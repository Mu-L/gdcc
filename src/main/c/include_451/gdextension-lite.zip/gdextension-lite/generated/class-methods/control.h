// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONTROL_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONTROL_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_Control *godot_new_Control();

// Methods
GDEXTENSION_LITE_DECL godot_bool godot_Control__has_point(const godot_Control *self, const godot_Vector2 *point);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_Vector3i) godot_Control__structured_text_parser(const godot_Control *self, const godot_Array *args, const godot_String *text);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Control__get_minimum_size(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_String godot_Control__get_tooltip(const godot_Control *self, const godot_Vector2 *at_position);
GDEXTENSION_LITE_DECL godot_Variant godot_Control__get_drag_data(godot_Control *self, const godot_Vector2 *at_position);
GDEXTENSION_LITE_DECL godot_bool godot_Control__can_drop_data(const godot_Control *self, const godot_Vector2 *at_position, const godot_Variant *data);
GDEXTENSION_LITE_DECL void godot_Control__drop_data(godot_Control *self, const godot_Vector2 *at_position, const godot_Variant *data);
GDEXTENSION_LITE_DECL godot_Object * godot_Control__make_custom_tooltip(const godot_Control *self, const godot_String *for_text);
GDEXTENSION_LITE_DECL godot_String godot_Control__accessibility_get_contextual_info(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_String godot_Control__get_accessibility_container_name(const godot_Control *self, const godot_Node *node);
GDEXTENSION_LITE_DECL void godot_Control__gui_input(godot_Control *self, const godot_InputEvent *event);
GDEXTENSION_LITE_DECL void godot_Control_accept_event(godot_Control *self);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Control_get_minimum_size(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Control_get_combined_minimum_size(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_anchors_preset(godot_Control *self, godot_Control_LayoutPreset preset, godot_bool keep_offsets);
GDEXTENSION_LITE_DECL void godot_Control_set_offsets_preset(godot_Control *self, godot_Control_LayoutPreset preset, godot_Control_LayoutPresetMode resize_mode, godot_int margin);
GDEXTENSION_LITE_DECL void godot_Control_set_anchors_and_offsets_preset(godot_Control *self, godot_Control_LayoutPreset preset, godot_Control_LayoutPresetMode resize_mode, godot_int margin);
GDEXTENSION_LITE_DECL void godot_Control_set_anchor(godot_Control *self, godot_Side side, godot_float anchor, godot_bool keep_offset, godot_bool push_opposite_anchor);
GDEXTENSION_LITE_DECL godot_float godot_Control_get_anchor(const godot_Control *self, godot_Side side);
GDEXTENSION_LITE_DECL void godot_Control_set_offset(godot_Control *self, godot_Side side, godot_float offset);
GDEXTENSION_LITE_DECL godot_float godot_Control_get_offset(const godot_Control *self, godot_Side offset);
GDEXTENSION_LITE_DECL void godot_Control_set_anchor_and_offset(godot_Control *self, godot_Side side, godot_float anchor, godot_float offset, godot_bool push_opposite_anchor);
GDEXTENSION_LITE_DECL void godot_Control_set_begin(godot_Control *self, const godot_Vector2 *position);
GDEXTENSION_LITE_DECL void godot_Control_set_end(godot_Control *self, const godot_Vector2 *position);
GDEXTENSION_LITE_DECL void godot_Control_set_position(godot_Control *self, const godot_Vector2 *position, godot_bool keep_offsets);
GDEXTENSION_LITE_DECL void godot_Control_set_size(godot_Control *self, const godot_Vector2 *size, godot_bool keep_offsets);
GDEXTENSION_LITE_DECL void godot_Control_reset_size(godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_custom_minimum_size(godot_Control *self, const godot_Vector2 *size);
GDEXTENSION_LITE_DECL void godot_Control_set_global_position(godot_Control *self, const godot_Vector2 *position, godot_bool keep_offsets);
GDEXTENSION_LITE_DECL void godot_Control_set_rotation(godot_Control *self, godot_float radians);
GDEXTENSION_LITE_DECL void godot_Control_set_rotation_degrees(godot_Control *self, godot_float degrees);
GDEXTENSION_LITE_DECL void godot_Control_set_scale(godot_Control *self, const godot_Vector2 *scale);
GDEXTENSION_LITE_DECL void godot_Control_set_pivot_offset(godot_Control *self, const godot_Vector2 *pivot_offset);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Control_get_begin(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Control_get_end(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Control_get_position(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Control_get_size(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_float godot_Control_get_rotation(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_float godot_Control_get_rotation_degrees(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Control_get_scale(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Control_get_pivot_offset(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Control_get_custom_minimum_size(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Control_get_parent_area_size(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Control_get_global_position(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Control_get_screen_position(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_Rect2 godot_Control_get_rect(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_Rect2 godot_Control_get_global_rect(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_focus_mode(godot_Control *self, godot_Control_FocusMode mode);
GDEXTENSION_LITE_DECL godot_Control_FocusMode godot_Control_get_focus_mode(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_Control_FocusMode godot_Control_get_focus_mode_with_override(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_focus_behavior_recursive(godot_Control *self, godot_Control_FocusBehaviorRecursive focus_behavior_recursive);
GDEXTENSION_LITE_DECL godot_Control_FocusBehaviorRecursive godot_Control_get_focus_behavior_recursive(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_bool godot_Control_has_focus(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_grab_focus(godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_release_focus(godot_Control *self);
GDEXTENSION_LITE_DECL godot_Control * godot_Control_find_prev_valid_focus(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_Control * godot_Control_find_next_valid_focus(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_Control * godot_Control_find_valid_focus_neighbor(const godot_Control *self, godot_Side side);
GDEXTENSION_LITE_DECL void godot_Control_set_h_size_flags(godot_Control *self, const godot_Control_SizeFlags *flags);
GDEXTENSION_LITE_DECL godot_Control_SizeFlags godot_Control_get_h_size_flags(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_stretch_ratio(godot_Control *self, godot_float ratio);
GDEXTENSION_LITE_DECL godot_float godot_Control_get_stretch_ratio(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_v_size_flags(godot_Control *self, const godot_Control_SizeFlags *flags);
GDEXTENSION_LITE_DECL godot_Control_SizeFlags godot_Control_get_v_size_flags(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_theme(godot_Control *self, const godot_Theme *theme);
GDEXTENSION_LITE_DECL godot_Theme * godot_Control_get_theme(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_theme_type_variation(godot_Control *self, const godot_StringName *theme_type);
GDEXTENSION_LITE_DECL godot_StringName godot_Control_get_theme_type_variation(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_begin_bulk_theme_override(godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_end_bulk_theme_override(godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_add_theme_icon_override(godot_Control *self, const godot_StringName *name, const godot_Texture2D *texture);
GDEXTENSION_LITE_DECL void godot_Control_add_theme_stylebox_override(godot_Control *self, const godot_StringName *name, const godot_StyleBox *stylebox);
GDEXTENSION_LITE_DECL void godot_Control_add_theme_font_override(godot_Control *self, const godot_StringName *name, const godot_Font *font);
GDEXTENSION_LITE_DECL void godot_Control_add_theme_font_size_override(godot_Control *self, const godot_StringName *name, godot_int font_size);
GDEXTENSION_LITE_DECL void godot_Control_add_theme_color_override(godot_Control *self, const godot_StringName *name, const godot_Color *color);
GDEXTENSION_LITE_DECL void godot_Control_add_theme_constant_override(godot_Control *self, const godot_StringName *name, godot_int constant);
GDEXTENSION_LITE_DECL void godot_Control_remove_theme_icon_override(godot_Control *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL void godot_Control_remove_theme_stylebox_override(godot_Control *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL void godot_Control_remove_theme_font_override(godot_Control *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL void godot_Control_remove_theme_font_size_override(godot_Control *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL void godot_Control_remove_theme_color_override(godot_Control *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL void godot_Control_remove_theme_constant_override(godot_Control *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL godot_Texture2D * godot_Control_get_theme_icon(const godot_Control *self, const godot_StringName *name, const godot_StringName *theme_type);
GDEXTENSION_LITE_DECL godot_StyleBox * godot_Control_get_theme_stylebox(const godot_Control *self, const godot_StringName *name, const godot_StringName *theme_type);
GDEXTENSION_LITE_DECL godot_Font * godot_Control_get_theme_font(const godot_Control *self, const godot_StringName *name, const godot_StringName *theme_type);
GDEXTENSION_LITE_DECL godot_int godot_Control_get_theme_font_size(const godot_Control *self, const godot_StringName *name, const godot_StringName *theme_type);
GDEXTENSION_LITE_DECL godot_Color godot_Control_get_theme_color(const godot_Control *self, const godot_StringName *name, const godot_StringName *theme_type);
GDEXTENSION_LITE_DECL godot_int godot_Control_get_theme_constant(const godot_Control *self, const godot_StringName *name, const godot_StringName *theme_type);
GDEXTENSION_LITE_DECL godot_bool godot_Control_has_theme_icon_override(const godot_Control *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL godot_bool godot_Control_has_theme_stylebox_override(const godot_Control *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL godot_bool godot_Control_has_theme_font_override(const godot_Control *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL godot_bool godot_Control_has_theme_font_size_override(const godot_Control *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL godot_bool godot_Control_has_theme_color_override(const godot_Control *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL godot_bool godot_Control_has_theme_constant_override(const godot_Control *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL godot_bool godot_Control_has_theme_icon(const godot_Control *self, const godot_StringName *name, const godot_StringName *theme_type);
GDEXTENSION_LITE_DECL godot_bool godot_Control_has_theme_stylebox(const godot_Control *self, const godot_StringName *name, const godot_StringName *theme_type);
GDEXTENSION_LITE_DECL godot_bool godot_Control_has_theme_font(const godot_Control *self, const godot_StringName *name, const godot_StringName *theme_type);
GDEXTENSION_LITE_DECL godot_bool godot_Control_has_theme_font_size(const godot_Control *self, const godot_StringName *name, const godot_StringName *theme_type);
GDEXTENSION_LITE_DECL godot_bool godot_Control_has_theme_color(const godot_Control *self, const godot_StringName *name, const godot_StringName *theme_type);
GDEXTENSION_LITE_DECL godot_bool godot_Control_has_theme_constant(const godot_Control *self, const godot_StringName *name, const godot_StringName *theme_type);
GDEXTENSION_LITE_DECL godot_float godot_Control_get_theme_default_base_scale(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_Font * godot_Control_get_theme_default_font(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_int godot_Control_get_theme_default_font_size(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_Control * godot_Control_get_parent_control(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_h_grow_direction(godot_Control *self, godot_Control_GrowDirection direction);
GDEXTENSION_LITE_DECL godot_Control_GrowDirection godot_Control_get_h_grow_direction(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_v_grow_direction(godot_Control *self, godot_Control_GrowDirection direction);
GDEXTENSION_LITE_DECL godot_Control_GrowDirection godot_Control_get_v_grow_direction(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_tooltip_auto_translate_mode(godot_Control *self, godot_Node_AutoTranslateMode mode);
GDEXTENSION_LITE_DECL godot_Node_AutoTranslateMode godot_Control_get_tooltip_auto_translate_mode(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_tooltip_text(godot_Control *self, const godot_String *hint);
GDEXTENSION_LITE_DECL godot_String godot_Control_get_tooltip_text(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_String godot_Control_get_tooltip(const godot_Control *self, const godot_Vector2 *at_position);
GDEXTENSION_LITE_DECL void godot_Control_set_default_cursor_shape(godot_Control *self, godot_Control_CursorShape shape);
GDEXTENSION_LITE_DECL godot_Control_CursorShape godot_Control_get_default_cursor_shape(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_Control_CursorShape godot_Control_get_cursor_shape(const godot_Control *self, const godot_Vector2 *position);
GDEXTENSION_LITE_DECL void godot_Control_set_focus_neighbor(godot_Control *self, godot_Side side, const godot_NodePath *neighbor);
GDEXTENSION_LITE_DECL godot_NodePath godot_Control_get_focus_neighbor(const godot_Control *self, godot_Side side);
GDEXTENSION_LITE_DECL void godot_Control_set_focus_next(godot_Control *self, const godot_NodePath *next);
GDEXTENSION_LITE_DECL godot_NodePath godot_Control_get_focus_next(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_focus_previous(godot_Control *self, const godot_NodePath *previous);
GDEXTENSION_LITE_DECL godot_NodePath godot_Control_get_focus_previous(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_force_drag(godot_Control *self, const godot_Variant *data, const godot_Control *preview);
GDEXTENSION_LITE_DECL void godot_Control_accessibility_drag(godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_accessibility_drop(godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_accessibility_name(godot_Control *self, const godot_String *name);
GDEXTENSION_LITE_DECL godot_String godot_Control_get_accessibility_name(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_accessibility_description(godot_Control *self, const godot_String *description);
GDEXTENSION_LITE_DECL godot_String godot_Control_get_accessibility_description(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_accessibility_live(godot_Control *self, godot_DisplayServer_AccessibilityLiveMode mode);
GDEXTENSION_LITE_DECL godot_DisplayServer_AccessibilityLiveMode godot_Control_get_accessibility_live(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_accessibility_controls_nodes(godot_Control *self, const godot_TypedArray(godot_NodePath) *node_path);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_NodePath) godot_Control_get_accessibility_controls_nodes(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_accessibility_described_by_nodes(godot_Control *self, const godot_TypedArray(godot_NodePath) *node_path);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_NodePath) godot_Control_get_accessibility_described_by_nodes(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_accessibility_labeled_by_nodes(godot_Control *self, const godot_TypedArray(godot_NodePath) *node_path);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_NodePath) godot_Control_get_accessibility_labeled_by_nodes(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_accessibility_flow_to_nodes(godot_Control *self, const godot_TypedArray(godot_NodePath) *node_path);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_NodePath) godot_Control_get_accessibility_flow_to_nodes(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_mouse_filter(godot_Control *self, godot_Control_MouseFilter filter);
GDEXTENSION_LITE_DECL godot_Control_MouseFilter godot_Control_get_mouse_filter(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_Control_MouseFilter godot_Control_get_mouse_filter_with_override(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_mouse_behavior_recursive(godot_Control *self, godot_Control_MouseBehaviorRecursive mouse_behavior_recursive);
GDEXTENSION_LITE_DECL godot_Control_MouseBehaviorRecursive godot_Control_get_mouse_behavior_recursive(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_force_pass_scroll_events(godot_Control *self, godot_bool force_pass_scroll_events);
GDEXTENSION_LITE_DECL godot_bool godot_Control_is_force_pass_scroll_events(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_clip_contents(godot_Control *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_Control_is_clipping_contents(godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_grab_click_focus(godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_drag_forwarding(godot_Control *self, const godot_Callable *drag_func, const godot_Callable *can_drop_func, const godot_Callable *drop_func);
GDEXTENSION_LITE_DECL void godot_Control_set_drag_preview(godot_Control *self, const godot_Control *control);
GDEXTENSION_LITE_DECL godot_bool godot_Control_is_drag_successful(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_warp_mouse(godot_Control *self, const godot_Vector2 *position);
GDEXTENSION_LITE_DECL void godot_Control_set_shortcut_context(godot_Control *self, const godot_Node *node);
GDEXTENSION_LITE_DECL godot_Node * godot_Control_get_shortcut_context(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_update_minimum_size(godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_layout_direction(godot_Control *self, godot_Control_LayoutDirection direction);
GDEXTENSION_LITE_DECL godot_Control_LayoutDirection godot_Control_get_layout_direction(const godot_Control *self);
GDEXTENSION_LITE_DECL godot_bool godot_Control_is_layout_rtl(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_auto_translate(godot_Control *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_Control_is_auto_translating(const godot_Control *self);
GDEXTENSION_LITE_DECL void godot_Control_set_localize_numeral_system(godot_Control *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_Control_is_localizing_numeral_system(const godot_Control *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONTROL_H__
