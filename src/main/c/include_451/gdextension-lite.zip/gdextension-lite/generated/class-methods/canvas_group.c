// This file was automatically generated
// Do not modify this file
#include "canvas_group.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CanvasGroup *godot_new_CanvasGroup() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CanvasGroup);
}

// Methods
void godot_CanvasGroup_set_fit_margin(godot_CanvasGroup *self, godot_float fit_margin) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasGroup, set_fit_margin, 373806689, void, self, &fit_margin)
}
godot_float godot_CanvasGroup_get_fit_margin(const godot_CanvasGroup *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasGroup, get_fit_margin, 1740695150, godot_float, self)
}
void godot_CanvasGroup_set_clear_margin(godot_CanvasGroup *self, godot_float clear_margin) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasGroup, set_clear_margin, 373806689, void, self, &clear_margin)
}
godot_float godot_CanvasGroup_get_clear_margin(const godot_CanvasGroup *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasGroup, get_clear_margin, 1740695150, godot_float, self)
}
void godot_CanvasGroup_set_use_mipmaps(godot_CanvasGroup *self, godot_bool use_mipmaps) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasGroup, set_use_mipmaps, 2586408642, void, self, &use_mipmaps)
}
godot_bool godot_CanvasGroup_is_using_mipmaps(const godot_CanvasGroup *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasGroup, is_using_mipmaps, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
