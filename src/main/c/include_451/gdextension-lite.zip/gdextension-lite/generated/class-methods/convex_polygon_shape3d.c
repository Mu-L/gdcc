// This file was automatically generated
// Do not modify this file
#include "convex_polygon_shape3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_ConvexPolygonShape3D *godot_new_ConvexPolygonShape3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(ConvexPolygonShape3D);
}

// Methods
void godot_ConvexPolygonShape3D_set_points(godot_ConvexPolygonShape3D *self, const godot_PackedVector3Array *points) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ConvexPolygonShape3D, set_points, 334873810, void, self, points)
}
godot_PackedVector3Array godot_ConvexPolygonShape3D_get_points(const godot_ConvexPolygonShape3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConvexPolygonShape3D, get_points, 497664490, godot_PackedVector3Array, self)
}


#ifdef __cplusplus
}
#endif
