// This file was automatically generated
// Do not modify this file
#include "csgbox3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CSGBox3D *godot_new_CSGBox3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CSGBox3D);
}

// Methods
void godot_CSGBox3D_set_size(godot_CSGBox3D *self, const godot_Vector3 *size) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGBox3D, set_size, 3460891852, void, self, size)
}
godot_Vector3 godot_CSGBox3D_get_size(const godot_CSGBox3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGBox3D, get_size, 3360562783, godot_Vector3, self)
}
void godot_CSGBox3D_set_material(godot_CSGBox3D *self, const godot_Material *material) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGBox3D, set_material, 2757459619, void, self, material)
}
godot_Material * godot_CSGBox3D_get_material(const godot_CSGBox3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGBox3D, get_material, 5934680, godot_Material *, self)
}


#ifdef __cplusplus
}
#endif
