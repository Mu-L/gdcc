// This file was automatically generated
// Do not modify this file
#include "editor_node3dgizmo.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorNode3DGizmo *godot_new_EditorNode3DGizmo() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorNode3DGizmo);
}

// Methods
void godot_EditorNode3DGizmo__redraw(godot_EditorNode3DGizmo *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmo, _redraw, 3218959716, void, self)
}
godot_String godot_EditorNode3DGizmo__get_handle_name(const godot_EditorNode3DGizmo *self, godot_int id, godot_bool secondary) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorNode3DGizmo, _get_handle_name, 1868713439, godot_String, self, &id, &secondary)
}
godot_bool godot_EditorNode3DGizmo__is_handle_highlighted(const godot_EditorNode3DGizmo *self, godot_int id, godot_bool secondary) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorNode3DGizmo, _is_handle_highlighted, 361316320, godot_bool, self, &id, &secondary)
}
godot_Variant godot_EditorNode3DGizmo__get_handle_value(const godot_EditorNode3DGizmo *self, godot_int id, godot_bool secondary) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorNode3DGizmo, _get_handle_value, 2144196525, godot_Variant, self, &id, &secondary)
}
void godot_EditorNode3DGizmo__begin_handle_action(godot_EditorNode3DGizmo *self, godot_int id, godot_bool secondary) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmo, _begin_handle_action, 300928843, void, self, &id, &secondary)
}
void godot_EditorNode3DGizmo__set_handle(godot_EditorNode3DGizmo *self, godot_int id, godot_bool secondary, const godot_Camera3D *camera, const godot_Vector2 *point) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmo, _set_handle, 2210262157, void, self, &id, &secondary, camera, point)
}
void godot_EditorNode3DGizmo__commit_handle(godot_EditorNode3DGizmo *self, godot_int id, godot_bool secondary, const godot_Variant *restore, godot_bool cancel) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmo, _commit_handle, 3655739840, void, self, &id, &secondary, restore, &cancel)
}
godot_int godot_EditorNode3DGizmo__subgizmos_intersect_ray(const godot_EditorNode3DGizmo *self, const godot_Camera3D *camera, const godot_Vector2 *point) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorNode3DGizmo, _subgizmos_intersect_ray, 2055005479, godot_int, self, camera, point)
}
godot_PackedInt32Array godot_EditorNode3DGizmo__subgizmos_intersect_frustum(const godot_EditorNode3DGizmo *self, const godot_Camera3D *camera, const godot_TypedArray(godot_Plane) *frustum) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorNode3DGizmo, _subgizmos_intersect_frustum, 1653813165, godot_PackedInt32Array, self, camera, frustum)
}
void godot_EditorNode3DGizmo__set_subgizmo_transform(godot_EditorNode3DGizmo *self, godot_int id, const godot_Transform3D *transform) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmo, _set_subgizmo_transform, 3616898986, void, self, &id, transform)
}
godot_Transform3D godot_EditorNode3DGizmo__get_subgizmo_transform(const godot_EditorNode3DGizmo *self, godot_int id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorNode3DGizmo, _get_subgizmo_transform, 1965739696, godot_Transform3D, self, &id)
}
void godot_EditorNode3DGizmo__commit_subgizmos(godot_EditorNode3DGizmo *self, const godot_PackedInt32Array *ids, const godot_TypedArray(godot_Transform3D) *restores, godot_bool cancel) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmo, _commit_subgizmos, 3411059856, void, self, ids, restores, &cancel)
}
void godot_EditorNode3DGizmo_add_lines(godot_EditorNode3DGizmo *self, const godot_PackedVector3Array *lines, const godot_Material *material, godot_bool billboard, const godot_Color *modulate) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmo, add_lines, 2910971437, void, self, lines, material, &billboard, modulate)
}
void godot_EditorNode3DGizmo_add_mesh(godot_EditorNode3DGizmo *self, const godot_Mesh *mesh, const godot_Material *material, const godot_Transform3D *transform, const godot_SkinReference *skeleton) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmo, add_mesh, 1579955111, void, self, mesh, material, transform, skeleton)
}
void godot_EditorNode3DGizmo_add_collision_segments(godot_EditorNode3DGizmo *self, const godot_PackedVector3Array *segments) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmo, add_collision_segments, 334873810, void, self, segments)
}
void godot_EditorNode3DGizmo_add_collision_triangles(godot_EditorNode3DGizmo *self, const godot_TriangleMesh *triangles) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmo, add_collision_triangles, 54901064, void, self, triangles)
}
void godot_EditorNode3DGizmo_add_unscaled_billboard(godot_EditorNode3DGizmo *self, const godot_Material *material, godot_float default_scale, const godot_Color *modulate) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmo, add_unscaled_billboard, 520007164, void, self, material, &default_scale, modulate)
}
void godot_EditorNode3DGizmo_add_handles(godot_EditorNode3DGizmo *self, const godot_PackedVector3Array *handles, const godot_Material *material, const godot_PackedInt32Array *ids, godot_bool billboard, godot_bool secondary) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmo, add_handles, 2254560097, void, self, handles, material, ids, &billboard, &secondary)
}
void godot_EditorNode3DGizmo_set_node_3d(godot_EditorNode3DGizmo *self, const godot_Node *node) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmo, set_node_3d, 1078189570, void, self, node)
}
godot_Node3D * godot_EditorNode3DGizmo_get_node_3d(const godot_EditorNode3DGizmo *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorNode3DGizmo, get_node_3d, 151077316, godot_Node3D *, self)
}
godot_EditorNode3DGizmoPlugin * godot_EditorNode3DGizmo_get_plugin(const godot_EditorNode3DGizmo *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorNode3DGizmo, get_plugin, 4250544552, godot_EditorNode3DGizmoPlugin *, self)
}
void godot_EditorNode3DGizmo_clear(godot_EditorNode3DGizmo *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmo, clear, 3218959716, void, self)
}
void godot_EditorNode3DGizmo_set_hidden(godot_EditorNode3DGizmo *self, godot_bool hidden) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmo, set_hidden, 2586408642, void, self, &hidden)
}
godot_bool godot_EditorNode3DGizmo_is_subgizmo_selected(const godot_EditorNode3DGizmo *self, godot_int id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorNode3DGizmo, is_subgizmo_selected, 1116898809, godot_bool, self, &id)
}
godot_PackedInt32Array godot_EditorNode3DGizmo_get_subgizmo_selection(const godot_EditorNode3DGizmo *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorNode3DGizmo, get_subgizmo_selection, 1930428628, godot_PackedInt32Array, self)
}


#ifdef __cplusplus
}
#endif
