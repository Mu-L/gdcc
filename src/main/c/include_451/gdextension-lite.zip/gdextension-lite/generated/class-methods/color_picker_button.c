// This file was automatically generated
// Do not modify this file
#include "color_picker_button.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_ColorPickerButton *godot_new_ColorPickerButton() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(ColorPickerButton);
}

// Methods
void godot_ColorPickerButton_set_pick_color(godot_ColorPickerButton *self, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ColorPickerButton, set_pick_color, 2920490490, void, self, color)
}
godot_Color godot_ColorPickerButton_get_pick_color(const godot_ColorPickerButton *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ColorPickerButton, get_pick_color, 3444240500, godot_Color, self)
}
godot_ColorPicker * godot_ColorPickerButton_get_picker(godot_ColorPickerButton *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ColorPickerButton, get_picker, 331835996, godot_ColorPicker *, self)
}
godot_PopupPanel * godot_ColorPickerButton_get_popup(godot_ColorPickerButton *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ColorPickerButton, get_popup, 1322440207, godot_PopupPanel *, self)
}
void godot_ColorPickerButton_set_edit_alpha(godot_ColorPickerButton *self, godot_bool show) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ColorPickerButton, set_edit_alpha, 2586408642, void, self, &show)
}
godot_bool godot_ColorPickerButton_is_editing_alpha(const godot_ColorPickerButton *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ColorPickerButton, is_editing_alpha, 36873697, godot_bool, self)
}
void godot_ColorPickerButton_set_edit_intensity(godot_ColorPickerButton *self, godot_bool show) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ColorPickerButton, set_edit_intensity, 2586408642, void, self, &show)
}
godot_bool godot_ColorPickerButton_is_editing_intensity(const godot_ColorPickerButton *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ColorPickerButton, is_editing_intensity, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
