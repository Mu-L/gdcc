// This file was automatically generated
// Do not modify this file
#include "audio_stream_wav.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioStreamWAV *godot_new_AudioStreamWAV() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioStreamWAV);
}

// Methods
godot_AudioStreamWAV * godot_AudioStreamWAV_load_from_buffer(const godot_PackedByteArray *stream_data, const godot_Dictionary *options) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamWAV, load_from_buffer, 4266838938, godot_AudioStreamWAV *, NULL, stream_data, options)
}
godot_AudioStreamWAV * godot_AudioStreamWAV_load_from_file(const godot_String *path, const godot_Dictionary *options) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamWAV, load_from_file, 4015802384, godot_AudioStreamWAV *, NULL, path, options)
}
void godot_AudioStreamWAV_set_data(godot_AudioStreamWAV *self, const godot_PackedByteArray *data) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamWAV, set_data, 2971499966, void, self, data)
}
godot_PackedByteArray godot_AudioStreamWAV_get_data(const godot_AudioStreamWAV *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamWAV, get_data, 2362200018, godot_PackedByteArray, self)
}
void godot_AudioStreamWAV_set_format(godot_AudioStreamWAV *self, godot_AudioStreamWAV_Format format) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamWAV, set_format, 60648488, void, self, &format)
}
godot_AudioStreamWAV_Format godot_AudioStreamWAV_get_format(const godot_AudioStreamWAV *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamWAV, get_format, 3151724922, godot_AudioStreamWAV_Format, self)
}
void godot_AudioStreamWAV_set_loop_mode(godot_AudioStreamWAV *self, godot_AudioStreamWAV_LoopMode loop_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamWAV, set_loop_mode, 2444882972, void, self, &loop_mode)
}
godot_AudioStreamWAV_LoopMode godot_AudioStreamWAV_get_loop_mode(const godot_AudioStreamWAV *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamWAV, get_loop_mode, 393560655, godot_AudioStreamWAV_LoopMode, self)
}
void godot_AudioStreamWAV_set_loop_begin(godot_AudioStreamWAV *self, godot_int loop_begin) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamWAV, set_loop_begin, 1286410249, void, self, &loop_begin)
}
godot_int godot_AudioStreamWAV_get_loop_begin(const godot_AudioStreamWAV *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamWAV, get_loop_begin, 3905245786, godot_int, self)
}
void godot_AudioStreamWAV_set_loop_end(godot_AudioStreamWAV *self, godot_int loop_end) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamWAV, set_loop_end, 1286410249, void, self, &loop_end)
}
godot_int godot_AudioStreamWAV_get_loop_end(const godot_AudioStreamWAV *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamWAV, get_loop_end, 3905245786, godot_int, self)
}
void godot_AudioStreamWAV_set_mix_rate(godot_AudioStreamWAV *self, godot_int mix_rate) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamWAV, set_mix_rate, 1286410249, void, self, &mix_rate)
}
godot_int godot_AudioStreamWAV_get_mix_rate(const godot_AudioStreamWAV *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamWAV, get_mix_rate, 3905245786, godot_int, self)
}
void godot_AudioStreamWAV_set_stereo(godot_AudioStreamWAV *self, godot_bool stereo) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamWAV, set_stereo, 2586408642, void, self, &stereo)
}
godot_bool godot_AudioStreamWAV_is_stereo(const godot_AudioStreamWAV *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamWAV, is_stereo, 36873697, godot_bool, self)
}
void godot_AudioStreamWAV_set_tags(godot_AudioStreamWAV *self, const godot_Dictionary *tags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamWAV, set_tags, 4155329257, void, self, tags)
}
godot_Dictionary godot_AudioStreamWAV_get_tags(const godot_AudioStreamWAV *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamWAV, get_tags, 3102165223, godot_Dictionary, self)
}
godot_Error godot_AudioStreamWAV_save_to_wav(godot_AudioStreamWAV *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamWAV, save_to_wav, 166001499, godot_Error, self, path)
}


#ifdef __cplusplus
}
#endif
