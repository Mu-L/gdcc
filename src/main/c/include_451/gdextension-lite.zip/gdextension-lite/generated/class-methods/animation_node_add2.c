// This file was automatically generated
// Do not modify this file
#include "animation_node_add2.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimationNodeAdd2 *godot_new_AnimationNodeAdd2() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimationNodeAdd2);
}


#ifdef __cplusplus
}
#endif
