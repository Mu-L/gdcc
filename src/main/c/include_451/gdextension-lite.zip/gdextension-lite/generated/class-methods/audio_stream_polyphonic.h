// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_POLYPHONIC_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_POLYPHONIC_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioStreamPolyphonic *godot_new_AudioStreamPolyphonic();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioStreamPolyphonic_set_polyphony(godot_AudioStreamPolyphonic *self, godot_int voices);
GDEXTENSION_LITE_DECL godot_int godot_AudioStreamPolyphonic_get_polyphony(const godot_AudioStreamPolyphonic *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_POLYPHONIC_H__
