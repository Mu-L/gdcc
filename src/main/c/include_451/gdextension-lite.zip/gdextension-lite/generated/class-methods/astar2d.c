// This file was automatically generated
// Do not modify this file
#include "astar2d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AStar2D *godot_new_AStar2D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AStar2D);
}

// Methods
godot_bool godot_AStar2D__filter_neighbor(const godot_AStar2D *self, godot_int from_id, godot_int neighbor_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStar2D, _filter_neighbor, 2522259332, godot_bool, self, &from_id, &neighbor_id)
}
godot_float godot_AStar2D__estimate_cost(const godot_AStar2D *self, godot_int from_id, godot_int end_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStar2D, _estimate_cost, 3085491603, godot_float, self, &from_id, &end_id)
}
godot_float godot_AStar2D__compute_cost(const godot_AStar2D *self, godot_int from_id, godot_int to_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStar2D, _compute_cost, 3085491603, godot_float, self, &from_id, &to_id)
}
godot_int godot_AStar2D_get_available_point_id(const godot_AStar2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStar2D, get_available_point_id, 3905245786, godot_int, self)
}
void godot_AStar2D_add_point(godot_AStar2D *self, godot_int id, const godot_Vector2 *position, godot_float weight_scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStar2D, add_point, 4074201818, void, self, &id, position, &weight_scale)
}
godot_Vector2 godot_AStar2D_get_point_position(const godot_AStar2D *self, godot_int id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStar2D, get_point_position, 2299179447, godot_Vector2, self, &id)
}
void godot_AStar2D_set_point_position(godot_AStar2D *self, godot_int id, const godot_Vector2 *position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStar2D, set_point_position, 163021252, void, self, &id, position)
}
godot_float godot_AStar2D_get_point_weight_scale(const godot_AStar2D *self, godot_int id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStar2D, get_point_weight_scale, 2339986948, godot_float, self, &id)
}
void godot_AStar2D_set_point_weight_scale(godot_AStar2D *self, godot_int id, godot_float weight_scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStar2D, set_point_weight_scale, 1602489585, void, self, &id, &weight_scale)
}
void godot_AStar2D_remove_point(godot_AStar2D *self, godot_int id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStar2D, remove_point, 1286410249, void, self, &id)
}
godot_bool godot_AStar2D_has_point(const godot_AStar2D *self, godot_int id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStar2D, has_point, 1116898809, godot_bool, self, &id)
}
godot_PackedInt64Array godot_AStar2D_get_point_connections(godot_AStar2D *self, godot_int id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStar2D, get_point_connections, 2865087369, godot_PackedInt64Array, self, &id)
}
godot_PackedInt64Array godot_AStar2D_get_point_ids(godot_AStar2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStar2D, get_point_ids, 3851388692, godot_PackedInt64Array, self)
}
void godot_AStar2D_set_neighbor_filter_enabled(godot_AStar2D *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStar2D, set_neighbor_filter_enabled, 2586408642, void, self, &enabled)
}
godot_bool godot_AStar2D_is_neighbor_filter_enabled(const godot_AStar2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStar2D, is_neighbor_filter_enabled, 36873697, godot_bool, self)
}
void godot_AStar2D_set_point_disabled(godot_AStar2D *self, godot_int id, godot_bool disabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStar2D, set_point_disabled, 972357352, void, self, &id, &disabled)
}
godot_bool godot_AStar2D_is_point_disabled(const godot_AStar2D *self, godot_int id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStar2D, is_point_disabled, 1116898809, godot_bool, self, &id)
}
void godot_AStar2D_connect_points(godot_AStar2D *self, godot_int id, godot_int to_id, godot_bool bidirectional) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStar2D, connect_points, 3710494224, void, self, &id, &to_id, &bidirectional)
}
void godot_AStar2D_disconnect_points(godot_AStar2D *self, godot_int id, godot_int to_id, godot_bool bidirectional) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStar2D, disconnect_points, 3710494224, void, self, &id, &to_id, &bidirectional)
}
godot_bool godot_AStar2D_are_points_connected(const godot_AStar2D *self, godot_int id, godot_int to_id, godot_bool bidirectional) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStar2D, are_points_connected, 2288175859, godot_bool, self, &id, &to_id, &bidirectional)
}
godot_int godot_AStar2D_get_point_count(const godot_AStar2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStar2D, get_point_count, 3905245786, godot_int, self)
}
godot_int godot_AStar2D_get_point_capacity(const godot_AStar2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStar2D, get_point_capacity, 3905245786, godot_int, self)
}
void godot_AStar2D_reserve_space(godot_AStar2D *self, godot_int num_nodes) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStar2D, reserve_space, 1286410249, void, self, &num_nodes)
}
void godot_AStar2D_clear(godot_AStar2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStar2D, clear, 3218959716, void, self)
}
godot_int godot_AStar2D_get_closest_point(const godot_AStar2D *self, const godot_Vector2 *to_position, godot_bool include_disabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStar2D, get_closest_point, 2300324924, godot_int, self, to_position, &include_disabled)
}
godot_Vector2 godot_AStar2D_get_closest_position_in_segment(const godot_AStar2D *self, const godot_Vector2 *to_position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStar2D, get_closest_position_in_segment, 2656412154, godot_Vector2, self, to_position)
}
godot_PackedVector2Array godot_AStar2D_get_point_path(godot_AStar2D *self, godot_int from_id, godot_int to_id, godot_bool allow_partial_path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStar2D, get_point_path, 3427490392, godot_PackedVector2Array, self, &from_id, &to_id, &allow_partial_path)
}
godot_PackedInt64Array godot_AStar2D_get_id_path(godot_AStar2D *self, godot_int from_id, godot_int to_id, godot_bool allow_partial_path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStar2D, get_id_path, 3136199648, godot_PackedInt64Array, self, &from_id, &to_id, &allow_partial_path)
}


#ifdef __cplusplus
}
#endif
