// This file was automatically generated
// Do not modify this file
#include "editor_export_preset.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
godot_bool godot_EditorExportPreset_has(const godot_EditorExportPreset *self, const godot_StringName *property) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, has, 2619796661, godot_bool, self, property)
}
godot_PackedStringArray godot_EditorExportPreset_get_files_to_export(const godot_EditorExportPreset *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, get_files_to_export, 1139954409, godot_PackedStringArray, self)
}
godot_Dictionary godot_EditorExportPreset_get_customized_files(const godot_EditorExportPreset *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, get_customized_files, 3102165223, godot_Dictionary, self)
}
godot_int godot_EditorExportPreset_get_customized_files_count(const godot_EditorExportPreset *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, get_customized_files_count, 3905245786, godot_int, self)
}
godot_bool godot_EditorExportPreset_has_export_file(godot_EditorExportPreset *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, has_export_file, 2323990056, godot_bool, self, path)
}
godot_EditorExportPreset_FileExportMode godot_EditorExportPreset_get_file_export_mode(const godot_EditorExportPreset *self, const godot_String *path, godot_EditorExportPreset_FileExportMode default_value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, get_file_export_mode, 407825436, godot_EditorExportPreset_FileExportMode, self, path, &default_value)
}
godot_Variant godot_EditorExportPreset_get_project_setting(godot_EditorExportPreset *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, get_project_setting, 2138907829, godot_Variant, self, name)
}
godot_String godot_EditorExportPreset_get_preset_name(const godot_EditorExportPreset *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, get_preset_name, 201670096, godot_String, self)
}
godot_bool godot_EditorExportPreset_is_runnable(const godot_EditorExportPreset *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, is_runnable, 36873697, godot_bool, self)
}
godot_bool godot_EditorExportPreset_are_advanced_options_enabled(const godot_EditorExportPreset *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, are_advanced_options_enabled, 36873697, godot_bool, self)
}
godot_bool godot_EditorExportPreset_is_dedicated_server(const godot_EditorExportPreset *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, is_dedicated_server, 36873697, godot_bool, self)
}
godot_EditorExportPreset_ExportFilter godot_EditorExportPreset_get_export_filter(const godot_EditorExportPreset *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, get_export_filter, 4227045696, godot_EditorExportPreset_ExportFilter, self)
}
godot_String godot_EditorExportPreset_get_include_filter(const godot_EditorExportPreset *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, get_include_filter, 201670096, godot_String, self)
}
godot_String godot_EditorExportPreset_get_exclude_filter(const godot_EditorExportPreset *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, get_exclude_filter, 201670096, godot_String, self)
}
godot_String godot_EditorExportPreset_get_custom_features(const godot_EditorExportPreset *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, get_custom_features, 201670096, godot_String, self)
}
godot_PackedStringArray godot_EditorExportPreset_get_patches(const godot_EditorExportPreset *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, get_patches, 1139954409, godot_PackedStringArray, self)
}
godot_String godot_EditorExportPreset_get_export_path(const godot_EditorExportPreset *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, get_export_path, 201670096, godot_String, self)
}
godot_String godot_EditorExportPreset_get_encryption_in_filter(const godot_EditorExportPreset *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, get_encryption_in_filter, 201670096, godot_String, self)
}
godot_String godot_EditorExportPreset_get_encryption_ex_filter(const godot_EditorExportPreset *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, get_encryption_ex_filter, 201670096, godot_String, self)
}
godot_bool godot_EditorExportPreset_get_encrypt_pck(const godot_EditorExportPreset *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, get_encrypt_pck, 36873697, godot_bool, self)
}
godot_bool godot_EditorExportPreset_get_encrypt_directory(const godot_EditorExportPreset *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, get_encrypt_directory, 36873697, godot_bool, self)
}
godot_String godot_EditorExportPreset_get_encryption_key(const godot_EditorExportPreset *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, get_encryption_key, 201670096, godot_String, self)
}
godot_int godot_EditorExportPreset_get_script_export_mode(const godot_EditorExportPreset *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, get_script_export_mode, 3905245786, godot_int, self)
}
godot_Variant godot_EditorExportPreset_get_or_env(const godot_EditorExportPreset *self, const godot_StringName *name, const godot_String *env_var) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, get_or_env, 389838787, godot_Variant, self, name, env_var)
}
godot_String godot_EditorExportPreset_get_version(const godot_EditorExportPreset *self, const godot_StringName *name, godot_bool windows_version) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPreset, get_version, 1132184663, godot_String, self, name, &windows_version)
}


#ifdef __cplusplus
}
#endif
