// This file was automatically generated
// Do not modify this file
#include "animation_node.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimationNode *godot_new_AnimationNode() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimationNode);
}

// Methods
godot_Dictionary godot_AnimationNode__get_child_nodes(const godot_AnimationNode *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNode, _get_child_nodes, 3102165223, godot_Dictionary, self)
}
godot_Array godot_AnimationNode__get_parameter_list(const godot_AnimationNode *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNode, _get_parameter_list, 3995934104, godot_Array, self)
}
godot_AnimationNode * godot_AnimationNode__get_child_by_name(const godot_AnimationNode *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNode, _get_child_by_name, 625644256, godot_AnimationNode *, self, name)
}
godot_Variant godot_AnimationNode__get_parameter_default_value(const godot_AnimationNode *self, const godot_StringName *parameter) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNode, _get_parameter_default_value, 2760726917, godot_Variant, self, parameter)
}
godot_bool godot_AnimationNode__is_parameter_read_only(const godot_AnimationNode *self, const godot_StringName *parameter) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNode, _is_parameter_read_only, 2619796661, godot_bool, self, parameter)
}
godot_float godot_AnimationNode__process(godot_AnimationNode *self, godot_float time, godot_bool seek, godot_bool is_external_seeking, godot_bool test_only) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNode, _process, 2139827523, godot_float, self, &time, &seek, &is_external_seeking, &test_only)
}
godot_String godot_AnimationNode__get_caption(const godot_AnimationNode *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNode, _get_caption, 201670096, godot_String, self)
}
godot_bool godot_AnimationNode__has_filter(const godot_AnimationNode *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNode, _has_filter, 36873697, godot_bool, self)
}
godot_bool godot_AnimationNode_add_input(godot_AnimationNode *self, const godot_String *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNode, add_input, 2323990056, godot_bool, self, name)
}
void godot_AnimationNode_remove_input(godot_AnimationNode *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNode, remove_input, 1286410249, void, self, &index)
}
godot_bool godot_AnimationNode_set_input_name(godot_AnimationNode *self, godot_int input, const godot_String *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNode, set_input_name, 215573526, godot_bool, self, &input, name)
}
godot_String godot_AnimationNode_get_input_name(const godot_AnimationNode *self, godot_int input) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNode, get_input_name, 844755477, godot_String, self, &input)
}
godot_int godot_AnimationNode_get_input_count(const godot_AnimationNode *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNode, get_input_count, 3905245786, godot_int, self)
}
godot_int godot_AnimationNode_find_input(const godot_AnimationNode *self, const godot_String *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNode, find_input, 1321353865, godot_int, self, name)
}
void godot_AnimationNode_set_filter_path(godot_AnimationNode *self, const godot_NodePath *path, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNode, set_filter_path, 3868023870, void, self, path, &enable)
}
godot_bool godot_AnimationNode_is_path_filtered(const godot_AnimationNode *self, const godot_NodePath *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNode, is_path_filtered, 861721659, godot_bool, self, path)
}
void godot_AnimationNode_set_filter_enabled(godot_AnimationNode *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNode, set_filter_enabled, 2586408642, void, self, &enable)
}
godot_bool godot_AnimationNode_is_filter_enabled(const godot_AnimationNode *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNode, is_filter_enabled, 36873697, godot_bool, self)
}
godot_int godot_AnimationNode_get_processing_animation_tree_instance_id(const godot_AnimationNode *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNode, get_processing_animation_tree_instance_id, 3905245786, godot_int, self)
}
godot_bool godot_AnimationNode_is_process_testing(const godot_AnimationNode *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNode, is_process_testing, 36873697, godot_bool, self)
}
void godot_AnimationNode_blend_animation(godot_AnimationNode *self, const godot_StringName *animation, godot_float time, godot_float delta, godot_bool seeked, godot_bool is_external_seeking, godot_float blend, godot_Animation_LoopedFlag looped_flag) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNode, blend_animation, 1630801826, void, self, animation, &time, &delta, &seeked, &is_external_seeking, &blend, &looped_flag)
}
godot_float godot_AnimationNode_blend_node(godot_AnimationNode *self, const godot_StringName *name, const godot_AnimationNode *node, godot_float time, godot_bool seek, godot_bool is_external_seeking, godot_float blend, godot_AnimationNode_FilterAction filter, godot_bool sync, godot_bool test_only) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNode, blend_node, 1746075988, godot_float, self, name, node, &time, &seek, &is_external_seeking, &blend, &filter, &sync, &test_only)
}
godot_float godot_AnimationNode_blend_input(godot_AnimationNode *self, godot_int input_index, godot_float time, godot_bool seek, godot_bool is_external_seeking, godot_float blend, godot_AnimationNode_FilterAction filter, godot_bool sync, godot_bool test_only) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNode, blend_input, 1361527350, godot_float, self, &input_index, &time, &seek, &is_external_seeking, &blend, &filter, &sync, &test_only)
}
void godot_AnimationNode_set_parameter(godot_AnimationNode *self, const godot_StringName *name, const godot_Variant *value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNode, set_parameter, 3776071444, void, self, name, value)
}
godot_Variant godot_AnimationNode_get_parameter(const godot_AnimationNode *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNode, get_parameter, 2760726917, godot_Variant, self, name)
}


#ifdef __cplusplus
}
#endif
