// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAMERA_ATTRIBUTES_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAMERA_ATTRIBUTES_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CameraAttributes *godot_new_CameraAttributes();

// Methods
GDEXTENSION_LITE_DECL void godot_CameraAttributes_set_exposure_multiplier(godot_CameraAttributes *self, godot_float multiplier);
GDEXTENSION_LITE_DECL godot_float godot_CameraAttributes_get_exposure_multiplier(const godot_CameraAttributes *self);
GDEXTENSION_LITE_DECL void godot_CameraAttributes_set_exposure_sensitivity(godot_CameraAttributes *self, godot_float sensitivity);
GDEXTENSION_LITE_DECL godot_float godot_CameraAttributes_get_exposure_sensitivity(const godot_CameraAttributes *self);
GDEXTENSION_LITE_DECL void godot_CameraAttributes_set_auto_exposure_enabled(godot_CameraAttributes *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_CameraAttributes_is_auto_exposure_enabled(const godot_CameraAttributes *self);
GDEXTENSION_LITE_DECL void godot_CameraAttributes_set_auto_exposure_speed(godot_CameraAttributes *self, godot_float exposure_speed);
GDEXTENSION_LITE_DECL godot_float godot_CameraAttributes_get_auto_exposure_speed(const godot_CameraAttributes *self);
GDEXTENSION_LITE_DECL void godot_CameraAttributes_set_auto_exposure_scale(godot_CameraAttributes *self, godot_float exposure_grey);
GDEXTENSION_LITE_DECL godot_float godot_CameraAttributes_get_auto_exposure_scale(const godot_CameraAttributes *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAMERA_ATTRIBUTES_H__
