// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATED_TEXTURE_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATED_TEXTURE_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AnimatedTexture *godot_new_AnimatedTexture();

// Methods
GDEXTENSION_LITE_DECL void godot_AnimatedTexture_set_frames(godot_AnimatedTexture *self, godot_int frames);
GDEXTENSION_LITE_DECL godot_int godot_AnimatedTexture_get_frames(const godot_AnimatedTexture *self);
GDEXTENSION_LITE_DECL void godot_AnimatedTexture_set_current_frame(godot_AnimatedTexture *self, godot_int frame);
GDEXTENSION_LITE_DECL godot_int godot_AnimatedTexture_get_current_frame(const godot_AnimatedTexture *self);
GDEXTENSION_LITE_DECL void godot_AnimatedTexture_set_pause(godot_AnimatedTexture *self, godot_bool pause);
GDEXTENSION_LITE_DECL godot_bool godot_AnimatedTexture_get_pause(const godot_AnimatedTexture *self);
GDEXTENSION_LITE_DECL void godot_AnimatedTexture_set_one_shot(godot_AnimatedTexture *self, godot_bool one_shot);
GDEXTENSION_LITE_DECL godot_bool godot_AnimatedTexture_get_one_shot(const godot_AnimatedTexture *self);
GDEXTENSION_LITE_DECL void godot_AnimatedTexture_set_speed_scale(godot_AnimatedTexture *self, godot_float scale);
GDEXTENSION_LITE_DECL godot_float godot_AnimatedTexture_get_speed_scale(const godot_AnimatedTexture *self);
GDEXTENSION_LITE_DECL void godot_AnimatedTexture_set_frame_texture(godot_AnimatedTexture *self, godot_int frame, const godot_Texture2D *texture);
GDEXTENSION_LITE_DECL godot_Texture2D * godot_AnimatedTexture_get_frame_texture(const godot_AnimatedTexture *self, godot_int frame);
GDEXTENSION_LITE_DECL void godot_AnimatedTexture_set_frame_duration(godot_AnimatedTexture *self, godot_int frame, godot_float duration);
GDEXTENSION_LITE_DECL godot_float godot_AnimatedTexture_get_frame_duration(const godot_AnimatedTexture *self, godot_int frame);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATED_TEXTURE_H__
