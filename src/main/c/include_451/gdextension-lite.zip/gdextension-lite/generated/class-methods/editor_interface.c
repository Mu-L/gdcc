// This file was automatically generated
// Do not modify this file
#include "editor_interface.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Singleton
godot_EditorInterface *godot_EditorInterface_singleton() {
	GDEXTENSION_LITE_GET_SINGLETON_IMPL(EditorInterface, "EditorInterface");
}

// Methods
void godot_EditorInterface_restart_editor(godot_EditorInterface *self, godot_bool save) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, restart_editor, 3216645846, void, self, &save)
}
godot_EditorCommandPalette * godot_EditorInterface_get_command_palette(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_command_palette, 2471163807, godot_EditorCommandPalette *, self)
}
godot_EditorFileSystem * godot_EditorInterface_get_resource_filesystem(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_resource_filesystem, 780151678, godot_EditorFileSystem *, self)
}
godot_EditorPaths * godot_EditorInterface_get_editor_paths(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_editor_paths, 1595760068, godot_EditorPaths *, self)
}
godot_EditorResourcePreview * godot_EditorInterface_get_resource_previewer(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_resource_previewer, 943486957, godot_EditorResourcePreview *, self)
}
godot_EditorSelection * godot_EditorInterface_get_selection(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_selection, 2690272531, godot_EditorSelection *, self)
}
godot_EditorSettings * godot_EditorInterface_get_editor_settings(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_editor_settings, 4086932459, godot_EditorSettings *, self)
}
godot_EditorToaster * godot_EditorInterface_get_editor_toaster(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_editor_toaster, 3612675797, godot_EditorToaster *, self)
}
godot_EditorUndoRedoManager * godot_EditorInterface_get_editor_undo_redo(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_editor_undo_redo, 3819628421, godot_EditorUndoRedoManager *, self)
}
godot_TypedArray(godot_Texture2D) godot_EditorInterface_make_mesh_previews(godot_EditorInterface *self, const godot_TypedArray(godot_Mesh) *meshes, godot_int preview_size) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, make_mesh_previews, 878078554, godot_TypedArray(godot_Texture2D), self, meshes, &preview_size)
}
void godot_EditorInterface_set_plugin_enabled(godot_EditorInterface *self, const godot_String *plugin, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, set_plugin_enabled, 2678287736, void, self, plugin, &enabled)
}
godot_bool godot_EditorInterface_is_plugin_enabled(const godot_EditorInterface *self, const godot_String *plugin) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, is_plugin_enabled, 3927539163, godot_bool, self, plugin)
}
godot_Theme * godot_EditorInterface_get_editor_theme(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_editor_theme, 3846893731, godot_Theme *, self)
}
godot_Control * godot_EditorInterface_get_base_control(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_base_control, 2783021301, godot_Control *, self)
}
godot_VBoxContainer * godot_EditorInterface_get_editor_main_screen(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_editor_main_screen, 1706218421, godot_VBoxContainer *, self)
}
godot_ScriptEditor * godot_EditorInterface_get_script_editor(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_script_editor, 90868003, godot_ScriptEditor *, self)
}
godot_SubViewport * godot_EditorInterface_get_editor_viewport_2d(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_editor_viewport_2d, 3750751911, godot_SubViewport *, self)
}
godot_SubViewport * godot_EditorInterface_get_editor_viewport_3d(const godot_EditorInterface *self, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_editor_viewport_3d, 1970834490, godot_SubViewport *, self, &idx)
}
void godot_EditorInterface_set_main_screen_editor(godot_EditorInterface *self, const godot_String *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, set_main_screen_editor, 83702148, void, self, name)
}
void godot_EditorInterface_set_distraction_free_mode(godot_EditorInterface *self, godot_bool enter) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, set_distraction_free_mode, 2586408642, void, self, &enter)
}
godot_bool godot_EditorInterface_is_distraction_free_mode_enabled(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, is_distraction_free_mode_enabled, 36873697, godot_bool, self)
}
godot_bool godot_EditorInterface_is_multi_window_enabled(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, is_multi_window_enabled, 36873697, godot_bool, self)
}
godot_float godot_EditorInterface_get_editor_scale(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_editor_scale, 1740695150, godot_float, self)
}
void godot_EditorInterface_popup_dialog(godot_EditorInterface *self, const godot_Window *dialog, const godot_Rect2i *rect) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, popup_dialog, 2015770942, void, self, dialog, rect)
}
void godot_EditorInterface_popup_dialog_centered(godot_EditorInterface *self, const godot_Window *dialog, const godot_Vector2i *minsize) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, popup_dialog_centered, 346557367, void, self, dialog, minsize)
}
void godot_EditorInterface_popup_dialog_centered_ratio(godot_EditorInterface *self, const godot_Window *dialog, godot_float ratio) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, popup_dialog_centered_ratio, 2093669136, void, self, dialog, &ratio)
}
void godot_EditorInterface_popup_dialog_centered_clamped(godot_EditorInterface *self, const godot_Window *dialog, const godot_Vector2i *minsize, godot_float fallback_ratio) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, popup_dialog_centered_clamped, 3763385571, void, self, dialog, minsize, &fallback_ratio)
}
godot_String godot_EditorInterface_get_current_feature_profile(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_current_feature_profile, 201670096, godot_String, self)
}
void godot_EditorInterface_set_current_feature_profile(godot_EditorInterface *self, const godot_String *profile_name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, set_current_feature_profile, 83702148, void, self, profile_name)
}
void godot_EditorInterface_popup_node_selector(godot_EditorInterface *self, const godot_Callable *callback, const godot_TypedArray(godot_StringName) *valid_types, const godot_Node *current_value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, popup_node_selector, 2444591477, void, self, callback, valid_types, current_value)
}
void godot_EditorInterface_popup_property_selector(godot_EditorInterface *self, const godot_Object *object, const godot_Callable *callback, const godot_PackedInt32Array *type_filter, const godot_String *current_value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, popup_property_selector, 2955609011, void, self, object, callback, type_filter, current_value)
}
void godot_EditorInterface_popup_method_selector(godot_EditorInterface *self, const godot_Object *object, const godot_Callable *callback, const godot_String *current_value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, popup_method_selector, 3585505226, void, self, object, callback, current_value)
}
void godot_EditorInterface_popup_quick_open(godot_EditorInterface *self, const godot_Callable *callback, const godot_TypedArray(godot_StringName) *base_types) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, popup_quick_open, 2271411043, void, self, callback, base_types)
}
void godot_EditorInterface_popup_create_dialog(godot_EditorInterface *self, const godot_Callable *callback, const godot_StringName *base_type, const godot_String *current_type, const godot_String *dialog_title, const godot_TypedArray(godot_StringName) *type_blocklist) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, popup_create_dialog, 495277124, void, self, callback, base_type, current_type, dialog_title, type_blocklist)
}
godot_FileSystemDock * godot_EditorInterface_get_file_system_dock(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_file_system_dock, 3751012327, godot_FileSystemDock *, self)
}
void godot_EditorInterface_select_file(godot_EditorInterface *self, const godot_String *file) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, select_file, 83702148, void, self, file)
}
godot_PackedStringArray godot_EditorInterface_get_selected_paths(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_selected_paths, 1139954409, godot_PackedStringArray, self)
}
godot_String godot_EditorInterface_get_current_path(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_current_path, 201670096, godot_String, self)
}
godot_String godot_EditorInterface_get_current_directory(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_current_directory, 201670096, godot_String, self)
}
godot_EditorInspector * godot_EditorInterface_get_inspector(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_inspector, 3517113938, godot_EditorInspector *, self)
}
void godot_EditorInterface_inspect_object(godot_EditorInterface *self, const godot_Object *object, const godot_String *for_property, godot_bool inspector_only) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, inspect_object, 127962172, void, self, object, for_property, &inspector_only)
}
void godot_EditorInterface_edit_resource(godot_EditorInterface *self, const godot_Resource *resource) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, edit_resource, 968641751, void, self, resource)
}
void godot_EditorInterface_edit_node(godot_EditorInterface *self, const godot_Node *node) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, edit_node, 1078189570, void, self, node)
}
void godot_EditorInterface_edit_script(godot_EditorInterface *self, const godot_Script *script, godot_int line, godot_int column, godot_bool grab_focus) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, edit_script, 219829402, void, self, script, &line, &column, &grab_focus)
}
void godot_EditorInterface_open_scene_from_path(godot_EditorInterface *self, const godot_String *scene_filepath, godot_bool set_inherited) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, open_scene_from_path, 1168363258, void, self, scene_filepath, &set_inherited)
}
void godot_EditorInterface_reload_scene_from_path(godot_EditorInterface *self, const godot_String *scene_filepath) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, reload_scene_from_path, 83702148, void, self, scene_filepath)
}
godot_PackedStringArray godot_EditorInterface_get_open_scenes(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_open_scenes, 1139954409, godot_PackedStringArray, self)
}
godot_TypedArray(godot_Node) godot_EditorInterface_get_open_scene_roots(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_open_scene_roots, 3995934104, godot_TypedArray(godot_Node), self)
}
godot_Node * godot_EditorInterface_get_edited_scene_root(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_edited_scene_root, 3160264692, godot_Node *, self)
}
godot_Error godot_EditorInterface_save_scene(godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, save_scene, 166280745, godot_Error, self)
}
void godot_EditorInterface_save_scene_as(godot_EditorInterface *self, const godot_String *path, godot_bool with_preview) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, save_scene_as, 3647332257, void, self, path, &with_preview)
}
void godot_EditorInterface_save_all_scenes(godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, save_all_scenes, 3218959716, void, self)
}
godot_Error godot_EditorInterface_close_scene(godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, close_scene, 166280745, godot_Error, self)
}
void godot_EditorInterface_mark_scene_as_unsaved(godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, mark_scene_as_unsaved, 3218959716, void, self)
}
void godot_EditorInterface_play_main_scene(godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, play_main_scene, 3218959716, void, self)
}
void godot_EditorInterface_play_current_scene(godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, play_current_scene, 3218959716, void, self)
}
void godot_EditorInterface_play_custom_scene(godot_EditorInterface *self, const godot_String *scene_filepath) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, play_custom_scene, 83702148, void, self, scene_filepath)
}
void godot_EditorInterface_stop_playing_scene(godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, stop_playing_scene, 3218959716, void, self)
}
godot_bool godot_EditorInterface_is_playing_scene(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, is_playing_scene, 36873697, godot_bool, self)
}
godot_String godot_EditorInterface_get_playing_scene(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, get_playing_scene, 201670096, godot_String, self)
}
void godot_EditorInterface_set_movie_maker_enabled(godot_EditorInterface *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorInterface, set_movie_maker_enabled, 2586408642, void, self, &enabled)
}
godot_bool godot_EditorInterface_is_movie_maker_enabled(const godot_EditorInterface *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorInterface, is_movie_maker_enabled, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
