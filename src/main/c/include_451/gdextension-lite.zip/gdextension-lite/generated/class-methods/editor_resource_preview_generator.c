// This file was automatically generated
// Do not modify this file
#include "editor_resource_preview_generator.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorResourcePreviewGenerator *godot_new_EditorResourcePreviewGenerator() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorResourcePreviewGenerator);
}

// Methods
godot_bool godot_EditorResourcePreviewGenerator__handles(const godot_EditorResourcePreviewGenerator *self, const godot_String *type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorResourcePreviewGenerator, _handles, 3927539163, godot_bool, self, type)
}
godot_Texture2D * godot_EditorResourcePreviewGenerator__generate(const godot_EditorResourcePreviewGenerator *self, const godot_Resource *resource, const godot_Vector2i *size, const godot_Dictionary *metadata) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorResourcePreviewGenerator, _generate, 255939159, godot_Texture2D *, self, resource, size, metadata)
}
godot_Texture2D * godot_EditorResourcePreviewGenerator__generate_from_path(const godot_EditorResourcePreviewGenerator *self, const godot_String *path, const godot_Vector2i *size, const godot_Dictionary *metadata) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorResourcePreviewGenerator, _generate_from_path, 1601192835, godot_Texture2D *, self, path, size, metadata)
}
godot_bool godot_EditorResourcePreviewGenerator__generate_small_preview_automatically(const godot_EditorResourcePreviewGenerator *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorResourcePreviewGenerator, _generate_small_preview_automatically, 36873697, godot_bool, self)
}
godot_bool godot_EditorResourcePreviewGenerator__can_generate_small_preview(const godot_EditorResourcePreviewGenerator *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorResourcePreviewGenerator, _can_generate_small_preview, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
