// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_INSPECTOR_PLUGIN_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_INSPECTOR_PLUGIN_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorInspectorPlugin *godot_new_EditorInspectorPlugin();

// Methods
GDEXTENSION_LITE_DECL godot_bool godot_EditorInspectorPlugin__can_handle(const godot_EditorInspectorPlugin *self, const godot_Object *object);
GDEXTENSION_LITE_DECL void godot_EditorInspectorPlugin__parse_begin(godot_EditorInspectorPlugin *self, const godot_Object *object);
GDEXTENSION_LITE_DECL void godot_EditorInspectorPlugin__parse_category(godot_EditorInspectorPlugin *self, const godot_Object *object, const godot_String *category);
GDEXTENSION_LITE_DECL void godot_EditorInspectorPlugin__parse_group(godot_EditorInspectorPlugin *self, const godot_Object *object, const godot_String *group);
GDEXTENSION_LITE_DECL godot_bool godot_EditorInspectorPlugin__parse_property(godot_EditorInspectorPlugin *self, const godot_Object *object, godot_Variant_Type type, const godot_String *name, godot_PropertyHint hint_type, const godot_String *hint_string, const godot_PropertyUsageFlags *usage_flags, godot_bool wide);
GDEXTENSION_LITE_DECL void godot_EditorInspectorPlugin__parse_end(godot_EditorInspectorPlugin *self, const godot_Object *object);
GDEXTENSION_LITE_DECL void godot_EditorInspectorPlugin_add_custom_control(godot_EditorInspectorPlugin *self, const godot_Control *control);
GDEXTENSION_LITE_DECL void godot_EditorInspectorPlugin_add_property_editor(godot_EditorInspectorPlugin *self, const godot_String *property, const godot_Control *editor, godot_bool add_to_end, const godot_String *label);
GDEXTENSION_LITE_DECL void godot_EditorInspectorPlugin_add_property_editor_for_multiple_properties(godot_EditorInspectorPlugin *self, const godot_String *label, const godot_PackedStringArray *properties, const godot_Control *editor);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_INSPECTOR_PLUGIN_H__
