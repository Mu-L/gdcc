// This file was automatically generated
// Do not modify this file
#include "editor_scene_post_import_plugin.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorScenePostImportPlugin *godot_new_EditorScenePostImportPlugin() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorScenePostImportPlugin);
}

// Methods
void godot_EditorScenePostImportPlugin__get_internal_import_options(godot_EditorScenePostImportPlugin *self, godot_int category) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorScenePostImportPlugin, _get_internal_import_options, 1286410249, void, self, &category)
}
godot_Variant godot_EditorScenePostImportPlugin__get_internal_option_visibility(const godot_EditorScenePostImportPlugin *self, godot_int category, godot_bool for_animation, const godot_String *option) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorScenePostImportPlugin, _get_internal_option_visibility, 3811255416, godot_Variant, self, &category, &for_animation, option)
}
godot_Variant godot_EditorScenePostImportPlugin__get_internal_option_update_view_required(const godot_EditorScenePostImportPlugin *self, godot_int category, const godot_String *option) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorScenePostImportPlugin, _get_internal_option_update_view_required, 3957349696, godot_Variant, self, &category, option)
}
void godot_EditorScenePostImportPlugin__internal_process(godot_EditorScenePostImportPlugin *self, godot_int category, const godot_Node *base_node, const godot_Node *node, const godot_Resource *resource) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorScenePostImportPlugin, _internal_process, 3641982463, void, self, &category, base_node, node, resource)
}
void godot_EditorScenePostImportPlugin__get_import_options(godot_EditorScenePostImportPlugin *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorScenePostImportPlugin, _get_import_options, 83702148, void, self, path)
}
godot_Variant godot_EditorScenePostImportPlugin__get_option_visibility(const godot_EditorScenePostImportPlugin *self, const godot_String *path, godot_bool for_animation, const godot_String *option) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorScenePostImportPlugin, _get_option_visibility, 298836892, godot_Variant, self, path, &for_animation, option)
}
void godot_EditorScenePostImportPlugin__pre_process(godot_EditorScenePostImportPlugin *self, const godot_Node *scene) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorScenePostImportPlugin, _pre_process, 1078189570, void, self, scene)
}
void godot_EditorScenePostImportPlugin__post_process(godot_EditorScenePostImportPlugin *self, const godot_Node *scene) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorScenePostImportPlugin, _post_process, 1078189570, void, self, scene)
}
godot_Variant godot_EditorScenePostImportPlugin_get_option_value(const godot_EditorScenePostImportPlugin *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorScenePostImportPlugin, get_option_value, 2760726917, godot_Variant, self, name)
}
void godot_EditorScenePostImportPlugin_add_import_option(godot_EditorScenePostImportPlugin *self, const godot_String *name, const godot_Variant *value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorScenePostImportPlugin, add_import_option, 402577236, void, self, name, value)
}
void godot_EditorScenePostImportPlugin_add_import_option_advanced(godot_EditorScenePostImportPlugin *self, godot_Variant_Type type, const godot_String *name, const godot_Variant *default_value, godot_PropertyHint hint, const godot_String *hint_string, godot_int usage_flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorScenePostImportPlugin, add_import_option_advanced, 3674075649, void, self, &type, name, default_value, &hint, hint_string, &usage_flags)
}


#ifdef __cplusplus
}
#endif
