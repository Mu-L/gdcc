// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CSGPOLYGON3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CSGPOLYGON3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CSGPolygon3D *godot_new_CSGPolygon3D();

// Methods
GDEXTENSION_LITE_DECL void godot_CSGPolygon3D_set_polygon(godot_CSGPolygon3D *self, const godot_PackedVector2Array *polygon);
GDEXTENSION_LITE_DECL godot_PackedVector2Array godot_CSGPolygon3D_get_polygon(const godot_CSGPolygon3D *self);
GDEXTENSION_LITE_DECL void godot_CSGPolygon3D_set_mode(godot_CSGPolygon3D *self, godot_CSGPolygon3D_Mode mode);
GDEXTENSION_LITE_DECL godot_CSGPolygon3D_Mode godot_CSGPolygon3D_get_mode(const godot_CSGPolygon3D *self);
GDEXTENSION_LITE_DECL void godot_CSGPolygon3D_set_depth(godot_CSGPolygon3D *self, godot_float depth);
GDEXTENSION_LITE_DECL godot_float godot_CSGPolygon3D_get_depth(const godot_CSGPolygon3D *self);
GDEXTENSION_LITE_DECL void godot_CSGPolygon3D_set_spin_degrees(godot_CSGPolygon3D *self, godot_float degrees);
GDEXTENSION_LITE_DECL godot_float godot_CSGPolygon3D_get_spin_degrees(const godot_CSGPolygon3D *self);
GDEXTENSION_LITE_DECL void godot_CSGPolygon3D_set_spin_sides(godot_CSGPolygon3D *self, godot_int spin_sides);
GDEXTENSION_LITE_DECL godot_int godot_CSGPolygon3D_get_spin_sides(const godot_CSGPolygon3D *self);
GDEXTENSION_LITE_DECL void godot_CSGPolygon3D_set_path_node(godot_CSGPolygon3D *self, const godot_NodePath *path);
GDEXTENSION_LITE_DECL godot_NodePath godot_CSGPolygon3D_get_path_node(const godot_CSGPolygon3D *self);
GDEXTENSION_LITE_DECL void godot_CSGPolygon3D_set_path_interval_type(godot_CSGPolygon3D *self, godot_CSGPolygon3D_PathIntervalType interval_type);
GDEXTENSION_LITE_DECL godot_CSGPolygon3D_PathIntervalType godot_CSGPolygon3D_get_path_interval_type(const godot_CSGPolygon3D *self);
GDEXTENSION_LITE_DECL void godot_CSGPolygon3D_set_path_interval(godot_CSGPolygon3D *self, godot_float interval);
GDEXTENSION_LITE_DECL godot_float godot_CSGPolygon3D_get_path_interval(const godot_CSGPolygon3D *self);
GDEXTENSION_LITE_DECL void godot_CSGPolygon3D_set_path_simplify_angle(godot_CSGPolygon3D *self, godot_float degrees);
GDEXTENSION_LITE_DECL godot_float godot_CSGPolygon3D_get_path_simplify_angle(const godot_CSGPolygon3D *self);
GDEXTENSION_LITE_DECL void godot_CSGPolygon3D_set_path_rotation(godot_CSGPolygon3D *self, godot_CSGPolygon3D_PathRotation path_rotation);
GDEXTENSION_LITE_DECL godot_CSGPolygon3D_PathRotation godot_CSGPolygon3D_get_path_rotation(const godot_CSGPolygon3D *self);
GDEXTENSION_LITE_DECL void godot_CSGPolygon3D_set_path_rotation_accurate(godot_CSGPolygon3D *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CSGPolygon3D_get_path_rotation_accurate(const godot_CSGPolygon3D *self);
GDEXTENSION_LITE_DECL void godot_CSGPolygon3D_set_path_local(godot_CSGPolygon3D *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CSGPolygon3D_is_path_local(const godot_CSGPolygon3D *self);
GDEXTENSION_LITE_DECL void godot_CSGPolygon3D_set_path_continuous_u(godot_CSGPolygon3D *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CSGPolygon3D_is_path_continuous_u(const godot_CSGPolygon3D *self);
GDEXTENSION_LITE_DECL void godot_CSGPolygon3D_set_path_u_distance(godot_CSGPolygon3D *self, godot_float distance);
GDEXTENSION_LITE_DECL godot_float godot_CSGPolygon3D_get_path_u_distance(const godot_CSGPolygon3D *self);
GDEXTENSION_LITE_DECL void godot_CSGPolygon3D_set_path_joined(godot_CSGPolygon3D *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CSGPolygon3D_is_path_joined(const godot_CSGPolygon3D *self);
GDEXTENSION_LITE_DECL void godot_CSGPolygon3D_set_material(godot_CSGPolygon3D *self, const godot_Material *material);
GDEXTENSION_LITE_DECL godot_Material * godot_CSGPolygon3D_get_material(const godot_CSGPolygon3D *self);
GDEXTENSION_LITE_DECL void godot_CSGPolygon3D_set_smooth_faces(godot_CSGPolygon3D *self, godot_bool smooth_faces);
GDEXTENSION_LITE_DECL godot_bool godot_CSGPolygon3D_get_smooth_faces(const godot_CSGPolygon3D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CSGPOLYGON3D_H__
