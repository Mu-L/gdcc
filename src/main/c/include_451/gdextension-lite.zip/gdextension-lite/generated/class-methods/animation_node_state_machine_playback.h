// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_STATE_MACHINE_PLAYBACK_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_STATE_MACHINE_PLAYBACK_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AnimationNodeStateMachinePlayback *godot_new_AnimationNodeStateMachinePlayback();

// Methods
GDEXTENSION_LITE_DECL void godot_AnimationNodeStateMachinePlayback_travel(godot_AnimationNodeStateMachinePlayback *self, const godot_StringName *to_node, godot_bool reset_on_teleport);
GDEXTENSION_LITE_DECL void godot_AnimationNodeStateMachinePlayback_start(godot_AnimationNodeStateMachinePlayback *self, const godot_StringName *node, godot_bool reset);
GDEXTENSION_LITE_DECL void godot_AnimationNodeStateMachinePlayback_next(godot_AnimationNodeStateMachinePlayback *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeStateMachinePlayback_stop(godot_AnimationNodeStateMachinePlayback *self);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNodeStateMachinePlayback_is_playing(const godot_AnimationNodeStateMachinePlayback *self);
GDEXTENSION_LITE_DECL godot_StringName godot_AnimationNodeStateMachinePlayback_get_current_node(const godot_AnimationNodeStateMachinePlayback *self);
GDEXTENSION_LITE_DECL godot_float godot_AnimationNodeStateMachinePlayback_get_current_play_position(const godot_AnimationNodeStateMachinePlayback *self);
GDEXTENSION_LITE_DECL godot_float godot_AnimationNodeStateMachinePlayback_get_current_length(const godot_AnimationNodeStateMachinePlayback *self);
GDEXTENSION_LITE_DECL godot_StringName godot_AnimationNodeStateMachinePlayback_get_fading_from_node(const godot_AnimationNodeStateMachinePlayback *self);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_StringName) godot_AnimationNodeStateMachinePlayback_get_travel_path(const godot_AnimationNodeStateMachinePlayback *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_STATE_MACHINE_PLAYBACK_H__
