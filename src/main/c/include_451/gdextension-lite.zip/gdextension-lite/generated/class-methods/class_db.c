// This file was automatically generated
// Do not modify this file
#include "class_db.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Singleton
godot_ClassDB *godot_ClassDB_singleton() {
	GDEXTENSION_LITE_GET_SINGLETON_IMPL(ClassDB, "ClassDB");
}

// Methods
godot_PackedStringArray godot_ClassDB_get_class_list(const godot_ClassDB *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, get_class_list, 1139954409, godot_PackedStringArray, self)
}
godot_PackedStringArray godot_ClassDB_get_inheriters_from_class(const godot_ClassDB *self, const godot_StringName *cls) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, get_inheriters_from_class, 1761182771, godot_PackedStringArray, self, cls)
}
godot_StringName godot_ClassDB_get_parent_class(const godot_ClassDB *self, const godot_StringName *cls) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, get_parent_class, 1965194235, godot_StringName, self, cls)
}
godot_bool godot_ClassDB_class_exists(const godot_ClassDB *self, const godot_StringName *cls) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, class_exists, 2619796661, godot_bool, self, cls)
}
godot_bool godot_ClassDB_is_parent_class(const godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *inherits) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, is_parent_class, 471820014, godot_bool, self, cls, inherits)
}
godot_bool godot_ClassDB_can_instantiate(const godot_ClassDB *self, const godot_StringName *cls) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, can_instantiate, 2619796661, godot_bool, self, cls)
}
godot_Variant godot_ClassDB_instantiate(const godot_ClassDB *self, const godot_StringName *cls) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, instantiate, 2760726917, godot_Variant, self, cls)
}
godot_ClassDB_APIType godot_ClassDB_class_get_api_type(const godot_ClassDB *self, const godot_StringName *cls) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, class_get_api_type, 2475317043, godot_ClassDB_APIType, self, cls)
}
godot_bool godot_ClassDB_class_has_signal(const godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *signal) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, class_has_signal, 471820014, godot_bool, self, cls, signal)
}
godot_Dictionary godot_ClassDB_class_get_signal(const godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *signal) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, class_get_signal, 3061114238, godot_Dictionary, self, cls, signal)
}
godot_TypedArray(godot_Dictionary) godot_ClassDB_class_get_signal_list(const godot_ClassDB *self, const godot_StringName *cls, godot_bool no_inheritance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, class_get_signal_list, 3504980660, godot_TypedArray(godot_Dictionary), self, cls, &no_inheritance)
}
godot_TypedArray(godot_Dictionary) godot_ClassDB_class_get_property_list(const godot_ClassDB *self, const godot_StringName *cls, godot_bool no_inheritance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, class_get_property_list, 3504980660, godot_TypedArray(godot_Dictionary), self, cls, &no_inheritance)
}
godot_StringName godot_ClassDB_class_get_property_getter(godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *property) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, class_get_property_getter, 3770832642, godot_StringName, self, cls, property)
}
godot_StringName godot_ClassDB_class_get_property_setter(godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *property) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, class_get_property_setter, 3770832642, godot_StringName, self, cls, property)
}
godot_Variant godot_ClassDB_class_get_property(const godot_ClassDB *self, const godot_Object *object, const godot_StringName *property) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, class_get_property, 2498641674, godot_Variant, self, object, property)
}
godot_Error godot_ClassDB_class_set_property(const godot_ClassDB *self, const godot_Object *object, const godot_StringName *property, const godot_Variant *value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, class_set_property, 1690314931, godot_Error, self, object, property, value)
}
godot_Variant godot_ClassDB_class_get_property_default_value(const godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *property) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, class_get_property_default_value, 2718203076, godot_Variant, self, cls, property)
}
godot_bool godot_ClassDB_class_has_method(const godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *method, godot_bool no_inheritance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, class_has_method, 3860701026, godot_bool, self, cls, method, &no_inheritance)
}
godot_int godot_ClassDB_class_get_method_argument_count(const godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *method, godot_bool no_inheritance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, class_get_method_argument_count, 3885694822, godot_int, self, cls, method, &no_inheritance)
}
godot_TypedArray(godot_Dictionary) godot_ClassDB_class_get_method_list(const godot_ClassDB *self, const godot_StringName *cls, godot_bool no_inheritance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, class_get_method_list, 3504980660, godot_TypedArray(godot_Dictionary), self, cls, &no_inheritance)
}
godot_Variant godot_ClassDB_class_call_static(godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *method, const godot_Variant **argv, godot_int argc) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VARIADIC(ClassDB, class_call_static, 3344196419, godot_Variant, self, cls, method)
}
godot_PackedStringArray godot_ClassDB_class_get_integer_constant_list(const godot_ClassDB *self, const godot_StringName *cls, godot_bool no_inheritance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, class_get_integer_constant_list, 3031669221, godot_PackedStringArray, self, cls, &no_inheritance)
}
godot_bool godot_ClassDB_class_has_integer_constant(const godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, class_has_integer_constant, 471820014, godot_bool, self, cls, name)
}
godot_int godot_ClassDB_class_get_integer_constant(const godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, class_get_integer_constant, 2419549490, godot_int, self, cls, name)
}
godot_bool godot_ClassDB_class_has_enum(const godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *name, godot_bool no_inheritance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, class_has_enum, 3860701026, godot_bool, self, cls, name, &no_inheritance)
}
godot_PackedStringArray godot_ClassDB_class_get_enum_list(const godot_ClassDB *self, const godot_StringName *cls, godot_bool no_inheritance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, class_get_enum_list, 3031669221, godot_PackedStringArray, self, cls, &no_inheritance)
}
godot_PackedStringArray godot_ClassDB_class_get_enum_constants(const godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *enumeration, godot_bool no_inheritance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, class_get_enum_constants, 661528303, godot_PackedStringArray, self, cls, enumeration, &no_inheritance)
}
godot_StringName godot_ClassDB_class_get_integer_constant_enum(const godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *name, godot_bool no_inheritance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, class_get_integer_constant_enum, 2457504236, godot_StringName, self, cls, name, &no_inheritance)
}
godot_bool godot_ClassDB_is_class_enum_bitfield(const godot_ClassDB *self, const godot_StringName *cls, const godot_StringName *enumeration, godot_bool no_inheritance) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, is_class_enum_bitfield, 3860701026, godot_bool, self, cls, enumeration, &no_inheritance)
}
godot_bool godot_ClassDB_is_class_enabled(const godot_ClassDB *self, const godot_StringName *cls) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ClassDB, is_class_enabled, 2619796661, godot_bool, self, cls)
}


#ifdef __cplusplus
}
#endif
