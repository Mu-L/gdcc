// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLOR_RECT_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLOR_RECT_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_ColorRect *godot_new_ColorRect();

// Methods
GDEXTENSION_LITE_DECL void godot_ColorRect_set_color(godot_ColorRect *self, const godot_Color *color);
GDEXTENSION_LITE_DECL godot_Color godot_ColorRect_get_color(const godot_ColorRect *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLOR_RECT_H__
