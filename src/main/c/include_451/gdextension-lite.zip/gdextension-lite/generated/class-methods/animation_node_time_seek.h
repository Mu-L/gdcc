// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_TIME_SEEK_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_TIME_SEEK_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AnimationNodeTimeSeek *godot_new_AnimationNodeTimeSeek();

// Methods
GDEXTENSION_LITE_DECL void godot_AnimationNodeTimeSeek_set_explicit_elapse(godot_AnimationNodeTimeSeek *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNodeTimeSeek_is_explicit_elapse(const godot_AnimationNodeTimeSeek *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_TIME_SEEK_H__
