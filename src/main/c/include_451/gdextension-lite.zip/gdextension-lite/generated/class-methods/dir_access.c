// This file was automatically generated
// Do not modify this file
#include "dir_access.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
godot_DirAccess * godot_DirAccess_open(const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, open, 1923528528, godot_DirAccess *, NULL, path)
}
godot_Error godot_DirAccess_get_open_error() {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, get_open_error, 166280745, godot_Error, NULL)
}
godot_DirAccess * godot_DirAccess_create_temp(const godot_String *prefix, godot_bool keep) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, create_temp, 812913566, godot_DirAccess *, NULL, prefix, &keep)
}
godot_Error godot_DirAccess_list_dir_begin(godot_DirAccess *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, list_dir_begin, 166280745, godot_Error, self)
}
godot_String godot_DirAccess_get_next(godot_DirAccess *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, get_next, 2841200299, godot_String, self)
}
godot_bool godot_DirAccess_current_is_dir(const godot_DirAccess *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, current_is_dir, 36873697, godot_bool, self)
}
void godot_DirAccess_list_dir_end(godot_DirAccess *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DirAccess, list_dir_end, 3218959716, void, self)
}
godot_PackedStringArray godot_DirAccess_get_files(godot_DirAccess *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, get_files, 2981934095, godot_PackedStringArray, self)
}
godot_PackedStringArray godot_DirAccess_get_files_at(const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, get_files_at, 3538744774, godot_PackedStringArray, NULL, path)
}
godot_PackedStringArray godot_DirAccess_get_directories(godot_DirAccess *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, get_directories, 2981934095, godot_PackedStringArray, self)
}
godot_PackedStringArray godot_DirAccess_get_directories_at(const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, get_directories_at, 3538744774, godot_PackedStringArray, NULL, path)
}
godot_int godot_DirAccess_get_drive_count() {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, get_drive_count, 2455072627, godot_int, NULL)
}
godot_String godot_DirAccess_get_drive_name(godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, get_drive_name, 990163283, godot_String, NULL, &idx)
}
godot_int godot_DirAccess_get_current_drive(godot_DirAccess *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, get_current_drive, 2455072627, godot_int, self)
}
godot_Error godot_DirAccess_change_dir(godot_DirAccess *self, const godot_String *to_dir) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, change_dir, 166001499, godot_Error, self, to_dir)
}
godot_String godot_DirAccess_get_current_dir(const godot_DirAccess *self, godot_bool include_drive) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, get_current_dir, 1287308131, godot_String, self, &include_drive)
}
godot_Error godot_DirAccess_make_dir(godot_DirAccess *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, make_dir, 166001499, godot_Error, self, path)
}
godot_Error godot_DirAccess_make_dir_absolute(const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, make_dir_absolute, 166001499, godot_Error, NULL, path)
}
godot_Error godot_DirAccess_make_dir_recursive(godot_DirAccess *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, make_dir_recursive, 166001499, godot_Error, self, path)
}
godot_Error godot_DirAccess_make_dir_recursive_absolute(const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, make_dir_recursive_absolute, 166001499, godot_Error, NULL, path)
}
godot_bool godot_DirAccess_file_exists(godot_DirAccess *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, file_exists, 2323990056, godot_bool, self, path)
}
godot_bool godot_DirAccess_dir_exists(godot_DirAccess *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, dir_exists, 2323990056, godot_bool, self, path)
}
godot_bool godot_DirAccess_dir_exists_absolute(const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, dir_exists_absolute, 2323990056, godot_bool, NULL, path)
}
godot_int godot_DirAccess_get_space_left(godot_DirAccess *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, get_space_left, 2455072627, godot_int, self)
}
godot_Error godot_DirAccess_copy(godot_DirAccess *self, const godot_String *from, const godot_String *to, godot_int chmod_flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, copy, 1063198817, godot_Error, self, from, to, &chmod_flags)
}
godot_Error godot_DirAccess_copy_absolute(const godot_String *from, const godot_String *to, godot_int chmod_flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, copy_absolute, 1063198817, godot_Error, NULL, from, to, &chmod_flags)
}
godot_Error godot_DirAccess_rename(godot_DirAccess *self, const godot_String *from, const godot_String *to) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, rename, 852856452, godot_Error, self, from, to)
}
godot_Error godot_DirAccess_rename_absolute(const godot_String *from, const godot_String *to) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, rename_absolute, 852856452, godot_Error, NULL, from, to)
}
godot_Error godot_DirAccess_remove(godot_DirAccess *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, remove, 166001499, godot_Error, self, path)
}
godot_Error godot_DirAccess_remove_absolute(const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, remove_absolute, 166001499, godot_Error, NULL, path)
}
godot_bool godot_DirAccess_is_link(godot_DirAccess *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, is_link, 2323990056, godot_bool, self, path)
}
godot_String godot_DirAccess_read_link(godot_DirAccess *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, read_link, 1703090593, godot_String, self, path)
}
godot_Error godot_DirAccess_create_link(godot_DirAccess *self, const godot_String *source, const godot_String *target) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, create_link, 852856452, godot_Error, self, source, target)
}
godot_bool godot_DirAccess_is_bundle(const godot_DirAccess *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, is_bundle, 3927539163, godot_bool, self, path)
}
void godot_DirAccess_set_include_navigational(godot_DirAccess *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DirAccess, set_include_navigational, 2586408642, void, self, &enable)
}
godot_bool godot_DirAccess_get_include_navigational(const godot_DirAccess *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, get_include_navigational, 36873697, godot_bool, self)
}
void godot_DirAccess_set_include_hidden(godot_DirAccess *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DirAccess, set_include_hidden, 2586408642, void, self, &enable)
}
godot_bool godot_DirAccess_get_include_hidden(const godot_DirAccess *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, get_include_hidden, 36873697, godot_bool, self)
}
godot_String godot_DirAccess_get_filesystem_type(const godot_DirAccess *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, get_filesystem_type, 201670096, godot_String, self)
}
godot_bool godot_DirAccess_is_case_sensitive(const godot_DirAccess *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, is_case_sensitive, 3927539163, godot_bool, self, path)
}
godot_bool godot_DirAccess_is_equivalent(const godot_DirAccess *self, const godot_String *path_a, const godot_String *path_b) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirAccess, is_equivalent, 820780508, godot_bool, self, path_a, path_b)
}


#ifdef __cplusplus
}
#endif
