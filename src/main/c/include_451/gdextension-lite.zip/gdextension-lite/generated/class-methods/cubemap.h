// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CUBEMAP_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CUBEMAP_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_Cubemap *godot_new_Cubemap();

// Methods
GDEXTENSION_LITE_DECL godot_Resource * godot_Cubemap_create_placeholder(const godot_Cubemap *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CUBEMAP_H__
