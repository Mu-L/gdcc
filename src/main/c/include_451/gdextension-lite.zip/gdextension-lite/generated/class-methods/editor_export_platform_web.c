// This file was automatically generated
// Do not modify this file
#include "editor_export_platform_web.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorExportPlatformWeb *godot_new_EditorExportPlatformWeb() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorExportPlatformWeb);
}


#ifdef __cplusplus
}
#endif
