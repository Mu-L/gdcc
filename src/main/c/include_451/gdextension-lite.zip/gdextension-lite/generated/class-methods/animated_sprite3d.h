// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATED_SPRITE3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATED_SPRITE3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AnimatedSprite3D *godot_new_AnimatedSprite3D();

// Methods
GDEXTENSION_LITE_DECL void godot_AnimatedSprite3D_set_sprite_frames(godot_AnimatedSprite3D *self, const godot_SpriteFrames *sprite_frames);
GDEXTENSION_LITE_DECL godot_SpriteFrames * godot_AnimatedSprite3D_get_sprite_frames(const godot_AnimatedSprite3D *self);
GDEXTENSION_LITE_DECL void godot_AnimatedSprite3D_set_animation(godot_AnimatedSprite3D *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL godot_StringName godot_AnimatedSprite3D_get_animation(const godot_AnimatedSprite3D *self);
GDEXTENSION_LITE_DECL void godot_AnimatedSprite3D_set_autoplay(godot_AnimatedSprite3D *self, const godot_String *name);
GDEXTENSION_LITE_DECL godot_String godot_AnimatedSprite3D_get_autoplay(const godot_AnimatedSprite3D *self);
GDEXTENSION_LITE_DECL godot_bool godot_AnimatedSprite3D_is_playing(const godot_AnimatedSprite3D *self);
GDEXTENSION_LITE_DECL void godot_AnimatedSprite3D_play(godot_AnimatedSprite3D *self, const godot_StringName *name, godot_float custom_speed, godot_bool from_end);
GDEXTENSION_LITE_DECL void godot_AnimatedSprite3D_play_backwards(godot_AnimatedSprite3D *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL void godot_AnimatedSprite3D_pause(godot_AnimatedSprite3D *self);
GDEXTENSION_LITE_DECL void godot_AnimatedSprite3D_stop(godot_AnimatedSprite3D *self);
GDEXTENSION_LITE_DECL void godot_AnimatedSprite3D_set_frame(godot_AnimatedSprite3D *self, godot_int frame);
GDEXTENSION_LITE_DECL godot_int godot_AnimatedSprite3D_get_frame(const godot_AnimatedSprite3D *self);
GDEXTENSION_LITE_DECL void godot_AnimatedSprite3D_set_frame_progress(godot_AnimatedSprite3D *self, godot_float progress);
GDEXTENSION_LITE_DECL godot_float godot_AnimatedSprite3D_get_frame_progress(const godot_AnimatedSprite3D *self);
GDEXTENSION_LITE_DECL void godot_AnimatedSprite3D_set_frame_and_progress(godot_AnimatedSprite3D *self, godot_int frame, godot_float progress);
GDEXTENSION_LITE_DECL void godot_AnimatedSprite3D_set_speed_scale(godot_AnimatedSprite3D *self, godot_float speed_scale);
GDEXTENSION_LITE_DECL godot_float godot_AnimatedSprite3D_get_speed_scale(const godot_AnimatedSprite3D *self);
GDEXTENSION_LITE_DECL godot_float godot_AnimatedSprite3D_get_playing_speed(const godot_AnimatedSprite3D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATED_SPRITE3D_H__
