// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AREA2D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AREA2D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_Area2D *godot_new_Area2D();

// Methods
GDEXTENSION_LITE_DECL void godot_Area2D_set_gravity_space_override_mode(godot_Area2D *self, godot_Area2D_SpaceOverride space_override_mode);
GDEXTENSION_LITE_DECL godot_Area2D_SpaceOverride godot_Area2D_get_gravity_space_override_mode(const godot_Area2D *self);
GDEXTENSION_LITE_DECL void godot_Area2D_set_gravity_is_point(godot_Area2D *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_Area2D_is_gravity_a_point(const godot_Area2D *self);
GDEXTENSION_LITE_DECL void godot_Area2D_set_gravity_point_unit_distance(godot_Area2D *self, godot_float distance_scale);
GDEXTENSION_LITE_DECL godot_float godot_Area2D_get_gravity_point_unit_distance(const godot_Area2D *self);
GDEXTENSION_LITE_DECL void godot_Area2D_set_gravity_point_center(godot_Area2D *self, const godot_Vector2 *center);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Area2D_get_gravity_point_center(const godot_Area2D *self);
GDEXTENSION_LITE_DECL void godot_Area2D_set_gravity_direction(godot_Area2D *self, const godot_Vector2 *direction);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Area2D_get_gravity_direction(const godot_Area2D *self);
GDEXTENSION_LITE_DECL void godot_Area2D_set_gravity(godot_Area2D *self, godot_float gravity);
GDEXTENSION_LITE_DECL godot_float godot_Area2D_get_gravity(const godot_Area2D *self);
GDEXTENSION_LITE_DECL void godot_Area2D_set_linear_damp_space_override_mode(godot_Area2D *self, godot_Area2D_SpaceOverride space_override_mode);
GDEXTENSION_LITE_DECL godot_Area2D_SpaceOverride godot_Area2D_get_linear_damp_space_override_mode(const godot_Area2D *self);
GDEXTENSION_LITE_DECL void godot_Area2D_set_angular_damp_space_override_mode(godot_Area2D *self, godot_Area2D_SpaceOverride space_override_mode);
GDEXTENSION_LITE_DECL godot_Area2D_SpaceOverride godot_Area2D_get_angular_damp_space_override_mode(const godot_Area2D *self);
GDEXTENSION_LITE_DECL void godot_Area2D_set_linear_damp(godot_Area2D *self, godot_float linear_damp);
GDEXTENSION_LITE_DECL godot_float godot_Area2D_get_linear_damp(const godot_Area2D *self);
GDEXTENSION_LITE_DECL void godot_Area2D_set_angular_damp(godot_Area2D *self, godot_float angular_damp);
GDEXTENSION_LITE_DECL godot_float godot_Area2D_get_angular_damp(const godot_Area2D *self);
GDEXTENSION_LITE_DECL void godot_Area2D_set_priority(godot_Area2D *self, godot_int priority);
GDEXTENSION_LITE_DECL godot_int godot_Area2D_get_priority(const godot_Area2D *self);
GDEXTENSION_LITE_DECL void godot_Area2D_set_monitoring(godot_Area2D *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_Area2D_is_monitoring(const godot_Area2D *self);
GDEXTENSION_LITE_DECL void godot_Area2D_set_monitorable(godot_Area2D *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_Area2D_is_monitorable(const godot_Area2D *self);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_Node2D) godot_Area2D_get_overlapping_bodies(const godot_Area2D *self);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_Area2D) godot_Area2D_get_overlapping_areas(const godot_Area2D *self);
GDEXTENSION_LITE_DECL godot_bool godot_Area2D_has_overlapping_bodies(const godot_Area2D *self);
GDEXTENSION_LITE_DECL godot_bool godot_Area2D_has_overlapping_areas(const godot_Area2D *self);
GDEXTENSION_LITE_DECL godot_bool godot_Area2D_overlaps_body(const godot_Area2D *self, const godot_Node *body);
GDEXTENSION_LITE_DECL godot_bool godot_Area2D_overlaps_area(const godot_Area2D *self, const godot_Node *area);
GDEXTENSION_LITE_DECL void godot_Area2D_set_audio_bus_name(godot_Area2D *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL godot_StringName godot_Area2D_get_audio_bus_name(const godot_Area2D *self);
GDEXTENSION_LITE_DECL void godot_Area2D_set_audio_bus_override(godot_Area2D *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_Area2D_is_overriding_audio_bus(const godot_Area2D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AREA2D_H__
