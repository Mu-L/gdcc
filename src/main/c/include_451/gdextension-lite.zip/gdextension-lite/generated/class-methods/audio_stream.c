// This file was automatically generated
// Do not modify this file
#include "audio_stream.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioStream *godot_new_AudioStream() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioStream);
}

// Methods
godot_AudioStreamPlayback * godot_AudioStream__instantiate_playback(const godot_AudioStream *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStream, _instantiate_playback, 3093715447, godot_AudioStreamPlayback *, self)
}
godot_String godot_AudioStream__get_stream_name(const godot_AudioStream *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStream, _get_stream_name, 201670096, godot_String, self)
}
godot_float godot_AudioStream__get_length(const godot_AudioStream *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStream, _get_length, 1740695150, godot_float, self)
}
godot_bool godot_AudioStream__is_monophonic(const godot_AudioStream *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStream, _is_monophonic, 36873697, godot_bool, self)
}
godot_float godot_AudioStream__get_bpm(const godot_AudioStream *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStream, _get_bpm, 1740695150, godot_float, self)
}
godot_int godot_AudioStream__get_beat_count(const godot_AudioStream *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStream, _get_beat_count, 3905245786, godot_int, self)
}
godot_Dictionary godot_AudioStream__get_tags(const godot_AudioStream *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStream, _get_tags, 3102165223, godot_Dictionary, self)
}
godot_TypedArray(godot_Dictionary) godot_AudioStream__get_parameter_list(const godot_AudioStream *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStream, _get_parameter_list, 3995934104, godot_TypedArray(godot_Dictionary), self)
}
godot_bool godot_AudioStream__has_loop(const godot_AudioStream *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStream, _has_loop, 36873697, godot_bool, self)
}
godot_int godot_AudioStream__get_bar_beats(const godot_AudioStream *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStream, _get_bar_beats, 3905245786, godot_int, self)
}
godot_float godot_AudioStream_get_length(const godot_AudioStream *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStream, get_length, 1740695150, godot_float, self)
}
godot_bool godot_AudioStream_is_monophonic(const godot_AudioStream *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStream, is_monophonic, 36873697, godot_bool, self)
}
godot_AudioStreamPlayback * godot_AudioStream_instantiate_playback(godot_AudioStream *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStream, instantiate_playback, 210135309, godot_AudioStreamPlayback *, self)
}
godot_bool godot_AudioStream_can_be_sampled(const godot_AudioStream *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStream, can_be_sampled, 36873697, godot_bool, self)
}
godot_AudioSample * godot_AudioStream_generate_sample(const godot_AudioStream *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStream, generate_sample, 2646048999, godot_AudioSample *, self)
}
godot_bool godot_AudioStream_is_meta_stream(const godot_AudioStream *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStream, is_meta_stream, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
