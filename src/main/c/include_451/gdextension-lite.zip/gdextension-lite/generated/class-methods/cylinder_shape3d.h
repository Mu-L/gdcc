// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CYLINDER_SHAPE3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CYLINDER_SHAPE3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CylinderShape3D *godot_new_CylinderShape3D();

// Methods
GDEXTENSION_LITE_DECL void godot_CylinderShape3D_set_radius(godot_CylinderShape3D *self, godot_float radius);
GDEXTENSION_LITE_DECL godot_float godot_CylinderShape3D_get_radius(const godot_CylinderShape3D *self);
GDEXTENSION_LITE_DECL void godot_CylinderShape3D_set_height(godot_CylinderShape3D *self, godot_float height);
GDEXTENSION_LITE_DECL godot_float godot_CylinderShape3D_get_height(const godot_CylinderShape3D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CYLINDER_SHAPE3D_H__
