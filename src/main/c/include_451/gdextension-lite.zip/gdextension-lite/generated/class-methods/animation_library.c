// This file was automatically generated
// Do not modify this file
#include "animation_library.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimationLibrary *godot_new_AnimationLibrary() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimationLibrary);
}

// Methods
godot_Error godot_AnimationLibrary_add_animation(godot_AnimationLibrary *self, const godot_StringName *name, const godot_Animation *animation) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationLibrary, add_animation, 1811855551, godot_Error, self, name, animation)
}
void godot_AnimationLibrary_remove_animation(godot_AnimationLibrary *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationLibrary, remove_animation, 3304788590, void, self, name)
}
void godot_AnimationLibrary_rename_animation(godot_AnimationLibrary *self, const godot_StringName *name, const godot_StringName *newname) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationLibrary, rename_animation, 3740211285, void, self, name, newname)
}
godot_bool godot_AnimationLibrary_has_animation(const godot_AnimationLibrary *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationLibrary, has_animation, 2619796661, godot_bool, self, name)
}
godot_Animation * godot_AnimationLibrary_get_animation(const godot_AnimationLibrary *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationLibrary, get_animation, 2933122410, godot_Animation *, self, name)
}
godot_TypedArray(godot_StringName) godot_AnimationLibrary_get_animation_list(const godot_AnimationLibrary *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationLibrary, get_animation_list, 3995934104, godot_TypedArray(godot_StringName), self)
}
godot_int godot_AnimationLibrary_get_animation_list_size(const godot_AnimationLibrary *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationLibrary, get_animation_list_size, 3905245786, godot_int, self)
}


#ifdef __cplusplus
}
#endif
