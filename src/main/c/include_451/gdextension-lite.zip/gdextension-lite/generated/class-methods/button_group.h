// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BUTTON_GROUP_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BUTTON_GROUP_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_ButtonGroup *godot_new_ButtonGroup();

// Methods
GDEXTENSION_LITE_DECL godot_BaseButton * godot_ButtonGroup_get_pressed_button(godot_ButtonGroup *self);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_BaseButton) godot_ButtonGroup_get_buttons(godot_ButtonGroup *self);
GDEXTENSION_LITE_DECL void godot_ButtonGroup_set_allow_unpress(godot_ButtonGroup *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_ButtonGroup_is_allow_unpress(godot_ButtonGroup *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BUTTON_GROUP_H__
