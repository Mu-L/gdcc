// This file was automatically generated
// Do not modify this file
#include "audio_stream_interactive.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioStreamInteractive *godot_new_AudioStreamInteractive() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioStreamInteractive);
}

// Methods
void godot_AudioStreamInteractive_set_clip_count(godot_AudioStreamInteractive *self, godot_int clip_count) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamInteractive, set_clip_count, 1286410249, void, self, &clip_count)
}
godot_int godot_AudioStreamInteractive_get_clip_count(const godot_AudioStreamInteractive *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamInteractive, get_clip_count, 3905245786, godot_int, self)
}
void godot_AudioStreamInteractive_set_initial_clip(godot_AudioStreamInteractive *self, godot_int clip_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamInteractive, set_initial_clip, 1286410249, void, self, &clip_index)
}
godot_int godot_AudioStreamInteractive_get_initial_clip(const godot_AudioStreamInteractive *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamInteractive, get_initial_clip, 3905245786, godot_int, self)
}
void godot_AudioStreamInteractive_set_clip_name(godot_AudioStreamInteractive *self, godot_int clip_index, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamInteractive, set_clip_name, 3780747571, void, self, &clip_index, name)
}
godot_StringName godot_AudioStreamInteractive_get_clip_name(const godot_AudioStreamInteractive *self, godot_int clip_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamInteractive, get_clip_name, 659327637, godot_StringName, self, &clip_index)
}
void godot_AudioStreamInteractive_set_clip_stream(godot_AudioStreamInteractive *self, godot_int clip_index, const godot_AudioStream *stream) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamInteractive, set_clip_stream, 111075094, void, self, &clip_index, stream)
}
godot_AudioStream * godot_AudioStreamInteractive_get_clip_stream(const godot_AudioStreamInteractive *self, godot_int clip_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamInteractive, get_clip_stream, 2739380747, godot_AudioStream *, self, &clip_index)
}
void godot_AudioStreamInteractive_set_clip_auto_advance(godot_AudioStreamInteractive *self, godot_int clip_index, godot_AudioStreamInteractive_AutoAdvanceMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamInteractive, set_clip_auto_advance, 57217598, void, self, &clip_index, &mode)
}
godot_AudioStreamInteractive_AutoAdvanceMode godot_AudioStreamInteractive_get_clip_auto_advance(const godot_AudioStreamInteractive *self, godot_int clip_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamInteractive, get_clip_auto_advance, 1778634807, godot_AudioStreamInteractive_AutoAdvanceMode, self, &clip_index)
}
void godot_AudioStreamInteractive_set_clip_auto_advance_next_clip(godot_AudioStreamInteractive *self, godot_int clip_index, godot_int auto_advance_next_clip) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamInteractive, set_clip_auto_advance_next_clip, 3937882851, void, self, &clip_index, &auto_advance_next_clip)
}
godot_int godot_AudioStreamInteractive_get_clip_auto_advance_next_clip(const godot_AudioStreamInteractive *self, godot_int clip_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamInteractive, get_clip_auto_advance_next_clip, 923996154, godot_int, self, &clip_index)
}
void godot_AudioStreamInteractive_add_transition(godot_AudioStreamInteractive *self, godot_int from_clip, godot_int to_clip, godot_AudioStreamInteractive_TransitionFromTime from_time, godot_AudioStreamInteractive_TransitionToTime to_time, godot_AudioStreamInteractive_FadeMode fade_mode, godot_float fade_beats, godot_bool use_filler_clip, godot_int filler_clip, godot_bool hold_previous) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamInteractive, add_transition, 1630280552, void, self, &from_clip, &to_clip, &from_time, &to_time, &fade_mode, &fade_beats, &use_filler_clip, &filler_clip, &hold_previous)
}
godot_bool godot_AudioStreamInteractive_has_transition(const godot_AudioStreamInteractive *self, godot_int from_clip, godot_int to_clip) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamInteractive, has_transition, 2522259332, godot_bool, self, &from_clip, &to_clip)
}
void godot_AudioStreamInteractive_erase_transition(godot_AudioStreamInteractive *self, godot_int from_clip, godot_int to_clip) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamInteractive, erase_transition, 3937882851, void, self, &from_clip, &to_clip)
}
godot_PackedInt32Array godot_AudioStreamInteractive_get_transition_list(const godot_AudioStreamInteractive *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamInteractive, get_transition_list, 1930428628, godot_PackedInt32Array, self)
}
godot_AudioStreamInteractive_TransitionFromTime godot_AudioStreamInteractive_get_transition_from_time(const godot_AudioStreamInteractive *self, godot_int from_clip, godot_int to_clip) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamInteractive, get_transition_from_time, 3453338158, godot_AudioStreamInteractive_TransitionFromTime, self, &from_clip, &to_clip)
}
godot_AudioStreamInteractive_TransitionToTime godot_AudioStreamInteractive_get_transition_to_time(const godot_AudioStreamInteractive *self, godot_int from_clip, godot_int to_clip) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamInteractive, get_transition_to_time, 1369651373, godot_AudioStreamInteractive_TransitionToTime, self, &from_clip, &to_clip)
}
godot_AudioStreamInteractive_FadeMode godot_AudioStreamInteractive_get_transition_fade_mode(const godot_AudioStreamInteractive *self, godot_int from_clip, godot_int to_clip) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamInteractive, get_transition_fade_mode, 4065396087, godot_AudioStreamInteractive_FadeMode, self, &from_clip, &to_clip)
}
godot_float godot_AudioStreamInteractive_get_transition_fade_beats(const godot_AudioStreamInteractive *self, godot_int from_clip, godot_int to_clip) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamInteractive, get_transition_fade_beats, 3085491603, godot_float, self, &from_clip, &to_clip)
}
godot_bool godot_AudioStreamInteractive_is_transition_using_filler_clip(const godot_AudioStreamInteractive *self, godot_int from_clip, godot_int to_clip) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamInteractive, is_transition_using_filler_clip, 2522259332, godot_bool, self, &from_clip, &to_clip)
}
godot_int godot_AudioStreamInteractive_get_transition_filler_clip(const godot_AudioStreamInteractive *self, godot_int from_clip, godot_int to_clip) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamInteractive, get_transition_filler_clip, 3175239445, godot_int, self, &from_clip, &to_clip)
}
godot_bool godot_AudioStreamInteractive_is_transition_holding_previous(const godot_AudioStreamInteractive *self, godot_int from_clip, godot_int to_clip) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamInteractive, is_transition_holding_previous, 2522259332, godot_bool, self, &from_clip, &to_clip)
}


#ifdef __cplusplus
}
#endif
