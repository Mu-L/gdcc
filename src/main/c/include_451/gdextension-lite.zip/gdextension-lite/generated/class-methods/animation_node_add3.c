// This file was automatically generated
// Do not modify this file
#include "animation_node_add3.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimationNodeAdd3 *godot_new_AnimationNodeAdd3() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimationNodeAdd3);
}


#ifdef __cplusplus
}
#endif
