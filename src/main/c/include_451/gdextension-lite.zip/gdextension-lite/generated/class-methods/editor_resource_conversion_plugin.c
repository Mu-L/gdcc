// This file was automatically generated
// Do not modify this file
#include "editor_resource_conversion_plugin.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorResourceConversionPlugin *godot_new_EditorResourceConversionPlugin() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorResourceConversionPlugin);
}

// Methods
godot_String godot_EditorResourceConversionPlugin__converts_to(const godot_EditorResourceConversionPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorResourceConversionPlugin, _converts_to, 201670096, godot_String, self)
}
godot_bool godot_EditorResourceConversionPlugin__handles(const godot_EditorResourceConversionPlugin *self, const godot_Resource *resource) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorResourceConversionPlugin, _handles, 3190994482, godot_bool, self, resource)
}
godot_Resource * godot_EditorResourceConversionPlugin__convert(const godot_EditorResourceConversionPlugin *self, const godot_Resource *resource) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorResourceConversionPlugin, _convert, 325183270, godot_Resource *, self, resource)
}


#ifdef __cplusplus
}
#endif
