// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_SCENE_POST_IMPORT_PLUGIN_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_SCENE_POST_IMPORT_PLUGIN_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorScenePostImportPlugin *godot_new_EditorScenePostImportPlugin();

// Methods
GDEXTENSION_LITE_DECL void godot_EditorScenePostImportPlugin__get_internal_import_options(godot_EditorScenePostImportPlugin *self, godot_int category);
GDEXTENSION_LITE_DECL godot_Variant godot_EditorScenePostImportPlugin__get_internal_option_visibility(const godot_EditorScenePostImportPlugin *self, godot_int category, godot_bool for_animation, const godot_String *option);
GDEXTENSION_LITE_DECL godot_Variant godot_EditorScenePostImportPlugin__get_internal_option_update_view_required(const godot_EditorScenePostImportPlugin *self, godot_int category, const godot_String *option);
GDEXTENSION_LITE_DECL void godot_EditorScenePostImportPlugin__internal_process(godot_EditorScenePostImportPlugin *self, godot_int category, const godot_Node *base_node, const godot_Node *node, const godot_Resource *resource);
GDEXTENSION_LITE_DECL void godot_EditorScenePostImportPlugin__get_import_options(godot_EditorScenePostImportPlugin *self, const godot_String *path);
GDEXTENSION_LITE_DECL godot_Variant godot_EditorScenePostImportPlugin__get_option_visibility(const godot_EditorScenePostImportPlugin *self, const godot_String *path, godot_bool for_animation, const godot_String *option);
GDEXTENSION_LITE_DECL void godot_EditorScenePostImportPlugin__pre_process(godot_EditorScenePostImportPlugin *self, const godot_Node *scene);
GDEXTENSION_LITE_DECL void godot_EditorScenePostImportPlugin__post_process(godot_EditorScenePostImportPlugin *self, const godot_Node *scene);
GDEXTENSION_LITE_DECL godot_Variant godot_EditorScenePostImportPlugin_get_option_value(const godot_EditorScenePostImportPlugin *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL void godot_EditorScenePostImportPlugin_add_import_option(godot_EditorScenePostImportPlugin *self, const godot_String *name, const godot_Variant *value);
GDEXTENSION_LITE_DECL void godot_EditorScenePostImportPlugin_add_import_option_advanced(godot_EditorScenePostImportPlugin *self, godot_Variant_Type type, const godot_String *name, const godot_Variant *default_value, godot_PropertyHint hint, const godot_String *hint_string, godot_int usage_flags);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_SCENE_POST_IMPORT_PLUGIN_H__
