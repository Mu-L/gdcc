// This file was automatically generated
// Do not modify this file
#include "crypto.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_Crypto *godot_new_Crypto() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(Crypto);
}

// Methods
godot_PackedByteArray godot_Crypto_generate_random_bytes(godot_Crypto *self, godot_int size) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Crypto, generate_random_bytes, 47165747, godot_PackedByteArray, self, &size)
}
godot_CryptoKey * godot_Crypto_generate_rsa(godot_Crypto *self, godot_int size) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Crypto, generate_rsa, 1237515462, godot_CryptoKey *, self, &size)
}
godot_X509Certificate * godot_Crypto_generate_self_signed_certificate(godot_Crypto *self, const godot_CryptoKey *key, const godot_String *issuer_name, const godot_String *not_before, const godot_String *not_after) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Crypto, generate_self_signed_certificate, 492266173, godot_X509Certificate *, self, key, issuer_name, not_before, not_after)
}
godot_PackedByteArray godot_Crypto_sign(godot_Crypto *self, godot_HashingContext_HashType hash_type, const godot_PackedByteArray *hash, const godot_CryptoKey *key) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Crypto, sign, 1673662703, godot_PackedByteArray, self, &hash_type, hash, key)
}
godot_bool godot_Crypto_verify(godot_Crypto *self, godot_HashingContext_HashType hash_type, const godot_PackedByteArray *hash, const godot_PackedByteArray *signature, const godot_CryptoKey *key) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Crypto, verify, 2805902225, godot_bool, self, &hash_type, hash, signature, key)
}
godot_PackedByteArray godot_Crypto_encrypt(godot_Crypto *self, const godot_CryptoKey *key, const godot_PackedByteArray *plaintext) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Crypto, encrypt, 2361793670, godot_PackedByteArray, self, key, plaintext)
}
godot_PackedByteArray godot_Crypto_decrypt(godot_Crypto *self, const godot_CryptoKey *key, const godot_PackedByteArray *ciphertext) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Crypto, decrypt, 2361793670, godot_PackedByteArray, self, key, ciphertext)
}
godot_PackedByteArray godot_Crypto_hmac_digest(godot_Crypto *self, godot_HashingContext_HashType hash_type, const godot_PackedByteArray *key, const godot_PackedByteArray *msg) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Crypto, hmac_digest, 2368951203, godot_PackedByteArray, self, &hash_type, key, msg)
}
godot_bool godot_Crypto_constant_time_compare(godot_Crypto *self, const godot_PackedByteArray *trusted, const godot_PackedByteArray *received) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Crypto, constant_time_compare, 1024142237, godot_bool, self, trusted, received)
}


#ifdef __cplusplus
}
#endif
