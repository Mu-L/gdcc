// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_REVERB_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_REVERB_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioEffectReverb *godot_new_AudioEffectReverb();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioEffectReverb_set_predelay_msec(godot_AudioEffectReverb *self, godot_float msec);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectReverb_get_predelay_msec(const godot_AudioEffectReverb *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectReverb_set_predelay_feedback(godot_AudioEffectReverb *self, godot_float feedback);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectReverb_get_predelay_feedback(const godot_AudioEffectReverb *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectReverb_set_room_size(godot_AudioEffectReverb *self, godot_float size);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectReverb_get_room_size(const godot_AudioEffectReverb *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectReverb_set_damping(godot_AudioEffectReverb *self, godot_float amount);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectReverb_get_damping(const godot_AudioEffectReverb *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectReverb_set_spread(godot_AudioEffectReverb *self, godot_float amount);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectReverb_get_spread(const godot_AudioEffectReverb *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectReverb_set_dry(godot_AudioEffectReverb *self, godot_float amount);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectReverb_get_dry(const godot_AudioEffectReverb *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectReverb_set_wet(godot_AudioEffectReverb *self, godot_float amount);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectReverb_get_wet(const godot_AudioEffectReverb *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectReverb_set_hpf(godot_AudioEffectReverb *self, godot_float amount);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectReverb_get_hpf(const godot_AudioEffectReverb *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_REVERB_H__
