// This file was automatically generated
// Do not modify this file
#include "check_box.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CheckBox *godot_new_CheckBox() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CheckBox);
}


#ifdef __cplusplus
}
#endif
