// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_DTLSSERVER_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_DTLSSERVER_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_DTLSServer *godot_new_DTLSServer();

// Methods
GDEXTENSION_LITE_DECL godot_Error godot_DTLSServer_setup(godot_DTLSServer *self, const godot_TLSOptions *server_options);
GDEXTENSION_LITE_DECL godot_PacketPeerDTLS * godot_DTLSServer_take_connection(godot_DTLSServer *self, const godot_PacketPeerUDP *udp_peer);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_DTLSSERVER_H__
