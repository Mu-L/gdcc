// This file was automatically generated
// Do not modify this file
#include "animation_node_sync.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimationNodeSync *godot_new_AnimationNodeSync() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimationNodeSync);
}

// Methods
void godot_AnimationNodeSync_set_use_sync(godot_AnimationNodeSync *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeSync, set_use_sync, 2586408642, void, self, &enable)
}
godot_bool godot_AnimationNodeSync_is_using_sync(const godot_AnimationNodeSync *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeSync, is_using_sync, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
