// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_PLAYBACK_POLYPHONIC_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_PLAYBACK_POLYPHONIC_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
GDEXTENSION_LITE_DECL godot_int godot_AudioStreamPlaybackPolyphonic_play_stream(godot_AudioStreamPlaybackPolyphonic *self, const godot_AudioStream *stream, godot_float from_offset, godot_float volume_db, godot_float pitch_scale, godot_AudioServer_PlaybackType playback_type, const godot_StringName *bus);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlaybackPolyphonic_set_stream_volume(godot_AudioStreamPlaybackPolyphonic *self, godot_int stream, godot_float volume_db);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlaybackPolyphonic_set_stream_pitch_scale(godot_AudioStreamPlaybackPolyphonic *self, godot_int stream, godot_float pitch_scale);
GDEXTENSION_LITE_DECL godot_bool godot_AudioStreamPlaybackPolyphonic_is_stream_playing(const godot_AudioStreamPlaybackPolyphonic *self, godot_int stream);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlaybackPolyphonic_stop_stream(godot_AudioStreamPlaybackPolyphonic *self, godot_int stream);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_PLAYBACK_POLYPHONIC_H__
