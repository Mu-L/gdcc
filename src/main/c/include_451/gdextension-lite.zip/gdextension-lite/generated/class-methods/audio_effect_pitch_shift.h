// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_PITCH_SHIFT_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_PITCH_SHIFT_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioEffectPitchShift *godot_new_AudioEffectPitchShift();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioEffectPitchShift_set_pitch_scale(godot_AudioEffectPitchShift *self, godot_float rate);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectPitchShift_get_pitch_scale(const godot_AudioEffectPitchShift *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectPitchShift_set_oversampling(godot_AudioEffectPitchShift *self, godot_int amount);
GDEXTENSION_LITE_DECL godot_int godot_AudioEffectPitchShift_get_oversampling(const godot_AudioEffectPitchShift *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectPitchShift_set_fft_size(godot_AudioEffectPitchShift *self, godot_AudioEffectPitchShift_FFTSize size);
GDEXTENSION_LITE_DECL godot_AudioEffectPitchShift_FFTSize godot_AudioEffectPitchShift_get_fft_size(const godot_AudioEffectPitchShift *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_PITCH_SHIFT_H__
