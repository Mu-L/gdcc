// This file was automatically generated
// Do not modify this file
#include "canvas_item.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
void godot_CanvasItem__draw(godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, _draw, 3218959716, void, self)
}
godot_RID godot_CanvasItem_get_canvas_item(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_canvas_item, 2944877500, godot_RID, self)
}
void godot_CanvasItem_set_visible(godot_CanvasItem *self, godot_bool visible) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, set_visible, 2586408642, void, self, &visible)
}
godot_bool godot_CanvasItem_is_visible(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, is_visible, 36873697, godot_bool, self)
}
godot_bool godot_CanvasItem_is_visible_in_tree(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, is_visible_in_tree, 36873697, godot_bool, self)
}
void godot_CanvasItem_show(godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, show, 3218959716, void, self)
}
void godot_CanvasItem_hide(godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, hide, 3218959716, void, self)
}
void godot_CanvasItem_queue_redraw(godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, queue_redraw, 3218959716, void, self)
}
void godot_CanvasItem_move_to_front(godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, move_to_front, 3218959716, void, self)
}
void godot_CanvasItem_set_as_top_level(godot_CanvasItem *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, set_as_top_level, 2586408642, void, self, &enable)
}
godot_bool godot_CanvasItem_is_set_as_top_level(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, is_set_as_top_level, 36873697, godot_bool, self)
}
void godot_CanvasItem_set_light_mask(godot_CanvasItem *self, godot_int light_mask) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, set_light_mask, 1286410249, void, self, &light_mask)
}
godot_int godot_CanvasItem_get_light_mask(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_light_mask, 3905245786, godot_int, self)
}
void godot_CanvasItem_set_modulate(godot_CanvasItem *self, const godot_Color *modulate) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, set_modulate, 2920490490, void, self, modulate)
}
godot_Color godot_CanvasItem_get_modulate(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_modulate, 3444240500, godot_Color, self)
}
void godot_CanvasItem_set_self_modulate(godot_CanvasItem *self, const godot_Color *self_modulate) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, set_self_modulate, 2920490490, void, self, self_modulate)
}
godot_Color godot_CanvasItem_get_self_modulate(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_self_modulate, 3444240500, godot_Color, self)
}
void godot_CanvasItem_set_z_index(godot_CanvasItem *self, godot_int z_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, set_z_index, 1286410249, void, self, &z_index)
}
godot_int godot_CanvasItem_get_z_index(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_z_index, 3905245786, godot_int, self)
}
void godot_CanvasItem_set_z_as_relative(godot_CanvasItem *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, set_z_as_relative, 2586408642, void, self, &enable)
}
godot_bool godot_CanvasItem_is_z_relative(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, is_z_relative, 36873697, godot_bool, self)
}
void godot_CanvasItem_set_y_sort_enabled(godot_CanvasItem *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, set_y_sort_enabled, 2586408642, void, self, &enabled)
}
godot_bool godot_CanvasItem_is_y_sort_enabled(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, is_y_sort_enabled, 36873697, godot_bool, self)
}
void godot_CanvasItem_set_draw_behind_parent(godot_CanvasItem *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, set_draw_behind_parent, 2586408642, void, self, &enable)
}
godot_bool godot_CanvasItem_is_draw_behind_parent_enabled(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, is_draw_behind_parent_enabled, 36873697, godot_bool, self)
}
void godot_CanvasItem_draw_line(godot_CanvasItem *self, const godot_Vector2 *from, const godot_Vector2 *to, const godot_Color *color, godot_float width, godot_bool antialiased) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_line, 1562330099, void, self, from, to, color, &width, &antialiased)
}
void godot_CanvasItem_draw_dashed_line(godot_CanvasItem *self, const godot_Vector2 *from, const godot_Vector2 *to, const godot_Color *color, godot_float width, godot_float dash, godot_bool aligned, godot_bool antialiased) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_dashed_line, 3653831622, void, self, from, to, color, &width, &dash, &aligned, &antialiased)
}
void godot_CanvasItem_draw_polyline(godot_CanvasItem *self, const godot_PackedVector2Array *points, const godot_Color *color, godot_float width, godot_bool antialiased) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_polyline, 3797364428, void, self, points, color, &width, &antialiased)
}
void godot_CanvasItem_draw_polyline_colors(godot_CanvasItem *self, const godot_PackedVector2Array *points, const godot_PackedColorArray *colors, godot_float width, godot_bool antialiased) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_polyline_colors, 2311979562, void, self, points, colors, &width, &antialiased)
}
void godot_CanvasItem_draw_arc(godot_CanvasItem *self, const godot_Vector2 *center, godot_float radius, godot_float start_angle, godot_float end_angle, godot_int point_count, const godot_Color *color, godot_float width, godot_bool antialiased) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_arc, 4140652635, void, self, center, &radius, &start_angle, &end_angle, &point_count, color, &width, &antialiased)
}
void godot_CanvasItem_draw_multiline(godot_CanvasItem *self, const godot_PackedVector2Array *points, const godot_Color *color, godot_float width, godot_bool antialiased) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_multiline, 3797364428, void, self, points, color, &width, &antialiased)
}
void godot_CanvasItem_draw_multiline_colors(godot_CanvasItem *self, const godot_PackedVector2Array *points, const godot_PackedColorArray *colors, godot_float width, godot_bool antialiased) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_multiline_colors, 2311979562, void, self, points, colors, &width, &antialiased)
}
void godot_CanvasItem_draw_rect(godot_CanvasItem *self, const godot_Rect2 *rect, const godot_Color *color, godot_bool filled, godot_float width, godot_bool antialiased) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_rect, 2773573813, void, self, rect, color, &filled, &width, &antialiased)
}
void godot_CanvasItem_draw_circle(godot_CanvasItem *self, const godot_Vector2 *position, godot_float radius, const godot_Color *color, godot_bool filled, godot_float width, godot_bool antialiased) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_circle, 3153026596, void, self, position, &radius, color, &filled, &width, &antialiased)
}
void godot_CanvasItem_draw_texture(godot_CanvasItem *self, const godot_Texture2D *texture, const godot_Vector2 *position, const godot_Color *modulate) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_texture, 520200117, void, self, texture, position, modulate)
}
void godot_CanvasItem_draw_texture_rect(godot_CanvasItem *self, const godot_Texture2D *texture, const godot_Rect2 *rect, godot_bool tile, const godot_Color *modulate, godot_bool transpose) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_texture_rect, 3832805018, void, self, texture, rect, &tile, modulate, &transpose)
}
void godot_CanvasItem_draw_texture_rect_region(godot_CanvasItem *self, const godot_Texture2D *texture, const godot_Rect2 *rect, const godot_Rect2 *src_rect, const godot_Color *modulate, godot_bool transpose, godot_bool clip_uv) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_texture_rect_region, 3883821411, void, self, texture, rect, src_rect, modulate, &transpose, &clip_uv)
}
void godot_CanvasItem_draw_msdf_texture_rect_region(godot_CanvasItem *self, const godot_Texture2D *texture, const godot_Rect2 *rect, const godot_Rect2 *src_rect, const godot_Color *modulate, godot_float outline, godot_float pixel_range, godot_float scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_msdf_texture_rect_region, 4219163252, void, self, texture, rect, src_rect, modulate, &outline, &pixel_range, &scale)
}
void godot_CanvasItem_draw_lcd_texture_rect_region(godot_CanvasItem *self, const godot_Texture2D *texture, const godot_Rect2 *rect, const godot_Rect2 *src_rect, const godot_Color *modulate) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_lcd_texture_rect_region, 3212350954, void, self, texture, rect, src_rect, modulate)
}
void godot_CanvasItem_draw_style_box(godot_CanvasItem *self, const godot_StyleBox *style_box, const godot_Rect2 *rect) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_style_box, 388176283, void, self, style_box, rect)
}
void godot_CanvasItem_draw_primitive(godot_CanvasItem *self, const godot_PackedVector2Array *points, const godot_PackedColorArray *colors, const godot_PackedVector2Array *uvs, const godot_Texture2D *texture) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_primitive, 3288481815, void, self, points, colors, uvs, texture)
}
void godot_CanvasItem_draw_polygon(godot_CanvasItem *self, const godot_PackedVector2Array *points, const godot_PackedColorArray *colors, const godot_PackedVector2Array *uvs, const godot_Texture2D *texture) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_polygon, 974537912, void, self, points, colors, uvs, texture)
}
void godot_CanvasItem_draw_colored_polygon(godot_CanvasItem *self, const godot_PackedVector2Array *points, const godot_Color *color, const godot_PackedVector2Array *uvs, const godot_Texture2D *texture) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_colored_polygon, 15245644, void, self, points, color, uvs, texture)
}
void godot_CanvasItem_draw_string(const godot_CanvasItem *self, const godot_Font *font, const godot_Vector2 *pos, const godot_String *text, godot_HorizontalAlignment alignment, godot_float width, godot_int font_size, const godot_Color *modulate, const godot_TextServer_JustificationFlag *justification_flags, godot_TextServer_Direction direction, godot_TextServer_Orientation orientation, godot_float oversampling) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_string, 719605945, void, self, font, pos, text, &alignment, &width, &font_size, modulate, justification_flags, &direction, &orientation, &oversampling)
}
void godot_CanvasItem_draw_multiline_string(const godot_CanvasItem *self, const godot_Font *font, const godot_Vector2 *pos, const godot_String *text, godot_HorizontalAlignment alignment, godot_float width, godot_int font_size, godot_int max_lines, const godot_Color *modulate, const godot_TextServer_LineBreakFlag *brk_flags, const godot_TextServer_JustificationFlag *justification_flags, godot_TextServer_Direction direction, godot_TextServer_Orientation orientation, godot_float oversampling) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_multiline_string, 2341488182, void, self, font, pos, text, &alignment, &width, &font_size, &max_lines, modulate, brk_flags, justification_flags, &direction, &orientation, &oversampling)
}
void godot_CanvasItem_draw_string_outline(const godot_CanvasItem *self, const godot_Font *font, const godot_Vector2 *pos, const godot_String *text, godot_HorizontalAlignment alignment, godot_float width, godot_int font_size, godot_int size, const godot_Color *modulate, const godot_TextServer_JustificationFlag *justification_flags, godot_TextServer_Direction direction, godot_TextServer_Orientation orientation, godot_float oversampling) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_string_outline, 707403449, void, self, font, pos, text, &alignment, &width, &font_size, &size, modulate, justification_flags, &direction, &orientation, &oversampling)
}
void godot_CanvasItem_draw_multiline_string_outline(const godot_CanvasItem *self, const godot_Font *font, const godot_Vector2 *pos, const godot_String *text, godot_HorizontalAlignment alignment, godot_float width, godot_int font_size, godot_int max_lines, godot_int size, const godot_Color *modulate, const godot_TextServer_LineBreakFlag *brk_flags, const godot_TextServer_JustificationFlag *justification_flags, godot_TextServer_Direction direction, godot_TextServer_Orientation orientation, godot_float oversampling) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_multiline_string_outline, 3050414441, void, self, font, pos, text, &alignment, &width, &font_size, &max_lines, &size, modulate, brk_flags, justification_flags, &direction, &orientation, &oversampling)
}
void godot_CanvasItem_draw_char(const godot_CanvasItem *self, const godot_Font *font, const godot_Vector2 *pos, const godot_String *chr, godot_int font_size, const godot_Color *modulate, godot_float oversampling) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_char, 1336210142, void, self, font, pos, chr, &font_size, modulate, &oversampling)
}
void godot_CanvasItem_draw_char_outline(const godot_CanvasItem *self, const godot_Font *font, const godot_Vector2 *pos, const godot_String *chr, godot_int font_size, godot_int size, const godot_Color *modulate, godot_float oversampling) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_char_outline, 1846384149, void, self, font, pos, chr, &font_size, &size, modulate, &oversampling)
}
void godot_CanvasItem_draw_mesh(godot_CanvasItem *self, const godot_Mesh *mesh, const godot_Texture2D *texture, const godot_Transform2D *transform, const godot_Color *modulate) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_mesh, 153818295, void, self, mesh, texture, transform, modulate)
}
void godot_CanvasItem_draw_multimesh(godot_CanvasItem *self, const godot_MultiMesh *multimesh, const godot_Texture2D *texture) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_multimesh, 937992368, void, self, multimesh, texture)
}
void godot_CanvasItem_draw_set_transform(godot_CanvasItem *self, const godot_Vector2 *position, godot_float rotation, const godot_Vector2 *scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_set_transform, 288975085, void, self, position, &rotation, scale)
}
void godot_CanvasItem_draw_set_transform_matrix(godot_CanvasItem *self, const godot_Transform2D *xform) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_set_transform_matrix, 2761652528, void, self, xform)
}
void godot_CanvasItem_draw_animation_slice(godot_CanvasItem *self, godot_float animation_length, godot_float slice_begin, godot_float slice_end, godot_float offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_animation_slice, 3112831842, void, self, &animation_length, &slice_begin, &slice_end, &offset)
}
void godot_CanvasItem_draw_end_animation(godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, draw_end_animation, 3218959716, void, self)
}
godot_Transform2D godot_CanvasItem_get_transform(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_transform, 3814499831, godot_Transform2D, self)
}
godot_Transform2D godot_CanvasItem_get_global_transform(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_global_transform, 3814499831, godot_Transform2D, self)
}
godot_Transform2D godot_CanvasItem_get_global_transform_with_canvas(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_global_transform_with_canvas, 3814499831, godot_Transform2D, self)
}
godot_Transform2D godot_CanvasItem_get_viewport_transform(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_viewport_transform, 3814499831, godot_Transform2D, self)
}
godot_Rect2 godot_CanvasItem_get_viewport_rect(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_viewport_rect, 1639390495, godot_Rect2, self)
}
godot_Transform2D godot_CanvasItem_get_canvas_transform(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_canvas_transform, 3814499831, godot_Transform2D, self)
}
godot_Transform2D godot_CanvasItem_get_screen_transform(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_screen_transform, 3814499831, godot_Transform2D, self)
}
godot_Vector2 godot_CanvasItem_get_local_mouse_position(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_local_mouse_position, 3341600327, godot_Vector2, self)
}
godot_Vector2 godot_CanvasItem_get_global_mouse_position(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_global_mouse_position, 3341600327, godot_Vector2, self)
}
godot_RID godot_CanvasItem_get_canvas(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_canvas, 2944877500, godot_RID, self)
}
godot_CanvasLayer * godot_CanvasItem_get_canvas_layer_node(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_canvas_layer_node, 2602762519, godot_CanvasLayer *, self)
}
godot_World2D * godot_CanvasItem_get_world_2d(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_world_2d, 2339128592, godot_World2D *, self)
}
void godot_CanvasItem_set_material(godot_CanvasItem *self, const godot_Material *material) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, set_material, 2757459619, void, self, material)
}
godot_Material * godot_CanvasItem_get_material(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_material, 5934680, godot_Material *, self)
}
void godot_CanvasItem_set_instance_shader_parameter(godot_CanvasItem *self, const godot_StringName *name, const godot_Variant *value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, set_instance_shader_parameter, 3776071444, void, self, name, value)
}
godot_Variant godot_CanvasItem_get_instance_shader_parameter(const godot_CanvasItem *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_instance_shader_parameter, 2760726917, godot_Variant, self, name)
}
void godot_CanvasItem_set_use_parent_material(godot_CanvasItem *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, set_use_parent_material, 2586408642, void, self, &enable)
}
godot_bool godot_CanvasItem_get_use_parent_material(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_use_parent_material, 36873697, godot_bool, self)
}
void godot_CanvasItem_set_notify_local_transform(godot_CanvasItem *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, set_notify_local_transform, 2586408642, void, self, &enable)
}
godot_bool godot_CanvasItem_is_local_transform_notification_enabled(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, is_local_transform_notification_enabled, 36873697, godot_bool, self)
}
void godot_CanvasItem_set_notify_transform(godot_CanvasItem *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, set_notify_transform, 2586408642, void, self, &enable)
}
godot_bool godot_CanvasItem_is_transform_notification_enabled(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, is_transform_notification_enabled, 36873697, godot_bool, self)
}
void godot_CanvasItem_force_update_transform(godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, force_update_transform, 3218959716, void, self)
}
godot_Vector2 godot_CanvasItem_make_canvas_position_local(const godot_CanvasItem *self, const godot_Vector2 *viewport_point) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, make_canvas_position_local, 2656412154, godot_Vector2, self, viewport_point)
}
godot_InputEvent * godot_CanvasItem_make_input_local(const godot_CanvasItem *self, const godot_InputEvent *event) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, make_input_local, 811130057, godot_InputEvent *, self, event)
}
void godot_CanvasItem_set_visibility_layer(godot_CanvasItem *self, godot_int layer) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, set_visibility_layer, 1286410249, void, self, &layer)
}
godot_int godot_CanvasItem_get_visibility_layer(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_visibility_layer, 3905245786, godot_int, self)
}
void godot_CanvasItem_set_visibility_layer_bit(godot_CanvasItem *self, godot_int layer, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, set_visibility_layer_bit, 300928843, void, self, &layer, &enabled)
}
godot_bool godot_CanvasItem_get_visibility_layer_bit(const godot_CanvasItem *self, godot_int layer) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_visibility_layer_bit, 1116898809, godot_bool, self, &layer)
}
void godot_CanvasItem_set_texture_filter(godot_CanvasItem *self, godot_CanvasItem_TextureFilter mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, set_texture_filter, 1037999706, void, self, &mode)
}
godot_CanvasItem_TextureFilter godot_CanvasItem_get_texture_filter(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_texture_filter, 121960042, godot_CanvasItem_TextureFilter, self)
}
void godot_CanvasItem_set_texture_repeat(godot_CanvasItem *self, godot_CanvasItem_TextureRepeat mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, set_texture_repeat, 1716472974, void, self, &mode)
}
godot_CanvasItem_TextureRepeat godot_CanvasItem_get_texture_repeat(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_texture_repeat, 2667158319, godot_CanvasItem_TextureRepeat, self)
}
void godot_CanvasItem_set_clip_children_mode(godot_CanvasItem *self, godot_CanvasItem_ClipChildrenMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasItem, set_clip_children_mode, 1319393776, void, self, &mode)
}
godot_CanvasItem_ClipChildrenMode godot_CanvasItem_get_clip_children_mode(const godot_CanvasItem *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasItem, get_clip_children_mode, 3581808349, godot_CanvasItem_ClipChildrenMode, self)
}


#ifdef __cplusplus
}
#endif
