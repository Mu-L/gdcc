// This file was automatically generated
// Do not modify this file
#include "audio_stream_microphone.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioStreamMicrophone *godot_new_AudioStreamMicrophone() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioStreamMicrophone);
}


#ifdef __cplusplus
}
#endif
