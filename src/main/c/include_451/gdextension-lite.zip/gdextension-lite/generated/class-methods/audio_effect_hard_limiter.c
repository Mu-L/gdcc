// This file was automatically generated
// Do not modify this file
#include "audio_effect_hard_limiter.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectHardLimiter *godot_new_AudioEffectHardLimiter() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectHardLimiter);
}

// Methods
void godot_AudioEffectHardLimiter_set_ceiling_db(godot_AudioEffectHardLimiter *self, godot_float ceiling) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectHardLimiter, set_ceiling_db, 373806689, void, self, &ceiling)
}
godot_float godot_AudioEffectHardLimiter_get_ceiling_db(const godot_AudioEffectHardLimiter *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectHardLimiter, get_ceiling_db, 1740695150, godot_float, self)
}
void godot_AudioEffectHardLimiter_set_pre_gain_db(godot_AudioEffectHardLimiter *self, godot_float p_pre_gain) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectHardLimiter, set_pre_gain_db, 373806689, void, self, &p_pre_gain)
}
godot_float godot_AudioEffectHardLimiter_get_pre_gain_db(const godot_AudioEffectHardLimiter *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectHardLimiter, get_pre_gain_db, 1740695150, godot_float, self)
}
void godot_AudioEffectHardLimiter_set_release(godot_AudioEffectHardLimiter *self, godot_float p_release) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectHardLimiter, set_release, 373806689, void, self, &p_release)
}
godot_float godot_AudioEffectHardLimiter_get_release(const godot_AudioEffectHardLimiter *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectHardLimiter, get_release, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
