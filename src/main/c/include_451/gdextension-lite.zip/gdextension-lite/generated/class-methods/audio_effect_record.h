// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_RECORD_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_RECORD_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioEffectRecord *godot_new_AudioEffectRecord();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioEffectRecord_set_recording_active(godot_AudioEffectRecord *self, godot_bool record);
GDEXTENSION_LITE_DECL godot_bool godot_AudioEffectRecord_is_recording_active(const godot_AudioEffectRecord *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectRecord_set_format(godot_AudioEffectRecord *self, godot_AudioStreamWAV_Format format);
GDEXTENSION_LITE_DECL godot_AudioStreamWAV_Format godot_AudioEffectRecord_get_format(const godot_AudioEffectRecord *self);
GDEXTENSION_LITE_DECL godot_AudioStreamWAV * godot_AudioEffectRecord_get_recording(const godot_AudioEffectRecord *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_RECORD_H__
