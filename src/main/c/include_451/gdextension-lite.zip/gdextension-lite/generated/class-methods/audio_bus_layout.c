// This file was automatically generated
// Do not modify this file
#include "audio_bus_layout.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioBusLayout *godot_new_AudioBusLayout() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioBusLayout);
}


#ifdef __cplusplus
}
#endif
