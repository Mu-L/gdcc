// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_RESOURCE_CONVERSION_PLUGIN_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_RESOURCE_CONVERSION_PLUGIN_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorResourceConversionPlugin *godot_new_EditorResourceConversionPlugin();

// Methods
GDEXTENSION_LITE_DECL godot_String godot_EditorResourceConversionPlugin__converts_to(const godot_EditorResourceConversionPlugin *self);
GDEXTENSION_LITE_DECL godot_bool godot_EditorResourceConversionPlugin__handles(const godot_EditorResourceConversionPlugin *self, const godot_Resource *resource);
GDEXTENSION_LITE_DECL godot_Resource * godot_EditorResourceConversionPlugin__convert(const godot_EditorResourceConversionPlugin *self, const godot_Resource *resource);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_RESOURCE_CONVERSION_PLUGIN_H__
