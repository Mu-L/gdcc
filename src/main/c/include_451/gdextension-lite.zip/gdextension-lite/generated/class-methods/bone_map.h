// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BONE_MAP_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BONE_MAP_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_BoneMap *godot_new_BoneMap();

// Methods
GDEXTENSION_LITE_DECL godot_SkeletonProfile * godot_BoneMap_get_profile(const godot_BoneMap *self);
GDEXTENSION_LITE_DECL void godot_BoneMap_set_profile(godot_BoneMap *self, const godot_SkeletonProfile *profile);
GDEXTENSION_LITE_DECL godot_StringName godot_BoneMap_get_skeleton_bone_name(const godot_BoneMap *self, const godot_StringName *profile_bone_name);
GDEXTENSION_LITE_DECL void godot_BoneMap_set_skeleton_bone_name(godot_BoneMap *self, const godot_StringName *profile_bone_name, const godot_StringName *skeleton_bone_name);
GDEXTENSION_LITE_DECL godot_StringName godot_BoneMap_find_profile_bone_name(const godot_BoneMap *self, const godot_StringName *skeleton_bone_name);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BONE_MAP_H__
