// This file was automatically generated
// Do not modify this file
#include "directional_light2d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_DirectionalLight2D *godot_new_DirectionalLight2D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(DirectionalLight2D);
}

// Methods
void godot_DirectionalLight2D_set_max_distance(godot_DirectionalLight2D *self, godot_float pixels) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(DirectionalLight2D, set_max_distance, 373806689, void, self, &pixels)
}
godot_float godot_DirectionalLight2D_get_max_distance(const godot_DirectionalLight2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DirectionalLight2D, get_max_distance, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
