// This file was automatically generated
// Do not modify this file
#include "capsule_mesh.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CapsuleMesh *godot_new_CapsuleMesh() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CapsuleMesh);
}

// Methods
void godot_CapsuleMesh_set_radius(godot_CapsuleMesh *self, godot_float radius) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CapsuleMesh, set_radius, 373806689, void, self, &radius)
}
godot_float godot_CapsuleMesh_get_radius(const godot_CapsuleMesh *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CapsuleMesh, get_radius, 1740695150, godot_float, self)
}
void godot_CapsuleMesh_set_height(godot_CapsuleMesh *self, godot_float height) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CapsuleMesh, set_height, 373806689, void, self, &height)
}
godot_float godot_CapsuleMesh_get_height(const godot_CapsuleMesh *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CapsuleMesh, get_height, 1740695150, godot_float, self)
}
void godot_CapsuleMesh_set_radial_segments(godot_CapsuleMesh *self, godot_int segments) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CapsuleMesh, set_radial_segments, 1286410249, void, self, &segments)
}
godot_int godot_CapsuleMesh_get_radial_segments(const godot_CapsuleMesh *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CapsuleMesh, get_radial_segments, 3905245786, godot_int, self)
}
void godot_CapsuleMesh_set_rings(godot_CapsuleMesh *self, godot_int rings) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CapsuleMesh, set_rings, 1286410249, void, self, &rings)
}
godot_int godot_CapsuleMesh_get_rings(const godot_CapsuleMesh *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CapsuleMesh, get_rings, 3905245786, godot_int, self)
}


#ifdef __cplusplus
}
#endif
