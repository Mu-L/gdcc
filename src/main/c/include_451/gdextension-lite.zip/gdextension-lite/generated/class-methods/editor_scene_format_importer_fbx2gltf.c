// This file was automatically generated
// Do not modify this file
#include "editor_scene_format_importer_fbx2gltf.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorSceneFormatImporterFBX2GLTF *godot_new_EditorSceneFormatImporterFBX2GLTF() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorSceneFormatImporterFBX2GLTF);
}


#ifdef __cplusplus
}
#endif
