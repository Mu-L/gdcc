// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_COMMAND_PALETTE_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_COMMAND_PALETTE_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorCommandPalette *godot_new_EditorCommandPalette();

// Methods
GDEXTENSION_LITE_DECL void godot_EditorCommandPalette_add_command(godot_EditorCommandPalette *self, const godot_String *command_name, const godot_String *key_name, const godot_Callable *binded_callable, const godot_String *shortcut_text);
GDEXTENSION_LITE_DECL void godot_EditorCommandPalette_remove_command(godot_EditorCommandPalette *self, const godot_String *key_name);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_COMMAND_PALETTE_H__
