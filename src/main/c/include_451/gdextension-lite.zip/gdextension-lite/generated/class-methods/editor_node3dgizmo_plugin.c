// This file was automatically generated
// Do not modify this file
#include "editor_node3dgizmo_plugin.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorNode3DGizmoPlugin *godot_new_EditorNode3DGizmoPlugin() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorNode3DGizmoPlugin);
}

// Methods
godot_bool godot_EditorNode3DGizmoPlugin__has_gizmo(const godot_EditorNode3DGizmoPlugin *self, const godot_Node3D *for_node_3d) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorNode3DGizmoPlugin, _has_gizmo, 1905827158, godot_bool, self, for_node_3d)
}
godot_EditorNode3DGizmo * godot_EditorNode3DGizmoPlugin__create_gizmo(const godot_EditorNode3DGizmoPlugin *self, const godot_Node3D *for_node_3d) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorNode3DGizmoPlugin, _create_gizmo, 1418965287, godot_EditorNode3DGizmo *, self, for_node_3d)
}
godot_String godot_EditorNode3DGizmoPlugin__get_gizmo_name(const godot_EditorNode3DGizmoPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorNode3DGizmoPlugin, _get_gizmo_name, 201670096, godot_String, self)
}
godot_int godot_EditorNode3DGizmoPlugin__get_priority(const godot_EditorNode3DGizmoPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorNode3DGizmoPlugin, _get_priority, 3905245786, godot_int, self)
}
godot_bool godot_EditorNode3DGizmoPlugin__can_be_hidden(const godot_EditorNode3DGizmoPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorNode3DGizmoPlugin, _can_be_hidden, 36873697, godot_bool, self)
}
godot_bool godot_EditorNode3DGizmoPlugin__is_selectable_when_hidden(const godot_EditorNode3DGizmoPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorNode3DGizmoPlugin, _is_selectable_when_hidden, 36873697, godot_bool, self)
}
void godot_EditorNode3DGizmoPlugin__redraw(godot_EditorNode3DGizmoPlugin *self, const godot_EditorNode3DGizmo *gizmo) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmoPlugin, _redraw, 173330131, void, self, gizmo)
}
godot_String godot_EditorNode3DGizmoPlugin__get_handle_name(const godot_EditorNode3DGizmoPlugin *self, const godot_EditorNode3DGizmo *gizmo, godot_int handle_id, godot_bool secondary) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorNode3DGizmoPlugin, _get_handle_name, 3888674840, godot_String, self, gizmo, &handle_id, &secondary)
}
godot_bool godot_EditorNode3DGizmoPlugin__is_handle_highlighted(const godot_EditorNode3DGizmoPlugin *self, const godot_EditorNode3DGizmo *gizmo, godot_int handle_id, godot_bool secondary) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorNode3DGizmoPlugin, _is_handle_highlighted, 2665780718, godot_bool, self, gizmo, &handle_id, &secondary)
}
godot_Variant godot_EditorNode3DGizmoPlugin__get_handle_value(const godot_EditorNode3DGizmoPlugin *self, const godot_EditorNode3DGizmo *gizmo, godot_int handle_id, godot_bool secondary) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorNode3DGizmoPlugin, _get_handle_value, 2887724832, godot_Variant, self, gizmo, &handle_id, &secondary)
}
void godot_EditorNode3DGizmoPlugin__begin_handle_action(godot_EditorNode3DGizmoPlugin *self, const godot_EditorNode3DGizmo *gizmo, godot_int handle_id, godot_bool secondary) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmoPlugin, _begin_handle_action, 3363704593, void, self, gizmo, &handle_id, &secondary)
}
void godot_EditorNode3DGizmoPlugin__set_handle(godot_EditorNode3DGizmoPlugin *self, const godot_EditorNode3DGizmo *gizmo, godot_int handle_id, godot_bool secondary, const godot_Camera3D *camera, const godot_Vector2 *screen_pos) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmoPlugin, _set_handle, 1249646868, void, self, gizmo, &handle_id, &secondary, camera, screen_pos)
}
void godot_EditorNode3DGizmoPlugin__commit_handle(godot_EditorNode3DGizmoPlugin *self, const godot_EditorNode3DGizmo *gizmo, godot_int handle_id, godot_bool secondary, const godot_Variant *restore, godot_bool cancel) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmoPlugin, _commit_handle, 1939863962, void, self, gizmo, &handle_id, &secondary, restore, &cancel)
}
godot_int godot_EditorNode3DGizmoPlugin__subgizmos_intersect_ray(const godot_EditorNode3DGizmoPlugin *self, const godot_EditorNode3DGizmo *gizmo, const godot_Camera3D *camera, const godot_Vector2 *screen_pos) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorNode3DGizmoPlugin, _subgizmos_intersect_ray, 1781916302, godot_int, self, gizmo, camera, screen_pos)
}
godot_PackedInt32Array godot_EditorNode3DGizmoPlugin__subgizmos_intersect_frustum(const godot_EditorNode3DGizmoPlugin *self, const godot_EditorNode3DGizmo *gizmo, const godot_Camera3D *camera, const godot_TypedArray(godot_Plane) *frustum_planes) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorNode3DGizmoPlugin, _subgizmos_intersect_frustum, 3514748524, godot_PackedInt32Array, self, gizmo, camera, frustum_planes)
}
godot_Transform3D godot_EditorNode3DGizmoPlugin__get_subgizmo_transform(const godot_EditorNode3DGizmoPlugin *self, const godot_EditorNode3DGizmo *gizmo, godot_int subgizmo_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorNode3DGizmoPlugin, _get_subgizmo_transform, 3700343508, godot_Transform3D, self, gizmo, &subgizmo_id)
}
void godot_EditorNode3DGizmoPlugin__set_subgizmo_transform(godot_EditorNode3DGizmoPlugin *self, const godot_EditorNode3DGizmo *gizmo, godot_int subgizmo_id, const godot_Transform3D *transform) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmoPlugin, _set_subgizmo_transform, 2435388792, void, self, gizmo, &subgizmo_id, transform)
}
void godot_EditorNode3DGizmoPlugin__commit_subgizmos(godot_EditorNode3DGizmoPlugin *self, const godot_EditorNode3DGizmo *gizmo, const godot_PackedInt32Array *ids, const godot_TypedArray(godot_Transform3D) *restores, godot_bool cancel) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmoPlugin, _commit_subgizmos, 2282018236, void, self, gizmo, ids, restores, &cancel)
}
void godot_EditorNode3DGizmoPlugin_create_material(godot_EditorNode3DGizmoPlugin *self, const godot_String *name, const godot_Color *color, godot_bool billboard, godot_bool on_top, godot_bool use_vertex_color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmoPlugin, create_material, 3486012546, void, self, name, color, &billboard, &on_top, &use_vertex_color)
}
void godot_EditorNode3DGizmoPlugin_create_icon_material(godot_EditorNode3DGizmoPlugin *self, const godot_String *name, const godot_Texture2D *texture, godot_bool on_top, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmoPlugin, create_icon_material, 3804976916, void, self, name, texture, &on_top, color)
}
void godot_EditorNode3DGizmoPlugin_create_handle_material(godot_EditorNode3DGizmoPlugin *self, const godot_String *name, godot_bool billboard, const godot_Texture2D *texture) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmoPlugin, create_handle_material, 2486475223, void, self, name, &billboard, texture)
}
void godot_EditorNode3DGizmoPlugin_add_material(godot_EditorNode3DGizmoPlugin *self, const godot_String *name, const godot_StandardMaterial3D *material) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorNode3DGizmoPlugin, add_material, 1374068695, void, self, name, material)
}
godot_StandardMaterial3D * godot_EditorNode3DGizmoPlugin_get_material(godot_EditorNode3DGizmoPlugin *self, const godot_String *name, const godot_EditorNode3DGizmo *gizmo) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorNode3DGizmoPlugin, get_material, 974464017, godot_StandardMaterial3D *, self, name, gizmo)
}


#ifdef __cplusplus
}
#endif
