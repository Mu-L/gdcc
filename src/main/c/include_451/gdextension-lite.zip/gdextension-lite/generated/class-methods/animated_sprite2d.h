// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATED_SPRITE2D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATED_SPRITE2D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AnimatedSprite2D *godot_new_AnimatedSprite2D();

// Methods
GDEXTENSION_LITE_DECL void godot_AnimatedSprite2D_set_sprite_frames(godot_AnimatedSprite2D *self, const godot_SpriteFrames *sprite_frames);
GDEXTENSION_LITE_DECL godot_SpriteFrames * godot_AnimatedSprite2D_get_sprite_frames(const godot_AnimatedSprite2D *self);
GDEXTENSION_LITE_DECL void godot_AnimatedSprite2D_set_animation(godot_AnimatedSprite2D *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL godot_StringName godot_AnimatedSprite2D_get_animation(const godot_AnimatedSprite2D *self);
GDEXTENSION_LITE_DECL void godot_AnimatedSprite2D_set_autoplay(godot_AnimatedSprite2D *self, const godot_String *name);
GDEXTENSION_LITE_DECL godot_String godot_AnimatedSprite2D_get_autoplay(const godot_AnimatedSprite2D *self);
GDEXTENSION_LITE_DECL godot_bool godot_AnimatedSprite2D_is_playing(const godot_AnimatedSprite2D *self);
GDEXTENSION_LITE_DECL void godot_AnimatedSprite2D_play(godot_AnimatedSprite2D *self, const godot_StringName *name, godot_float custom_speed, godot_bool from_end);
GDEXTENSION_LITE_DECL void godot_AnimatedSprite2D_play_backwards(godot_AnimatedSprite2D *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL void godot_AnimatedSprite2D_pause(godot_AnimatedSprite2D *self);
GDEXTENSION_LITE_DECL void godot_AnimatedSprite2D_stop(godot_AnimatedSprite2D *self);
GDEXTENSION_LITE_DECL void godot_AnimatedSprite2D_set_centered(godot_AnimatedSprite2D *self, godot_bool centered);
GDEXTENSION_LITE_DECL godot_bool godot_AnimatedSprite2D_is_centered(const godot_AnimatedSprite2D *self);
GDEXTENSION_LITE_DECL void godot_AnimatedSprite2D_set_offset(godot_AnimatedSprite2D *self, const godot_Vector2 *offset);
GDEXTENSION_LITE_DECL godot_Vector2 godot_AnimatedSprite2D_get_offset(const godot_AnimatedSprite2D *self);
GDEXTENSION_LITE_DECL void godot_AnimatedSprite2D_set_flip_h(godot_AnimatedSprite2D *self, godot_bool flip_h);
GDEXTENSION_LITE_DECL godot_bool godot_AnimatedSprite2D_is_flipped_h(const godot_AnimatedSprite2D *self);
GDEXTENSION_LITE_DECL void godot_AnimatedSprite2D_set_flip_v(godot_AnimatedSprite2D *self, godot_bool flip_v);
GDEXTENSION_LITE_DECL godot_bool godot_AnimatedSprite2D_is_flipped_v(const godot_AnimatedSprite2D *self);
GDEXTENSION_LITE_DECL void godot_AnimatedSprite2D_set_frame(godot_AnimatedSprite2D *self, godot_int frame);
GDEXTENSION_LITE_DECL godot_int godot_AnimatedSprite2D_get_frame(const godot_AnimatedSprite2D *self);
GDEXTENSION_LITE_DECL void godot_AnimatedSprite2D_set_frame_progress(godot_AnimatedSprite2D *self, godot_float progress);
GDEXTENSION_LITE_DECL godot_float godot_AnimatedSprite2D_get_frame_progress(const godot_AnimatedSprite2D *self);
GDEXTENSION_LITE_DECL void godot_AnimatedSprite2D_set_frame_and_progress(godot_AnimatedSprite2D *self, godot_int frame, godot_float progress);
GDEXTENSION_LITE_DECL void godot_AnimatedSprite2D_set_speed_scale(godot_AnimatedSprite2D *self, godot_float speed_scale);
GDEXTENSION_LITE_DECL godot_float godot_AnimatedSprite2D_get_speed_scale(const godot_AnimatedSprite2D *self);
GDEXTENSION_LITE_DECL godot_float godot_AnimatedSprite2D_get_playing_speed(const godot_AnimatedSprite2D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATED_SPRITE2D_H__
