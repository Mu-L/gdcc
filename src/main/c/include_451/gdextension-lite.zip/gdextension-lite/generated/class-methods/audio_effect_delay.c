// This file was automatically generated
// Do not modify this file
#include "audio_effect_delay.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectDelay *godot_new_AudioEffectDelay() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectDelay);
}

// Methods
void godot_AudioEffectDelay_set_dry(godot_AudioEffectDelay *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectDelay, set_dry, 373806689, void, self, &amount)
}
godot_float godot_AudioEffectDelay_get_dry(godot_AudioEffectDelay *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectDelay, get_dry, 191475506, godot_float, self)
}
void godot_AudioEffectDelay_set_tap1_active(godot_AudioEffectDelay *self, godot_bool amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectDelay, set_tap1_active, 2586408642, void, self, &amount)
}
godot_bool godot_AudioEffectDelay_is_tap1_active(const godot_AudioEffectDelay *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectDelay, is_tap1_active, 36873697, godot_bool, self)
}
void godot_AudioEffectDelay_set_tap1_delay_ms(godot_AudioEffectDelay *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectDelay, set_tap1_delay_ms, 373806689, void, self, &amount)
}
godot_float godot_AudioEffectDelay_get_tap1_delay_ms(const godot_AudioEffectDelay *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectDelay, get_tap1_delay_ms, 1740695150, godot_float, self)
}
void godot_AudioEffectDelay_set_tap1_level_db(godot_AudioEffectDelay *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectDelay, set_tap1_level_db, 373806689, void, self, &amount)
}
godot_float godot_AudioEffectDelay_get_tap1_level_db(const godot_AudioEffectDelay *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectDelay, get_tap1_level_db, 1740695150, godot_float, self)
}
void godot_AudioEffectDelay_set_tap1_pan(godot_AudioEffectDelay *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectDelay, set_tap1_pan, 373806689, void, self, &amount)
}
godot_float godot_AudioEffectDelay_get_tap1_pan(const godot_AudioEffectDelay *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectDelay, get_tap1_pan, 1740695150, godot_float, self)
}
void godot_AudioEffectDelay_set_tap2_active(godot_AudioEffectDelay *self, godot_bool amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectDelay, set_tap2_active, 2586408642, void, self, &amount)
}
godot_bool godot_AudioEffectDelay_is_tap2_active(const godot_AudioEffectDelay *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectDelay, is_tap2_active, 36873697, godot_bool, self)
}
void godot_AudioEffectDelay_set_tap2_delay_ms(godot_AudioEffectDelay *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectDelay, set_tap2_delay_ms, 373806689, void, self, &amount)
}
godot_float godot_AudioEffectDelay_get_tap2_delay_ms(const godot_AudioEffectDelay *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectDelay, get_tap2_delay_ms, 1740695150, godot_float, self)
}
void godot_AudioEffectDelay_set_tap2_level_db(godot_AudioEffectDelay *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectDelay, set_tap2_level_db, 373806689, void, self, &amount)
}
godot_float godot_AudioEffectDelay_get_tap2_level_db(const godot_AudioEffectDelay *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectDelay, get_tap2_level_db, 1740695150, godot_float, self)
}
void godot_AudioEffectDelay_set_tap2_pan(godot_AudioEffectDelay *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectDelay, set_tap2_pan, 373806689, void, self, &amount)
}
godot_float godot_AudioEffectDelay_get_tap2_pan(const godot_AudioEffectDelay *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectDelay, get_tap2_pan, 1740695150, godot_float, self)
}
void godot_AudioEffectDelay_set_feedback_active(godot_AudioEffectDelay *self, godot_bool amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectDelay, set_feedback_active, 2586408642, void, self, &amount)
}
godot_bool godot_AudioEffectDelay_is_feedback_active(const godot_AudioEffectDelay *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectDelay, is_feedback_active, 36873697, godot_bool, self)
}
void godot_AudioEffectDelay_set_feedback_delay_ms(godot_AudioEffectDelay *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectDelay, set_feedback_delay_ms, 373806689, void, self, &amount)
}
godot_float godot_AudioEffectDelay_get_feedback_delay_ms(const godot_AudioEffectDelay *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectDelay, get_feedback_delay_ms, 1740695150, godot_float, self)
}
void godot_AudioEffectDelay_set_feedback_level_db(godot_AudioEffectDelay *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectDelay, set_feedback_level_db, 373806689, void, self, &amount)
}
godot_float godot_AudioEffectDelay_get_feedback_level_db(const godot_AudioEffectDelay *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectDelay, get_feedback_level_db, 1740695150, godot_float, self)
}
void godot_AudioEffectDelay_set_feedback_lowpass(godot_AudioEffectDelay *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectDelay, set_feedback_lowpass, 373806689, void, self, &amount)
}
godot_float godot_AudioEffectDelay_get_feedback_lowpass(const godot_AudioEffectDelay *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectDelay, get_feedback_lowpass, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
