// This file was automatically generated
// Do not modify this file
#include "audio_effect_record.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectRecord *godot_new_AudioEffectRecord() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectRecord);
}

// Methods
void godot_AudioEffectRecord_set_recording_active(godot_AudioEffectRecord *self, godot_bool record) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectRecord, set_recording_active, 2586408642, void, self, &record)
}
godot_bool godot_AudioEffectRecord_is_recording_active(const godot_AudioEffectRecord *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectRecord, is_recording_active, 36873697, godot_bool, self)
}
void godot_AudioEffectRecord_set_format(godot_AudioEffectRecord *self, godot_AudioStreamWAV_Format format) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectRecord, set_format, 60648488, void, self, &format)
}
godot_AudioStreamWAV_Format godot_AudioEffectRecord_get_format(const godot_AudioEffectRecord *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectRecord, get_format, 3151724922, godot_AudioStreamWAV_Format, self)
}
godot_AudioStreamWAV * godot_AudioEffectRecord_get_recording(const godot_AudioEffectRecord *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectRecord, get_recording, 2964110865, godot_AudioStreamWAV *, self)
}


#ifdef __cplusplus
}
#endif
