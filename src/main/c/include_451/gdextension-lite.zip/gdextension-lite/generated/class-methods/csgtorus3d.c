// This file was automatically generated
// Do not modify this file
#include "csgtorus3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CSGTorus3D *godot_new_CSGTorus3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CSGTorus3D);
}

// Methods
void godot_CSGTorus3D_set_inner_radius(godot_CSGTorus3D *self, godot_float radius) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGTorus3D, set_inner_radius, 373806689, void, self, &radius)
}
godot_float godot_CSGTorus3D_get_inner_radius(const godot_CSGTorus3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGTorus3D, get_inner_radius, 1740695150, godot_float, self)
}
void godot_CSGTorus3D_set_outer_radius(godot_CSGTorus3D *self, godot_float radius) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGTorus3D, set_outer_radius, 373806689, void, self, &radius)
}
godot_float godot_CSGTorus3D_get_outer_radius(const godot_CSGTorus3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGTorus3D, get_outer_radius, 1740695150, godot_float, self)
}
void godot_CSGTorus3D_set_sides(godot_CSGTorus3D *self, godot_int sides) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGTorus3D, set_sides, 1286410249, void, self, &sides)
}
godot_int godot_CSGTorus3D_get_sides(const godot_CSGTorus3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGTorus3D, get_sides, 3905245786, godot_int, self)
}
void godot_CSGTorus3D_set_ring_sides(godot_CSGTorus3D *self, godot_int sides) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGTorus3D, set_ring_sides, 1286410249, void, self, &sides)
}
godot_int godot_CSGTorus3D_get_ring_sides(const godot_CSGTorus3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGTorus3D, get_ring_sides, 3905245786, godot_int, self)
}
void godot_CSGTorus3D_set_material(godot_CSGTorus3D *self, const godot_Material *material) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGTorus3D, set_material, 2757459619, void, self, material)
}
godot_Material * godot_CSGTorus3D_get_material(const godot_CSGTorus3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGTorus3D, get_material, 5934680, godot_Material *, self)
}
void godot_CSGTorus3D_set_smooth_faces(godot_CSGTorus3D *self, godot_bool smooth_faces) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGTorus3D, set_smooth_faces, 2586408642, void, self, &smooth_faces)
}
godot_bool godot_CSGTorus3D_get_smooth_faces(const godot_CSGTorus3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGTorus3D, get_smooth_faces, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
