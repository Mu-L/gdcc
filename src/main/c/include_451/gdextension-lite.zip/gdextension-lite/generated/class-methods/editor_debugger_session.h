// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_DEBUGGER_SESSION_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_DEBUGGER_SESSION_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
GDEXTENSION_LITE_DECL void godot_EditorDebuggerSession_send_message(godot_EditorDebuggerSession *self, const godot_String *message, const godot_Array *data);
GDEXTENSION_LITE_DECL void godot_EditorDebuggerSession_toggle_profiler(godot_EditorDebuggerSession *self, const godot_String *profiler, godot_bool enable, const godot_Array *data);
GDEXTENSION_LITE_DECL godot_bool godot_EditorDebuggerSession_is_breaked(godot_EditorDebuggerSession *self);
GDEXTENSION_LITE_DECL godot_bool godot_EditorDebuggerSession_is_debuggable(godot_EditorDebuggerSession *self);
GDEXTENSION_LITE_DECL godot_bool godot_EditorDebuggerSession_is_active(godot_EditorDebuggerSession *self);
GDEXTENSION_LITE_DECL void godot_EditorDebuggerSession_add_session_tab(godot_EditorDebuggerSession *self, const godot_Control *control);
GDEXTENSION_LITE_DECL void godot_EditorDebuggerSession_remove_session_tab(godot_EditorDebuggerSession *self, const godot_Control *control);
GDEXTENSION_LITE_DECL void godot_EditorDebuggerSession_set_breakpoint(godot_EditorDebuggerSession *self, const godot_String *path, godot_int line, godot_bool enabled);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_DEBUGGER_SESSION_H__
