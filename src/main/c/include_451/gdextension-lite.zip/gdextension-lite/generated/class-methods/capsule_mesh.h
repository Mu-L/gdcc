// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAPSULE_MESH_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAPSULE_MESH_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CapsuleMesh *godot_new_CapsuleMesh();

// Methods
GDEXTENSION_LITE_DECL void godot_CapsuleMesh_set_radius(godot_CapsuleMesh *self, godot_float radius);
GDEXTENSION_LITE_DECL godot_float godot_CapsuleMesh_get_radius(const godot_CapsuleMesh *self);
GDEXTENSION_LITE_DECL void godot_CapsuleMesh_set_height(godot_CapsuleMesh *self, godot_float height);
GDEXTENSION_LITE_DECL godot_float godot_CapsuleMesh_get_height(const godot_CapsuleMesh *self);
GDEXTENSION_LITE_DECL void godot_CapsuleMesh_set_radial_segments(godot_CapsuleMesh *self, godot_int segments);
GDEXTENSION_LITE_DECL godot_int godot_CapsuleMesh_get_radial_segments(const godot_CapsuleMesh *self);
GDEXTENSION_LITE_DECL void godot_CapsuleMesh_set_rings(godot_CapsuleMesh *self, godot_int rings);
GDEXTENSION_LITE_DECL godot_int godot_CapsuleMesh_get_rings(const godot_CapsuleMesh *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAPSULE_MESH_H__
