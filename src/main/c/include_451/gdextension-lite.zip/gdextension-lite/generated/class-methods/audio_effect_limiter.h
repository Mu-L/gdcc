// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_LIMITER_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_LIMITER_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioEffectLimiter *godot_new_AudioEffectLimiter();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioEffectLimiter_set_ceiling_db(godot_AudioEffectLimiter *self, godot_float ceiling);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectLimiter_get_ceiling_db(const godot_AudioEffectLimiter *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectLimiter_set_threshold_db(godot_AudioEffectLimiter *self, godot_float threshold);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectLimiter_get_threshold_db(const godot_AudioEffectLimiter *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectLimiter_set_soft_clip_db(godot_AudioEffectLimiter *self, godot_float soft_clip);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectLimiter_get_soft_clip_db(const godot_AudioEffectLimiter *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectLimiter_set_soft_clip_ratio(godot_AudioEffectLimiter *self, godot_float soft_clip);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectLimiter_get_soft_clip_ratio(const godot_AudioEffectLimiter *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_LIMITER_H__
