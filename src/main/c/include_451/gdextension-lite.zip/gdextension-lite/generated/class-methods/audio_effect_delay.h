// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_DELAY_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_DELAY_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioEffectDelay *godot_new_AudioEffectDelay();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioEffectDelay_set_dry(godot_AudioEffectDelay *self, godot_float amount);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectDelay_get_dry(godot_AudioEffectDelay *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectDelay_set_tap1_active(godot_AudioEffectDelay *self, godot_bool amount);
GDEXTENSION_LITE_DECL godot_bool godot_AudioEffectDelay_is_tap1_active(const godot_AudioEffectDelay *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectDelay_set_tap1_delay_ms(godot_AudioEffectDelay *self, godot_float amount);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectDelay_get_tap1_delay_ms(const godot_AudioEffectDelay *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectDelay_set_tap1_level_db(godot_AudioEffectDelay *self, godot_float amount);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectDelay_get_tap1_level_db(const godot_AudioEffectDelay *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectDelay_set_tap1_pan(godot_AudioEffectDelay *self, godot_float amount);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectDelay_get_tap1_pan(const godot_AudioEffectDelay *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectDelay_set_tap2_active(godot_AudioEffectDelay *self, godot_bool amount);
GDEXTENSION_LITE_DECL godot_bool godot_AudioEffectDelay_is_tap2_active(const godot_AudioEffectDelay *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectDelay_set_tap2_delay_ms(godot_AudioEffectDelay *self, godot_float amount);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectDelay_get_tap2_delay_ms(const godot_AudioEffectDelay *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectDelay_set_tap2_level_db(godot_AudioEffectDelay *self, godot_float amount);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectDelay_get_tap2_level_db(const godot_AudioEffectDelay *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectDelay_set_tap2_pan(godot_AudioEffectDelay *self, godot_float amount);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectDelay_get_tap2_pan(const godot_AudioEffectDelay *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectDelay_set_feedback_active(godot_AudioEffectDelay *self, godot_bool amount);
GDEXTENSION_LITE_DECL godot_bool godot_AudioEffectDelay_is_feedback_active(const godot_AudioEffectDelay *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectDelay_set_feedback_delay_ms(godot_AudioEffectDelay *self, godot_float amount);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectDelay_get_feedback_delay_ms(const godot_AudioEffectDelay *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectDelay_set_feedback_level_db(godot_AudioEffectDelay *self, godot_float amount);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectDelay_get_feedback_level_db(const godot_AudioEffectDelay *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectDelay_set_feedback_lowpass(godot_AudioEffectDelay *self, godot_float amount);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectDelay_get_feedback_lowpass(const godot_AudioEffectDelay *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_DELAY_H__
