// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CSGMESH3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CSGMESH3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CSGMesh3D *godot_new_CSGMesh3D();

// Methods
GDEXTENSION_LITE_DECL void godot_CSGMesh3D_set_mesh(godot_CSGMesh3D *self, const godot_Mesh *mesh);
GDEXTENSION_LITE_DECL godot_Mesh * godot_CSGMesh3D_get_mesh(godot_CSGMesh3D *self);
GDEXTENSION_LITE_DECL void godot_CSGMesh3D_set_material(godot_CSGMesh3D *self, const godot_Material *material);
GDEXTENSION_LITE_DECL godot_Material * godot_CSGMesh3D_get_material(const godot_CSGMesh3D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CSGMESH3D_H__
