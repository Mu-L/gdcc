// This file was automatically generated
// Do not modify this file
#include "animation_node_blend_space1d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimationNodeBlendSpace1D *godot_new_AnimationNodeBlendSpace1D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimationNodeBlendSpace1D);
}

// Methods
void godot_AnimationNodeBlendSpace1D_add_blend_point(godot_AnimationNodeBlendSpace1D *self, const godot_AnimationRootNode *node, godot_float pos, godot_int at_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendSpace1D, add_blend_point, 285050433, void, self, node, &pos, &at_index)
}
void godot_AnimationNodeBlendSpace1D_set_blend_point_position(godot_AnimationNodeBlendSpace1D *self, godot_int point, godot_float pos) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendSpace1D, set_blend_point_position, 1602489585, void, self, &point, &pos)
}
godot_float godot_AnimationNodeBlendSpace1D_get_blend_point_position(const godot_AnimationNodeBlendSpace1D *self, godot_int point) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendSpace1D, get_blend_point_position, 2339986948, godot_float, self, &point)
}
void godot_AnimationNodeBlendSpace1D_set_blend_point_node(godot_AnimationNodeBlendSpace1D *self, godot_int point, const godot_AnimationRootNode *node) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendSpace1D, set_blend_point_node, 4240341528, void, self, &point, node)
}
godot_AnimationRootNode * godot_AnimationNodeBlendSpace1D_get_blend_point_node(const godot_AnimationNodeBlendSpace1D *self, godot_int point) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendSpace1D, get_blend_point_node, 665599029, godot_AnimationRootNode *, self, &point)
}
void godot_AnimationNodeBlendSpace1D_remove_blend_point(godot_AnimationNodeBlendSpace1D *self, godot_int point) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendSpace1D, remove_blend_point, 1286410249, void, self, &point)
}
godot_int godot_AnimationNodeBlendSpace1D_get_blend_point_count(const godot_AnimationNodeBlendSpace1D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendSpace1D, get_blend_point_count, 3905245786, godot_int, self)
}
void godot_AnimationNodeBlendSpace1D_set_min_space(godot_AnimationNodeBlendSpace1D *self, godot_float min_space) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendSpace1D, set_min_space, 373806689, void, self, &min_space)
}
godot_float godot_AnimationNodeBlendSpace1D_get_min_space(const godot_AnimationNodeBlendSpace1D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendSpace1D, get_min_space, 1740695150, godot_float, self)
}
void godot_AnimationNodeBlendSpace1D_set_max_space(godot_AnimationNodeBlendSpace1D *self, godot_float max_space) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendSpace1D, set_max_space, 373806689, void, self, &max_space)
}
godot_float godot_AnimationNodeBlendSpace1D_get_max_space(const godot_AnimationNodeBlendSpace1D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendSpace1D, get_max_space, 1740695150, godot_float, self)
}
void godot_AnimationNodeBlendSpace1D_set_snap(godot_AnimationNodeBlendSpace1D *self, godot_float snap) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendSpace1D, set_snap, 373806689, void, self, &snap)
}
godot_float godot_AnimationNodeBlendSpace1D_get_snap(const godot_AnimationNodeBlendSpace1D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendSpace1D, get_snap, 1740695150, godot_float, self)
}
void godot_AnimationNodeBlendSpace1D_set_value_label(godot_AnimationNodeBlendSpace1D *self, const godot_String *text) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendSpace1D, set_value_label, 83702148, void, self, text)
}
godot_String godot_AnimationNodeBlendSpace1D_get_value_label(const godot_AnimationNodeBlendSpace1D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendSpace1D, get_value_label, 201670096, godot_String, self)
}
void godot_AnimationNodeBlendSpace1D_set_blend_mode(godot_AnimationNodeBlendSpace1D *self, godot_AnimationNodeBlendSpace1D_BlendMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendSpace1D, set_blend_mode, 2600869457, void, self, &mode)
}
godot_AnimationNodeBlendSpace1D_BlendMode godot_AnimationNodeBlendSpace1D_get_blend_mode(const godot_AnimationNodeBlendSpace1D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendSpace1D, get_blend_mode, 1547667849, godot_AnimationNodeBlendSpace1D_BlendMode, self)
}
void godot_AnimationNodeBlendSpace1D_set_use_sync(godot_AnimationNodeBlendSpace1D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeBlendSpace1D, set_use_sync, 2586408642, void, self, &enable)
}
godot_bool godot_AnimationNodeBlendSpace1D_is_using_sync(const godot_AnimationNodeBlendSpace1D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeBlendSpace1D, is_using_sync, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
