// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_FILE_SYSTEM_IMPORT_FORMAT_SUPPORT_QUERY_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_FILE_SYSTEM_IMPORT_FORMAT_SUPPORT_QUERY_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorFileSystemImportFormatSupportQuery *godot_new_EditorFileSystemImportFormatSupportQuery();

// Methods
GDEXTENSION_LITE_DECL godot_bool godot_EditorFileSystemImportFormatSupportQuery__is_active(const godot_EditorFileSystemImportFormatSupportQuery *self);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_EditorFileSystemImportFormatSupportQuery__get_file_extensions(const godot_EditorFileSystemImportFormatSupportQuery *self);
GDEXTENSION_LITE_DECL godot_bool godot_EditorFileSystemImportFormatSupportQuery__query(const godot_EditorFileSystemImportFormatSupportQuery *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_FILE_SYSTEM_IMPORT_FORMAT_SUPPORT_QUERY_H__
