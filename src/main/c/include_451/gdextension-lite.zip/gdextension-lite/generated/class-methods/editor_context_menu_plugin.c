// This file was automatically generated
// Do not modify this file
#include "editor_context_menu_plugin.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorContextMenuPlugin *godot_new_EditorContextMenuPlugin() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorContextMenuPlugin);
}

// Methods
void godot_EditorContextMenuPlugin__popup_menu(godot_EditorContextMenuPlugin *self, const godot_PackedStringArray *paths) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorContextMenuPlugin, _popup_menu, 4015028928, void, self, paths)
}
void godot_EditorContextMenuPlugin_add_menu_shortcut(godot_EditorContextMenuPlugin *self, const godot_Shortcut *shortcut, const godot_Callable *callback) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorContextMenuPlugin, add_menu_shortcut, 851596305, void, self, shortcut, callback)
}
void godot_EditorContextMenuPlugin_add_context_menu_item(godot_EditorContextMenuPlugin *self, const godot_String *name, const godot_Callable *callback, const godot_Texture2D *icon) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorContextMenuPlugin, add_context_menu_item, 2748336951, void, self, name, callback, icon)
}
void godot_EditorContextMenuPlugin_add_context_menu_item_from_shortcut(godot_EditorContextMenuPlugin *self, const godot_String *name, const godot_Shortcut *shortcut, const godot_Texture2D *icon) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorContextMenuPlugin, add_context_menu_item_from_shortcut, 3799546916, void, self, name, shortcut, icon)
}
void godot_EditorContextMenuPlugin_add_context_submenu_item(godot_EditorContextMenuPlugin *self, const godot_String *name, const godot_PopupMenu *menu, const godot_Texture2D *icon) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorContextMenuPlugin, add_context_submenu_item, 1994674995, void, self, name, menu, icon)
}


#ifdef __cplusplus
}
#endif
