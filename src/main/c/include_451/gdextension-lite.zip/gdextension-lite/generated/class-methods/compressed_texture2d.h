// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COMPRESSED_TEXTURE2D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COMPRESSED_TEXTURE2D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CompressedTexture2D *godot_new_CompressedTexture2D();

// Methods
GDEXTENSION_LITE_DECL godot_Error godot_CompressedTexture2D_load(godot_CompressedTexture2D *self, const godot_String *path);
GDEXTENSION_LITE_DECL godot_String godot_CompressedTexture2D_get_load_path(const godot_CompressedTexture2D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COMPRESSED_TEXTURE2D_H__
