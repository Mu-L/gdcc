// This file was automatically generated
// Do not modify this file
#include "audio_stream_generator_playback.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
godot_bool godot_AudioStreamGeneratorPlayback_push_frame(godot_AudioStreamGeneratorPlayback *self, const godot_Vector2 *frame) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamGeneratorPlayback, push_frame, 3975407249, godot_bool, self, frame)
}
godot_bool godot_AudioStreamGeneratorPlayback_can_push_buffer(const godot_AudioStreamGeneratorPlayback *self, godot_int amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamGeneratorPlayback, can_push_buffer, 1116898809, godot_bool, self, &amount)
}
godot_bool godot_AudioStreamGeneratorPlayback_push_buffer(godot_AudioStreamGeneratorPlayback *self, const godot_PackedVector2Array *frames) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamGeneratorPlayback, push_buffer, 1361156557, godot_bool, self, frames)
}
godot_int godot_AudioStreamGeneratorPlayback_get_frames_available(const godot_AudioStreamGeneratorPlayback *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamGeneratorPlayback, get_frames_available, 3905245786, godot_int, self)
}
godot_int godot_AudioStreamGeneratorPlayback_get_skips(const godot_AudioStreamGeneratorPlayback *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamGeneratorPlayback, get_skips, 3905245786, godot_int, self)
}
void godot_AudioStreamGeneratorPlayback_clear_buffer(godot_AudioStreamGeneratorPlayback *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamGeneratorPlayback, clear_buffer, 3218959716, void, self)
}


#ifdef __cplusplus
}
#endif
