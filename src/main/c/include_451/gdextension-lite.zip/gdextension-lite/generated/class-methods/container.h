// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONTAINER_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONTAINER_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_Container *godot_new_Container();

// Methods
GDEXTENSION_LITE_DECL godot_PackedInt32Array godot_Container__get_allowed_size_flags_horizontal(const godot_Container *self);
GDEXTENSION_LITE_DECL godot_PackedInt32Array godot_Container__get_allowed_size_flags_vertical(const godot_Container *self);
GDEXTENSION_LITE_DECL void godot_Container_queue_sort(godot_Container *self);
GDEXTENSION_LITE_DECL void godot_Container_fit_child_in_rect(godot_Container *self, const godot_Control *child, const godot_Rect2 *rect);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONTAINER_H__
