// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_ONE_SHOT_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_ONE_SHOT_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AnimationNodeOneShot *godot_new_AnimationNodeOneShot();

// Methods
GDEXTENSION_LITE_DECL void godot_AnimationNodeOneShot_set_fadein_time(godot_AnimationNodeOneShot *self, godot_float time);
GDEXTENSION_LITE_DECL godot_float godot_AnimationNodeOneShot_get_fadein_time(const godot_AnimationNodeOneShot *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeOneShot_set_fadein_curve(godot_AnimationNodeOneShot *self, const godot_Curve *curve);
GDEXTENSION_LITE_DECL godot_Curve * godot_AnimationNodeOneShot_get_fadein_curve(const godot_AnimationNodeOneShot *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeOneShot_set_fadeout_time(godot_AnimationNodeOneShot *self, godot_float time);
GDEXTENSION_LITE_DECL godot_float godot_AnimationNodeOneShot_get_fadeout_time(const godot_AnimationNodeOneShot *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeOneShot_set_fadeout_curve(godot_AnimationNodeOneShot *self, const godot_Curve *curve);
GDEXTENSION_LITE_DECL godot_Curve * godot_AnimationNodeOneShot_get_fadeout_curve(const godot_AnimationNodeOneShot *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeOneShot_set_break_loop_at_end(godot_AnimationNodeOneShot *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNodeOneShot_is_loop_broken_at_end(const godot_AnimationNodeOneShot *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeOneShot_set_autorestart(godot_AnimationNodeOneShot *self, godot_bool active);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNodeOneShot_has_autorestart(const godot_AnimationNodeOneShot *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeOneShot_set_autorestart_delay(godot_AnimationNodeOneShot *self, godot_float time);
GDEXTENSION_LITE_DECL godot_float godot_AnimationNodeOneShot_get_autorestart_delay(const godot_AnimationNodeOneShot *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeOneShot_set_autorestart_random_delay(godot_AnimationNodeOneShot *self, godot_float time);
GDEXTENSION_LITE_DECL godot_float godot_AnimationNodeOneShot_get_autorestart_random_delay(const godot_AnimationNodeOneShot *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeOneShot_set_mix_mode(godot_AnimationNodeOneShot *self, godot_AnimationNodeOneShot_MixMode mode);
GDEXTENSION_LITE_DECL godot_AnimationNodeOneShot_MixMode godot_AnimationNodeOneShot_get_mix_mode(const godot_AnimationNodeOneShot *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_ONE_SHOT_H__
