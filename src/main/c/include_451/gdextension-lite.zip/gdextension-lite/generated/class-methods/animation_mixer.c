// This file was automatically generated
// Do not modify this file
#include "animation_mixer.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
godot_Variant godot_AnimationMixer__post_process_key_value(const godot_AnimationMixer *self, const godot_Animation *animation, godot_int track, const godot_Variant *value, godot_int object_id, godot_int object_sub_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, _post_process_key_value, 2716908335, godot_Variant, self, animation, &track, value, &object_id, &object_sub_idx)
}
godot_Error godot_AnimationMixer_add_animation_library(godot_AnimationMixer *self, const godot_StringName *name, const godot_AnimationLibrary *library) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, add_animation_library, 618909818, godot_Error, self, name, library)
}
void godot_AnimationMixer_remove_animation_library(godot_AnimationMixer *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationMixer, remove_animation_library, 3304788590, void, self, name)
}
void godot_AnimationMixer_rename_animation_library(godot_AnimationMixer *self, const godot_StringName *name, const godot_StringName *newname) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationMixer, rename_animation_library, 3740211285, void, self, name, newname)
}
godot_bool godot_AnimationMixer_has_animation_library(const godot_AnimationMixer *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, has_animation_library, 2619796661, godot_bool, self, name)
}
godot_AnimationLibrary * godot_AnimationMixer_get_animation_library(const godot_AnimationMixer *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, get_animation_library, 147342321, godot_AnimationLibrary *, self, name)
}
godot_TypedArray(godot_StringName) godot_AnimationMixer_get_animation_library_list(const godot_AnimationMixer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, get_animation_library_list, 3995934104, godot_TypedArray(godot_StringName), self)
}
godot_bool godot_AnimationMixer_has_animation(const godot_AnimationMixer *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, has_animation, 2619796661, godot_bool, self, name)
}
godot_Animation * godot_AnimationMixer_get_animation(const godot_AnimationMixer *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, get_animation, 2933122410, godot_Animation *, self, name)
}
godot_PackedStringArray godot_AnimationMixer_get_animation_list(const godot_AnimationMixer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, get_animation_list, 1139954409, godot_PackedStringArray, self)
}
void godot_AnimationMixer_set_active(godot_AnimationMixer *self, godot_bool active) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationMixer, set_active, 2586408642, void, self, &active)
}
godot_bool godot_AnimationMixer_is_active(const godot_AnimationMixer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, is_active, 36873697, godot_bool, self)
}
void godot_AnimationMixer_set_deterministic(godot_AnimationMixer *self, godot_bool deterministic) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationMixer, set_deterministic, 2586408642, void, self, &deterministic)
}
godot_bool godot_AnimationMixer_is_deterministic(const godot_AnimationMixer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, is_deterministic, 36873697, godot_bool, self)
}
void godot_AnimationMixer_set_root_node(godot_AnimationMixer *self, const godot_NodePath *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationMixer, set_root_node, 1348162250, void, self, path)
}
godot_NodePath godot_AnimationMixer_get_root_node(const godot_AnimationMixer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, get_root_node, 4075236667, godot_NodePath, self)
}
void godot_AnimationMixer_set_callback_mode_process(godot_AnimationMixer *self, godot_AnimationMixer_AnimationCallbackModeProcess mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationMixer, set_callback_mode_process, 2153733086, void, self, &mode)
}
godot_AnimationMixer_AnimationCallbackModeProcess godot_AnimationMixer_get_callback_mode_process(const godot_AnimationMixer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, get_callback_mode_process, 1394468472, godot_AnimationMixer_AnimationCallbackModeProcess, self)
}
void godot_AnimationMixer_set_callback_mode_method(godot_AnimationMixer *self, godot_AnimationMixer_AnimationCallbackModeMethod mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationMixer, set_callback_mode_method, 742218271, void, self, &mode)
}
godot_AnimationMixer_AnimationCallbackModeMethod godot_AnimationMixer_get_callback_mode_method(const godot_AnimationMixer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, get_callback_mode_method, 489449656, godot_AnimationMixer_AnimationCallbackModeMethod, self)
}
void godot_AnimationMixer_set_callback_mode_discrete(godot_AnimationMixer *self, godot_AnimationMixer_AnimationCallbackModeDiscrete mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationMixer, set_callback_mode_discrete, 1998944670, void, self, &mode)
}
godot_AnimationMixer_AnimationCallbackModeDiscrete godot_AnimationMixer_get_callback_mode_discrete(const godot_AnimationMixer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, get_callback_mode_discrete, 3493168860, godot_AnimationMixer_AnimationCallbackModeDiscrete, self)
}
void godot_AnimationMixer_set_audio_max_polyphony(godot_AnimationMixer *self, godot_int max_polyphony) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationMixer, set_audio_max_polyphony, 1286410249, void, self, &max_polyphony)
}
godot_int godot_AnimationMixer_get_audio_max_polyphony(const godot_AnimationMixer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, get_audio_max_polyphony, 3905245786, godot_int, self)
}
void godot_AnimationMixer_set_root_motion_track(godot_AnimationMixer *self, const godot_NodePath *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationMixer, set_root_motion_track, 1348162250, void, self, path)
}
godot_NodePath godot_AnimationMixer_get_root_motion_track(const godot_AnimationMixer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, get_root_motion_track, 4075236667, godot_NodePath, self)
}
void godot_AnimationMixer_set_root_motion_local(godot_AnimationMixer *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationMixer, set_root_motion_local, 2586408642, void, self, &enabled)
}
godot_bool godot_AnimationMixer_is_root_motion_local(const godot_AnimationMixer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, is_root_motion_local, 36873697, godot_bool, self)
}
godot_Vector3 godot_AnimationMixer_get_root_motion_position(const godot_AnimationMixer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, get_root_motion_position, 3360562783, godot_Vector3, self)
}
godot_Quaternion godot_AnimationMixer_get_root_motion_rotation(const godot_AnimationMixer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, get_root_motion_rotation, 1222331677, godot_Quaternion, self)
}
godot_Vector3 godot_AnimationMixer_get_root_motion_scale(const godot_AnimationMixer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, get_root_motion_scale, 3360562783, godot_Vector3, self)
}
godot_Vector3 godot_AnimationMixer_get_root_motion_position_accumulator(const godot_AnimationMixer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, get_root_motion_position_accumulator, 3360562783, godot_Vector3, self)
}
godot_Quaternion godot_AnimationMixer_get_root_motion_rotation_accumulator(const godot_AnimationMixer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, get_root_motion_rotation_accumulator, 1222331677, godot_Quaternion, self)
}
godot_Vector3 godot_AnimationMixer_get_root_motion_scale_accumulator(const godot_AnimationMixer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, get_root_motion_scale_accumulator, 3360562783, godot_Vector3, self)
}
void godot_AnimationMixer_clear_caches(godot_AnimationMixer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationMixer, clear_caches, 3218959716, void, self)
}
void godot_AnimationMixer_advance(godot_AnimationMixer *self, godot_float delta) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationMixer, advance, 373806689, void, self, &delta)
}
void godot_AnimationMixer_capture(godot_AnimationMixer *self, const godot_StringName *name, godot_float duration, godot_Tween_TransitionType trans_type, godot_Tween_EaseType ease_type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationMixer, capture, 1333632127, void, self, name, &duration, &trans_type, &ease_type)
}
void godot_AnimationMixer_set_reset_on_save_enabled(godot_AnimationMixer *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationMixer, set_reset_on_save_enabled, 2586408642, void, self, &enabled)
}
godot_bool godot_AnimationMixer_is_reset_on_save_enabled(const godot_AnimationMixer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, is_reset_on_save_enabled, 36873697, godot_bool, self)
}
godot_StringName godot_AnimationMixer_find_animation(const godot_AnimationMixer *self, const godot_Animation *animation) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, find_animation, 1559484580, godot_StringName, self, animation)
}
godot_StringName godot_AnimationMixer_find_animation_library(const godot_AnimationMixer *self, const godot_Animation *animation) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationMixer, find_animation_library, 1559484580, godot_StringName, self, animation)
}


#ifdef __cplusplus
}
#endif
