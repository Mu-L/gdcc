// This file was automatically generated
// Do not modify this file
#include "animated_texture.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimatedTexture *godot_new_AnimatedTexture() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimatedTexture);
}

// Methods
void godot_AnimatedTexture_set_frames(godot_AnimatedTexture *self, godot_int frames) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimatedTexture, set_frames, 1286410249, void, self, &frames)
}
godot_int godot_AnimatedTexture_get_frames(const godot_AnimatedTexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimatedTexture, get_frames, 3905245786, godot_int, self)
}
void godot_AnimatedTexture_set_current_frame(godot_AnimatedTexture *self, godot_int frame) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimatedTexture, set_current_frame, 1286410249, void, self, &frame)
}
godot_int godot_AnimatedTexture_get_current_frame(const godot_AnimatedTexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimatedTexture, get_current_frame, 3905245786, godot_int, self)
}
void godot_AnimatedTexture_set_pause(godot_AnimatedTexture *self, godot_bool pause) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimatedTexture, set_pause, 2586408642, void, self, &pause)
}
godot_bool godot_AnimatedTexture_get_pause(const godot_AnimatedTexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimatedTexture, get_pause, 36873697, godot_bool, self)
}
void godot_AnimatedTexture_set_one_shot(godot_AnimatedTexture *self, godot_bool one_shot) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimatedTexture, set_one_shot, 2586408642, void, self, &one_shot)
}
godot_bool godot_AnimatedTexture_get_one_shot(const godot_AnimatedTexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimatedTexture, get_one_shot, 36873697, godot_bool, self)
}
void godot_AnimatedTexture_set_speed_scale(godot_AnimatedTexture *self, godot_float scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimatedTexture, set_speed_scale, 373806689, void, self, &scale)
}
godot_float godot_AnimatedTexture_get_speed_scale(const godot_AnimatedTexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimatedTexture, get_speed_scale, 1740695150, godot_float, self)
}
void godot_AnimatedTexture_set_frame_texture(godot_AnimatedTexture *self, godot_int frame, const godot_Texture2D *texture) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimatedTexture, set_frame_texture, 666127730, void, self, &frame, texture)
}
godot_Texture2D * godot_AnimatedTexture_get_frame_texture(const godot_AnimatedTexture *self, godot_int frame) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimatedTexture, get_frame_texture, 3536238170, godot_Texture2D *, self, &frame)
}
void godot_AnimatedTexture_set_frame_duration(godot_AnimatedTexture *self, godot_int frame, godot_float duration) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimatedTexture, set_frame_duration, 1602489585, void, self, &frame, &duration)
}
godot_float godot_AnimatedTexture_get_frame_duration(const godot_AnimatedTexture *self, godot_int frame) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimatedTexture, get_frame_duration, 2339986948, godot_float, self, &frame)
}


#ifdef __cplusplus
}
#endif
