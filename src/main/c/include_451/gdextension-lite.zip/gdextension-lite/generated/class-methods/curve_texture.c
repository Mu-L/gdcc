// This file was automatically generated
// Do not modify this file
#include "curve_texture.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CurveTexture *godot_new_CurveTexture() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CurveTexture);
}

// Methods
void godot_CurveTexture_set_width(godot_CurveTexture *self, godot_int width) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CurveTexture, set_width, 1286410249, void, self, &width)
}
void godot_CurveTexture_set_curve(godot_CurveTexture *self, const godot_Curve *curve) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CurveTexture, set_curve, 270443179, void, self, curve)
}
godot_Curve * godot_CurveTexture_get_curve(const godot_CurveTexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CurveTexture, get_curve, 2460114913, godot_Curve *, self)
}
void godot_CurveTexture_set_texture_mode(godot_CurveTexture *self, godot_CurveTexture_TextureMode texture_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CurveTexture, set_texture_mode, 1321955367, void, self, &texture_mode)
}
godot_CurveTexture_TextureMode godot_CurveTexture_get_texture_mode(const godot_CurveTexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CurveTexture, get_texture_mode, 715756376, godot_CurveTexture_TextureMode, self)
}


#ifdef __cplusplus
}
#endif
