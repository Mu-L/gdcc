// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_STATE_MACHINE_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_STATE_MACHINE_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AnimationNodeStateMachine *godot_new_AnimationNodeStateMachine();

// Methods
GDEXTENSION_LITE_DECL void godot_AnimationNodeStateMachine_add_node(godot_AnimationNodeStateMachine *self, const godot_StringName *name, const godot_AnimationNode *node, const godot_Vector2 *position);
GDEXTENSION_LITE_DECL void godot_AnimationNodeStateMachine_replace_node(godot_AnimationNodeStateMachine *self, const godot_StringName *name, const godot_AnimationNode *node);
GDEXTENSION_LITE_DECL godot_AnimationNode * godot_AnimationNodeStateMachine_get_node(const godot_AnimationNodeStateMachine *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL void godot_AnimationNodeStateMachine_remove_node(godot_AnimationNodeStateMachine *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL void godot_AnimationNodeStateMachine_rename_node(godot_AnimationNodeStateMachine *self, const godot_StringName *name, const godot_StringName *new_name);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNodeStateMachine_has_node(const godot_AnimationNodeStateMachine *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL godot_StringName godot_AnimationNodeStateMachine_get_node_name(const godot_AnimationNodeStateMachine *self, const godot_AnimationNode *node);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_StringName) godot_AnimationNodeStateMachine_get_node_list(const godot_AnimationNodeStateMachine *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeStateMachine_set_node_position(godot_AnimationNodeStateMachine *self, const godot_StringName *name, const godot_Vector2 *position);
GDEXTENSION_LITE_DECL godot_Vector2 godot_AnimationNodeStateMachine_get_node_position(const godot_AnimationNodeStateMachine *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNodeStateMachine_has_transition(const godot_AnimationNodeStateMachine *self, const godot_StringName *from, const godot_StringName *to);
GDEXTENSION_LITE_DECL void godot_AnimationNodeStateMachine_add_transition(godot_AnimationNodeStateMachine *self, const godot_StringName *from, const godot_StringName *to, const godot_AnimationNodeStateMachineTransition *transition);
GDEXTENSION_LITE_DECL godot_AnimationNodeStateMachineTransition * godot_AnimationNodeStateMachine_get_transition(const godot_AnimationNodeStateMachine *self, godot_int idx);
GDEXTENSION_LITE_DECL godot_StringName godot_AnimationNodeStateMachine_get_transition_from(const godot_AnimationNodeStateMachine *self, godot_int idx);
GDEXTENSION_LITE_DECL godot_StringName godot_AnimationNodeStateMachine_get_transition_to(const godot_AnimationNodeStateMachine *self, godot_int idx);
GDEXTENSION_LITE_DECL godot_int godot_AnimationNodeStateMachine_get_transition_count(const godot_AnimationNodeStateMachine *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeStateMachine_remove_transition_by_index(godot_AnimationNodeStateMachine *self, godot_int idx);
GDEXTENSION_LITE_DECL void godot_AnimationNodeStateMachine_remove_transition(godot_AnimationNodeStateMachine *self, const godot_StringName *from, const godot_StringName *to);
GDEXTENSION_LITE_DECL void godot_AnimationNodeStateMachine_set_graph_offset(godot_AnimationNodeStateMachine *self, const godot_Vector2 *offset);
GDEXTENSION_LITE_DECL godot_Vector2 godot_AnimationNodeStateMachine_get_graph_offset(const godot_AnimationNodeStateMachine *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeStateMachine_set_state_machine_type(godot_AnimationNodeStateMachine *self, godot_AnimationNodeStateMachine_StateMachineType state_machine_type);
GDEXTENSION_LITE_DECL godot_AnimationNodeStateMachine_StateMachineType godot_AnimationNodeStateMachine_get_state_machine_type(const godot_AnimationNodeStateMachine *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeStateMachine_set_allow_transition_to_self(godot_AnimationNodeStateMachine *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNodeStateMachine_is_allow_transition_to_self(const godot_AnimationNodeStateMachine *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeStateMachine_set_reset_ends(godot_AnimationNodeStateMachine *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNodeStateMachine_are_ends_reset(const godot_AnimationNodeStateMachine *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_STATE_MACHINE_H__
