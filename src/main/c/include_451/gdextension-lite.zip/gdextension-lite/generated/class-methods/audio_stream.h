// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioStream *godot_new_AudioStream();

// Methods
GDEXTENSION_LITE_DECL godot_AudioStreamPlayback * godot_AudioStream__instantiate_playback(const godot_AudioStream *self);
GDEXTENSION_LITE_DECL godot_String godot_AudioStream__get_stream_name(const godot_AudioStream *self);
GDEXTENSION_LITE_DECL godot_float godot_AudioStream__get_length(const godot_AudioStream *self);
GDEXTENSION_LITE_DECL godot_bool godot_AudioStream__is_monophonic(const godot_AudioStream *self);
GDEXTENSION_LITE_DECL godot_float godot_AudioStream__get_bpm(const godot_AudioStream *self);
GDEXTENSION_LITE_DECL godot_int godot_AudioStream__get_beat_count(const godot_AudioStream *self);
GDEXTENSION_LITE_DECL godot_Dictionary godot_AudioStream__get_tags(const godot_AudioStream *self);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_Dictionary) godot_AudioStream__get_parameter_list(const godot_AudioStream *self);
GDEXTENSION_LITE_DECL godot_bool godot_AudioStream__has_loop(const godot_AudioStream *self);
GDEXTENSION_LITE_DECL godot_int godot_AudioStream__get_bar_beats(const godot_AudioStream *self);
GDEXTENSION_LITE_DECL godot_float godot_AudioStream_get_length(const godot_AudioStream *self);
GDEXTENSION_LITE_DECL godot_bool godot_AudioStream_is_monophonic(const godot_AudioStream *self);
GDEXTENSION_LITE_DECL godot_AudioStreamPlayback * godot_AudioStream_instantiate_playback(godot_AudioStream *self);
GDEXTENSION_LITE_DECL godot_bool godot_AudioStream_can_be_sampled(const godot_AudioStream *self);
GDEXTENSION_LITE_DECL godot_AudioSample * godot_AudioStream_generate_sample(const godot_AudioStream *self);
GDEXTENSION_LITE_DECL godot_bool godot_AudioStream_is_meta_stream(const godot_AudioStream *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_H__
