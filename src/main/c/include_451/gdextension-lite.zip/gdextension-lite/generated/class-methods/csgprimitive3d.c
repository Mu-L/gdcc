// This file was automatically generated
// Do not modify this file
#include "csgprimitive3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
void godot_CSGPrimitive3D_set_flip_faces(godot_CSGPrimitive3D *self, godot_bool flip_faces) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGPrimitive3D, set_flip_faces, 2586408642, void, self, &flip_faces)
}
godot_bool godot_CSGPrimitive3D_get_flip_faces(godot_CSGPrimitive3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGPrimitive3D, get_flip_faces, 2240911060, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
