// This file was automatically generated
// Do not modify this file
#include "character_body2d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CharacterBody2D *godot_new_CharacterBody2D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CharacterBody2D);
}

// Methods
godot_bool godot_CharacterBody2D_move_and_slide(godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, move_and_slide, 2240911060, godot_bool, self)
}
void godot_CharacterBody2D_apply_floor_snap(godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharacterBody2D, apply_floor_snap, 3218959716, void, self)
}
void godot_CharacterBody2D_set_velocity(godot_CharacterBody2D *self, const godot_Vector2 *velocity) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharacterBody2D, set_velocity, 743155724, void, self, velocity)
}
godot_Vector2 godot_CharacterBody2D_get_velocity(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, get_velocity, 3341600327, godot_Vector2, self)
}
void godot_CharacterBody2D_set_safe_margin(godot_CharacterBody2D *self, godot_float margin) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharacterBody2D, set_safe_margin, 373806689, void, self, &margin)
}
godot_float godot_CharacterBody2D_get_safe_margin(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, get_safe_margin, 1740695150, godot_float, self)
}
godot_bool godot_CharacterBody2D_is_floor_stop_on_slope_enabled(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, is_floor_stop_on_slope_enabled, 36873697, godot_bool, self)
}
void godot_CharacterBody2D_set_floor_stop_on_slope_enabled(godot_CharacterBody2D *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharacterBody2D, set_floor_stop_on_slope_enabled, 2586408642, void, self, &enabled)
}
void godot_CharacterBody2D_set_floor_constant_speed_enabled(godot_CharacterBody2D *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharacterBody2D, set_floor_constant_speed_enabled, 2586408642, void, self, &enabled)
}
godot_bool godot_CharacterBody2D_is_floor_constant_speed_enabled(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, is_floor_constant_speed_enabled, 36873697, godot_bool, self)
}
void godot_CharacterBody2D_set_floor_block_on_wall_enabled(godot_CharacterBody2D *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharacterBody2D, set_floor_block_on_wall_enabled, 2586408642, void, self, &enabled)
}
godot_bool godot_CharacterBody2D_is_floor_block_on_wall_enabled(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, is_floor_block_on_wall_enabled, 36873697, godot_bool, self)
}
void godot_CharacterBody2D_set_slide_on_ceiling_enabled(godot_CharacterBody2D *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharacterBody2D, set_slide_on_ceiling_enabled, 2586408642, void, self, &enabled)
}
godot_bool godot_CharacterBody2D_is_slide_on_ceiling_enabled(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, is_slide_on_ceiling_enabled, 36873697, godot_bool, self)
}
void godot_CharacterBody2D_set_platform_floor_layers(godot_CharacterBody2D *self, godot_int exclude_layer) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharacterBody2D, set_platform_floor_layers, 1286410249, void, self, &exclude_layer)
}
godot_int godot_CharacterBody2D_get_platform_floor_layers(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, get_platform_floor_layers, 3905245786, godot_int, self)
}
void godot_CharacterBody2D_set_platform_wall_layers(godot_CharacterBody2D *self, godot_int exclude_layer) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharacterBody2D, set_platform_wall_layers, 1286410249, void, self, &exclude_layer)
}
godot_int godot_CharacterBody2D_get_platform_wall_layers(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, get_platform_wall_layers, 3905245786, godot_int, self)
}
godot_int godot_CharacterBody2D_get_max_slides(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, get_max_slides, 3905245786, godot_int, self)
}
void godot_CharacterBody2D_set_max_slides(godot_CharacterBody2D *self, godot_int max_slides) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharacterBody2D, set_max_slides, 1286410249, void, self, &max_slides)
}
godot_float godot_CharacterBody2D_get_floor_max_angle(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, get_floor_max_angle, 1740695150, godot_float, self)
}
void godot_CharacterBody2D_set_floor_max_angle(godot_CharacterBody2D *self, godot_float radians) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharacterBody2D, set_floor_max_angle, 373806689, void, self, &radians)
}
godot_float godot_CharacterBody2D_get_floor_snap_length(godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, get_floor_snap_length, 191475506, godot_float, self)
}
void godot_CharacterBody2D_set_floor_snap_length(godot_CharacterBody2D *self, godot_float floor_snap_length) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharacterBody2D, set_floor_snap_length, 373806689, void, self, &floor_snap_length)
}
godot_float godot_CharacterBody2D_get_wall_min_slide_angle(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, get_wall_min_slide_angle, 1740695150, godot_float, self)
}
void godot_CharacterBody2D_set_wall_min_slide_angle(godot_CharacterBody2D *self, godot_float radians) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharacterBody2D, set_wall_min_slide_angle, 373806689, void, self, &radians)
}
godot_Vector2 godot_CharacterBody2D_get_up_direction(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, get_up_direction, 3341600327, godot_Vector2, self)
}
void godot_CharacterBody2D_set_up_direction(godot_CharacterBody2D *self, const godot_Vector2 *up_direction) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharacterBody2D, set_up_direction, 743155724, void, self, up_direction)
}
void godot_CharacterBody2D_set_motion_mode(godot_CharacterBody2D *self, godot_CharacterBody2D_MotionMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharacterBody2D, set_motion_mode, 1224392233, void, self, &mode)
}
godot_CharacterBody2D_MotionMode godot_CharacterBody2D_get_motion_mode(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, get_motion_mode, 1160151236, godot_CharacterBody2D_MotionMode, self)
}
void godot_CharacterBody2D_set_platform_on_leave(godot_CharacterBody2D *self, godot_CharacterBody2D_PlatformOnLeave on_leave_apply_velocity) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CharacterBody2D, set_platform_on_leave, 2423324375, void, self, &on_leave_apply_velocity)
}
godot_CharacterBody2D_PlatformOnLeave godot_CharacterBody2D_get_platform_on_leave(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, get_platform_on_leave, 4054324341, godot_CharacterBody2D_PlatformOnLeave, self)
}
godot_bool godot_CharacterBody2D_is_on_floor(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, is_on_floor, 36873697, godot_bool, self)
}
godot_bool godot_CharacterBody2D_is_on_floor_only(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, is_on_floor_only, 36873697, godot_bool, self)
}
godot_bool godot_CharacterBody2D_is_on_ceiling(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, is_on_ceiling, 36873697, godot_bool, self)
}
godot_bool godot_CharacterBody2D_is_on_ceiling_only(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, is_on_ceiling_only, 36873697, godot_bool, self)
}
godot_bool godot_CharacterBody2D_is_on_wall(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, is_on_wall, 36873697, godot_bool, self)
}
godot_bool godot_CharacterBody2D_is_on_wall_only(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, is_on_wall_only, 36873697, godot_bool, self)
}
godot_Vector2 godot_CharacterBody2D_get_floor_normal(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, get_floor_normal, 3341600327, godot_Vector2, self)
}
godot_Vector2 godot_CharacterBody2D_get_wall_normal(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, get_wall_normal, 3341600327, godot_Vector2, self)
}
godot_Vector2 godot_CharacterBody2D_get_last_motion(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, get_last_motion, 3341600327, godot_Vector2, self)
}
godot_Vector2 godot_CharacterBody2D_get_position_delta(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, get_position_delta, 3341600327, godot_Vector2, self)
}
godot_Vector2 godot_CharacterBody2D_get_real_velocity(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, get_real_velocity, 3341600327, godot_Vector2, self)
}
godot_float godot_CharacterBody2D_get_floor_angle(const godot_CharacterBody2D *self, const godot_Vector2 *up_direction) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, get_floor_angle, 2841063350, godot_float, self, up_direction)
}
godot_Vector2 godot_CharacterBody2D_get_platform_velocity(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, get_platform_velocity, 3341600327, godot_Vector2, self)
}
godot_int godot_CharacterBody2D_get_slide_collision_count(const godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, get_slide_collision_count, 3905245786, godot_int, self)
}
godot_KinematicCollision2D * godot_CharacterBody2D_get_slide_collision(godot_CharacterBody2D *self, godot_int slide_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, get_slide_collision, 860659811, godot_KinematicCollision2D *, self, &slide_idx)
}
godot_KinematicCollision2D * godot_CharacterBody2D_get_last_slide_collision(godot_CharacterBody2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CharacterBody2D, get_last_slide_collision, 2161834755, godot_KinematicCollision2D *, self)
}


#ifdef __cplusplus
}
#endif
