// This file was automatically generated
// Do not modify this file
#include "editor_import_plugin.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorImportPlugin *godot_new_EditorImportPlugin() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorImportPlugin);
}

// Methods
godot_String godot_EditorImportPlugin__get_importer_name(const godot_EditorImportPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorImportPlugin, _get_importer_name, 201670096, godot_String, self)
}
godot_String godot_EditorImportPlugin__get_visible_name(const godot_EditorImportPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorImportPlugin, _get_visible_name, 201670096, godot_String, self)
}
godot_int godot_EditorImportPlugin__get_preset_count(const godot_EditorImportPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorImportPlugin, _get_preset_count, 3905245786, godot_int, self)
}
godot_String godot_EditorImportPlugin__get_preset_name(const godot_EditorImportPlugin *self, godot_int preset_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorImportPlugin, _get_preset_name, 844755477, godot_String, self, &preset_index)
}
godot_PackedStringArray godot_EditorImportPlugin__get_recognized_extensions(const godot_EditorImportPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorImportPlugin, _get_recognized_extensions, 1139954409, godot_PackedStringArray, self)
}
godot_TypedArray(godot_Dictionary) godot_EditorImportPlugin__get_import_options(const godot_EditorImportPlugin *self, const godot_String *path, godot_int preset_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorImportPlugin, _get_import_options, 520498173, godot_TypedArray(godot_Dictionary), self, path, &preset_index)
}
godot_String godot_EditorImportPlugin__get_save_extension(const godot_EditorImportPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorImportPlugin, _get_save_extension, 201670096, godot_String, self)
}
godot_String godot_EditorImportPlugin__get_resource_type(const godot_EditorImportPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorImportPlugin, _get_resource_type, 201670096, godot_String, self)
}
godot_float godot_EditorImportPlugin__get_priority(const godot_EditorImportPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorImportPlugin, _get_priority, 1740695150, godot_float, self)
}
godot_int godot_EditorImportPlugin__get_import_order(const godot_EditorImportPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorImportPlugin, _get_import_order, 3905245786, godot_int, self)
}
godot_int godot_EditorImportPlugin__get_format_version(const godot_EditorImportPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorImportPlugin, _get_format_version, 3905245786, godot_int, self)
}
godot_bool godot_EditorImportPlugin__get_option_visibility(const godot_EditorImportPlugin *self, const godot_String *path, const godot_StringName *option_name, const godot_Dictionary *options) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorImportPlugin, _get_option_visibility, 240466755, godot_bool, self, path, option_name, options)
}
godot_Error godot_EditorImportPlugin__import(const godot_EditorImportPlugin *self, const godot_String *source_file, const godot_String *save_path, const godot_Dictionary *options, const godot_TypedArray(godot_String) *platform_variants, const godot_TypedArray(godot_String) *gen_files) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorImportPlugin, _import, 4108152118, godot_Error, self, source_file, save_path, options, platform_variants, gen_files)
}
godot_bool godot_EditorImportPlugin__can_import_threaded(const godot_EditorImportPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorImportPlugin, _can_import_threaded, 36873697, godot_bool, self)
}
godot_Error godot_EditorImportPlugin_append_import_external_resource(godot_EditorImportPlugin *self, const godot_String *path, const godot_Dictionary *custom_options, const godot_String *custom_importer, const godot_Variant *generator_parameters) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorImportPlugin, append_import_external_resource, 320493106, godot_Error, self, path, custom_options, custom_importer, generator_parameters)
}


#ifdef __cplusplus
}
#endif
