// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_NODE3DGIZMO_PLUGIN_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_NODE3DGIZMO_PLUGIN_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorNode3DGizmoPlugin *godot_new_EditorNode3DGizmoPlugin();

// Methods
GDEXTENSION_LITE_DECL godot_bool godot_EditorNode3DGizmoPlugin__has_gizmo(const godot_EditorNode3DGizmoPlugin *self, const godot_Node3D *for_node_3d);
GDEXTENSION_LITE_DECL godot_EditorNode3DGizmo * godot_EditorNode3DGizmoPlugin__create_gizmo(const godot_EditorNode3DGizmoPlugin *self, const godot_Node3D *for_node_3d);
GDEXTENSION_LITE_DECL godot_String godot_EditorNode3DGizmoPlugin__get_gizmo_name(const godot_EditorNode3DGizmoPlugin *self);
GDEXTENSION_LITE_DECL godot_int godot_EditorNode3DGizmoPlugin__get_priority(const godot_EditorNode3DGizmoPlugin *self);
GDEXTENSION_LITE_DECL godot_bool godot_EditorNode3DGizmoPlugin__can_be_hidden(const godot_EditorNode3DGizmoPlugin *self);
GDEXTENSION_LITE_DECL godot_bool godot_EditorNode3DGizmoPlugin__is_selectable_when_hidden(const godot_EditorNode3DGizmoPlugin *self);
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmoPlugin__redraw(godot_EditorNode3DGizmoPlugin *self, const godot_EditorNode3DGizmo *gizmo);
GDEXTENSION_LITE_DECL godot_String godot_EditorNode3DGizmoPlugin__get_handle_name(const godot_EditorNode3DGizmoPlugin *self, const godot_EditorNode3DGizmo *gizmo, godot_int handle_id, godot_bool secondary);
GDEXTENSION_LITE_DECL godot_bool godot_EditorNode3DGizmoPlugin__is_handle_highlighted(const godot_EditorNode3DGizmoPlugin *self, const godot_EditorNode3DGizmo *gizmo, godot_int handle_id, godot_bool secondary);
GDEXTENSION_LITE_DECL godot_Variant godot_EditorNode3DGizmoPlugin__get_handle_value(const godot_EditorNode3DGizmoPlugin *self, const godot_EditorNode3DGizmo *gizmo, godot_int handle_id, godot_bool secondary);
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmoPlugin__begin_handle_action(godot_EditorNode3DGizmoPlugin *self, const godot_EditorNode3DGizmo *gizmo, godot_int handle_id, godot_bool secondary);
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmoPlugin__set_handle(godot_EditorNode3DGizmoPlugin *self, const godot_EditorNode3DGizmo *gizmo, godot_int handle_id, godot_bool secondary, const godot_Camera3D *camera, const godot_Vector2 *screen_pos);
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmoPlugin__commit_handle(godot_EditorNode3DGizmoPlugin *self, const godot_EditorNode3DGizmo *gizmo, godot_int handle_id, godot_bool secondary, const godot_Variant *restore, godot_bool cancel);
GDEXTENSION_LITE_DECL godot_int godot_EditorNode3DGizmoPlugin__subgizmos_intersect_ray(const godot_EditorNode3DGizmoPlugin *self, const godot_EditorNode3DGizmo *gizmo, const godot_Camera3D *camera, const godot_Vector2 *screen_pos);
GDEXTENSION_LITE_DECL godot_PackedInt32Array godot_EditorNode3DGizmoPlugin__subgizmos_intersect_frustum(const godot_EditorNode3DGizmoPlugin *self, const godot_EditorNode3DGizmo *gizmo, const godot_Camera3D *camera, const godot_TypedArray(godot_Plane) *frustum_planes);
GDEXTENSION_LITE_DECL godot_Transform3D godot_EditorNode3DGizmoPlugin__get_subgizmo_transform(const godot_EditorNode3DGizmoPlugin *self, const godot_EditorNode3DGizmo *gizmo, godot_int subgizmo_id);
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmoPlugin__set_subgizmo_transform(godot_EditorNode3DGizmoPlugin *self, const godot_EditorNode3DGizmo *gizmo, godot_int subgizmo_id, const godot_Transform3D *transform);
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmoPlugin__commit_subgizmos(godot_EditorNode3DGizmoPlugin *self, const godot_EditorNode3DGizmo *gizmo, const godot_PackedInt32Array *ids, const godot_TypedArray(godot_Transform3D) *restores, godot_bool cancel);
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmoPlugin_create_material(godot_EditorNode3DGizmoPlugin *self, const godot_String *name, const godot_Color *color, godot_bool billboard, godot_bool on_top, godot_bool use_vertex_color);
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmoPlugin_create_icon_material(godot_EditorNode3DGizmoPlugin *self, const godot_String *name, const godot_Texture2D *texture, godot_bool on_top, const godot_Color *color);
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmoPlugin_create_handle_material(godot_EditorNode3DGizmoPlugin *self, const godot_String *name, godot_bool billboard, const godot_Texture2D *texture);
GDEXTENSION_LITE_DECL void godot_EditorNode3DGizmoPlugin_add_material(godot_EditorNode3DGizmoPlugin *self, const godot_String *name, const godot_StandardMaterial3D *material);
GDEXTENSION_LITE_DECL godot_StandardMaterial3D * godot_EditorNode3DGizmoPlugin_get_material(godot_EditorNode3DGizmoPlugin *self, const godot_String *name, const godot_EditorNode3DGizmo *gizmo);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_NODE3DGIZMO_PLUGIN_H__
