// This file was automatically generated
// Do not modify this file
#include "astar_grid2d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AStarGrid2D *godot_new_AStarGrid2D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AStarGrid2D);
}

// Methods
godot_float godot_AStarGrid2D__estimate_cost(const godot_AStarGrid2D *self, const godot_Vector2i *from_id, const godot_Vector2i *end_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStarGrid2D, _estimate_cost, 2153177966, godot_float, self, from_id, end_id)
}
godot_float godot_AStarGrid2D__compute_cost(const godot_AStarGrid2D *self, const godot_Vector2i *from_id, const godot_Vector2i *to_id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStarGrid2D, _compute_cost, 2153177966, godot_float, self, from_id, to_id)
}
void godot_AStarGrid2D_set_region(godot_AStarGrid2D *self, const godot_Rect2i *region) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStarGrid2D, set_region, 1763793166, void, self, region)
}
godot_Rect2i godot_AStarGrid2D_get_region(const godot_AStarGrid2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStarGrid2D, get_region, 410525958, godot_Rect2i, self)
}
void godot_AStarGrid2D_set_size(godot_AStarGrid2D *self, const godot_Vector2i *size) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStarGrid2D, set_size, 1130785943, void, self, size)
}
godot_Vector2i godot_AStarGrid2D_get_size(const godot_AStarGrid2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStarGrid2D, get_size, 3690982128, godot_Vector2i, self)
}
void godot_AStarGrid2D_set_offset(godot_AStarGrid2D *self, const godot_Vector2 *offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStarGrid2D, set_offset, 743155724, void, self, offset)
}
godot_Vector2 godot_AStarGrid2D_get_offset(const godot_AStarGrid2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStarGrid2D, get_offset, 3341600327, godot_Vector2, self)
}
void godot_AStarGrid2D_set_cell_size(godot_AStarGrid2D *self, const godot_Vector2 *cell_size) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStarGrid2D, set_cell_size, 743155724, void, self, cell_size)
}
godot_Vector2 godot_AStarGrid2D_get_cell_size(const godot_AStarGrid2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStarGrid2D, get_cell_size, 3341600327, godot_Vector2, self)
}
void godot_AStarGrid2D_set_cell_shape(godot_AStarGrid2D *self, godot_AStarGrid2D_CellShape cell_shape) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStarGrid2D, set_cell_shape, 4130591146, void, self, &cell_shape)
}
godot_AStarGrid2D_CellShape godot_AStarGrid2D_get_cell_shape(const godot_AStarGrid2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStarGrid2D, get_cell_shape, 3293463634, godot_AStarGrid2D_CellShape, self)
}
godot_bool godot_AStarGrid2D_is_in_bounds(const godot_AStarGrid2D *self, godot_int x, godot_int y) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStarGrid2D, is_in_bounds, 2522259332, godot_bool, self, &x, &y)
}
godot_bool godot_AStarGrid2D_is_in_boundsv(const godot_AStarGrid2D *self, const godot_Vector2i *id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStarGrid2D, is_in_boundsv, 3900751641, godot_bool, self, id)
}
godot_bool godot_AStarGrid2D_is_dirty(const godot_AStarGrid2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStarGrid2D, is_dirty, 36873697, godot_bool, self)
}
void godot_AStarGrid2D_update(godot_AStarGrid2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStarGrid2D, update, 3218959716, void, self)
}
void godot_AStarGrid2D_set_jumping_enabled(godot_AStarGrid2D *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStarGrid2D, set_jumping_enabled, 2586408642, void, self, &enabled)
}
godot_bool godot_AStarGrid2D_is_jumping_enabled(const godot_AStarGrid2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStarGrid2D, is_jumping_enabled, 36873697, godot_bool, self)
}
void godot_AStarGrid2D_set_diagonal_mode(godot_AStarGrid2D *self, godot_AStarGrid2D_DiagonalMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStarGrid2D, set_diagonal_mode, 1017829798, void, self, &mode)
}
godot_AStarGrid2D_DiagonalMode godot_AStarGrid2D_get_diagonal_mode(const godot_AStarGrid2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStarGrid2D, get_diagonal_mode, 3129282674, godot_AStarGrid2D_DiagonalMode, self)
}
void godot_AStarGrid2D_set_default_compute_heuristic(godot_AStarGrid2D *self, godot_AStarGrid2D_Heuristic heuristic) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStarGrid2D, set_default_compute_heuristic, 1044375519, void, self, &heuristic)
}
godot_AStarGrid2D_Heuristic godot_AStarGrid2D_get_default_compute_heuristic(const godot_AStarGrid2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStarGrid2D, get_default_compute_heuristic, 2074731422, godot_AStarGrid2D_Heuristic, self)
}
void godot_AStarGrid2D_set_default_estimate_heuristic(godot_AStarGrid2D *self, godot_AStarGrid2D_Heuristic heuristic) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStarGrid2D, set_default_estimate_heuristic, 1044375519, void, self, &heuristic)
}
godot_AStarGrid2D_Heuristic godot_AStarGrid2D_get_default_estimate_heuristic(const godot_AStarGrid2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStarGrid2D, get_default_estimate_heuristic, 2074731422, godot_AStarGrid2D_Heuristic, self)
}
void godot_AStarGrid2D_set_point_solid(godot_AStarGrid2D *self, const godot_Vector2i *id, godot_bool solid) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStarGrid2D, set_point_solid, 1765703753, void, self, id, &solid)
}
godot_bool godot_AStarGrid2D_is_point_solid(const godot_AStarGrid2D *self, const godot_Vector2i *id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStarGrid2D, is_point_solid, 3900751641, godot_bool, self, id)
}
void godot_AStarGrid2D_set_point_weight_scale(godot_AStarGrid2D *self, const godot_Vector2i *id, godot_float weight_scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStarGrid2D, set_point_weight_scale, 2262553149, void, self, id, &weight_scale)
}
godot_float godot_AStarGrid2D_get_point_weight_scale(const godot_AStarGrid2D *self, const godot_Vector2i *id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStarGrid2D, get_point_weight_scale, 719993801, godot_float, self, id)
}
void godot_AStarGrid2D_fill_solid_region(godot_AStarGrid2D *self, const godot_Rect2i *region, godot_bool solid) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStarGrid2D, fill_solid_region, 2261970063, void, self, region, &solid)
}
void godot_AStarGrid2D_fill_weight_scale_region(godot_AStarGrid2D *self, const godot_Rect2i *region, godot_float weight_scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStarGrid2D, fill_weight_scale_region, 2793244083, void, self, region, &weight_scale)
}
void godot_AStarGrid2D_clear(godot_AStarGrid2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AStarGrid2D, clear, 3218959716, void, self)
}
godot_Vector2 godot_AStarGrid2D_get_point_position(const godot_AStarGrid2D *self, const godot_Vector2i *id) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStarGrid2D, get_point_position, 108438297, godot_Vector2, self, id)
}
godot_TypedArray(godot_Dictionary) godot_AStarGrid2D_get_point_data_in_region(const godot_AStarGrid2D *self, const godot_Rect2i *region) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStarGrid2D, get_point_data_in_region, 3893818462, godot_TypedArray(godot_Dictionary), self, region)
}
godot_PackedVector2Array godot_AStarGrid2D_get_point_path(godot_AStarGrid2D *self, const godot_Vector2i *from_id, const godot_Vector2i *to_id, godot_bool allow_partial_path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStarGrid2D, get_point_path, 1641925693, godot_PackedVector2Array, self, from_id, to_id, &allow_partial_path)
}
godot_TypedArray(godot_Vector2i) godot_AStarGrid2D_get_id_path(godot_AStarGrid2D *self, const godot_Vector2i *from_id, const godot_Vector2i *to_id, godot_bool allow_partial_path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AStarGrid2D, get_id_path, 1918132273, godot_TypedArray(godot_Vector2i), self, from_id, to_id, &allow_partial_path)
}


#ifdef __cplusplus
}
#endif
