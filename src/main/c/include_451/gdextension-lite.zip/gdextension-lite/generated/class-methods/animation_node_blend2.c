// This file was automatically generated
// Do not modify this file
#include "animation_node_blend2.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimationNodeBlend2 *godot_new_AnimationNodeBlend2() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimationNodeBlend2);
}


#ifdef __cplusplus
}
#endif
