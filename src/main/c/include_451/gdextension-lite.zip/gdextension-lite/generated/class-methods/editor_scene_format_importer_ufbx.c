// This file was automatically generated
// Do not modify this file
#include "editor_scene_format_importer_ufbx.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorSceneFormatImporterUFBX *godot_new_EditorSceneFormatImporterUFBX() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorSceneFormatImporterUFBX);
}


#ifdef __cplusplus
}
#endif
