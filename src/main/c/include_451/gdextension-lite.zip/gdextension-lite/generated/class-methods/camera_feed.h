// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAMERA_FEED_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAMERA_FEED_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CameraFeed *godot_new_CameraFeed();

// Methods
GDEXTENSION_LITE_DECL godot_bool godot_CameraFeed__activate_feed(godot_CameraFeed *self);
GDEXTENSION_LITE_DECL void godot_CameraFeed__deactivate_feed(godot_CameraFeed *self);
GDEXTENSION_LITE_DECL godot_int godot_CameraFeed_get_id(const godot_CameraFeed *self);
GDEXTENSION_LITE_DECL godot_bool godot_CameraFeed_is_active(const godot_CameraFeed *self);
GDEXTENSION_LITE_DECL void godot_CameraFeed_set_active(godot_CameraFeed *self, godot_bool active);
GDEXTENSION_LITE_DECL godot_String godot_CameraFeed_get_name(const godot_CameraFeed *self);
GDEXTENSION_LITE_DECL void godot_CameraFeed_set_name(godot_CameraFeed *self, const godot_String *name);
GDEXTENSION_LITE_DECL godot_CameraFeed_FeedPosition godot_CameraFeed_get_position(const godot_CameraFeed *self);
GDEXTENSION_LITE_DECL void godot_CameraFeed_set_position(godot_CameraFeed *self, godot_CameraFeed_FeedPosition position);
GDEXTENSION_LITE_DECL godot_Transform2D godot_CameraFeed_get_transform(const godot_CameraFeed *self);
GDEXTENSION_LITE_DECL void godot_CameraFeed_set_transform(godot_CameraFeed *self, const godot_Transform2D *transform);
GDEXTENSION_LITE_DECL void godot_CameraFeed_set_rgb_image(godot_CameraFeed *self, const godot_Image *rgb_image);
GDEXTENSION_LITE_DECL void godot_CameraFeed_set_ycbcr_image(godot_CameraFeed *self, const godot_Image *ycbcr_image);
GDEXTENSION_LITE_DECL void godot_CameraFeed_set_external(godot_CameraFeed *self, godot_int width, godot_int height);
GDEXTENSION_LITE_DECL godot_int godot_CameraFeed_get_texture_tex_id(godot_CameraFeed *self, godot_CameraServer_FeedImage feed_image_type);
GDEXTENSION_LITE_DECL godot_CameraFeed_FeedDataType godot_CameraFeed_get_datatype(const godot_CameraFeed *self);
GDEXTENSION_LITE_DECL godot_Array godot_CameraFeed_get_formats(const godot_CameraFeed *self);
GDEXTENSION_LITE_DECL godot_bool godot_CameraFeed_set_format(godot_CameraFeed *self, godot_int index, const godot_Dictionary *parameters);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAMERA_FEED_H__
