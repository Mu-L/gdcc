// This file was automatically generated
// Do not modify this file
#include "compressed_texture2darray.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CompressedTexture2DArray *godot_new_CompressedTexture2DArray() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CompressedTexture2DArray);
}


#ifdef __cplusplus
}
#endif
