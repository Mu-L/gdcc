// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAMERA_TEXTURE_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAMERA_TEXTURE_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CameraTexture *godot_new_CameraTexture();

// Methods
GDEXTENSION_LITE_DECL void godot_CameraTexture_set_camera_feed_id(godot_CameraTexture *self, godot_int feed_id);
GDEXTENSION_LITE_DECL godot_int godot_CameraTexture_get_camera_feed_id(const godot_CameraTexture *self);
GDEXTENSION_LITE_DECL void godot_CameraTexture_set_which_feed(godot_CameraTexture *self, godot_CameraServer_FeedImage which_feed);
GDEXTENSION_LITE_DECL godot_CameraServer_FeedImage godot_CameraTexture_get_which_feed(const godot_CameraTexture *self);
GDEXTENSION_LITE_DECL void godot_CameraTexture_set_camera_active(godot_CameraTexture *self, godot_bool active);
GDEXTENSION_LITE_DECL godot_bool godot_CameraTexture_get_camera_active(const godot_CameraTexture *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAMERA_TEXTURE_H__
