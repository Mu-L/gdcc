// This file was automatically generated
// Do not modify this file
#include "editor_export_platform_mac_os.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorExportPlatformMacOS *godot_new_EditorExportPlatformMacOS() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorExportPlatformMacOS);
}


#ifdef __cplusplus
}
#endif
