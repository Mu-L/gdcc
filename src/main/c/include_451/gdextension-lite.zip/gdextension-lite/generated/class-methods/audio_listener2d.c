// This file was automatically generated
// Do not modify this file
#include "audio_listener2d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioListener2D *godot_new_AudioListener2D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioListener2D);
}

// Methods
void godot_AudioListener2D_make_current(godot_AudioListener2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioListener2D, make_current, 3218959716, void, self)
}
void godot_AudioListener2D_clear_current(godot_AudioListener2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioListener2D, clear_current, 3218959716, void, self)
}
godot_bool godot_AudioListener2D_is_current(const godot_AudioListener2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioListener2D, is_current, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
