// This file was automatically generated
// Do not modify this file
#include "editor_file_dialog.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorFileDialog *godot_new_EditorFileDialog() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorFileDialog);
}

// Methods
void godot_EditorFileDialog_clear_filters(godot_EditorFileDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileDialog, clear_filters, 3218959716, void, self)
}
void godot_EditorFileDialog_add_filter(godot_EditorFileDialog *self, const godot_String *filter, const godot_String *description) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileDialog, add_filter, 3388804757, void, self, filter, description)
}
void godot_EditorFileDialog_set_filters(godot_EditorFileDialog *self, const godot_PackedStringArray *filters) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileDialog, set_filters, 4015028928, void, self, filters)
}
godot_PackedStringArray godot_EditorFileDialog_get_filters(const godot_EditorFileDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileDialog, get_filters, 1139954409, godot_PackedStringArray, self)
}
godot_String godot_EditorFileDialog_get_option_name(const godot_EditorFileDialog *self, godot_int option) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileDialog, get_option_name, 844755477, godot_String, self, &option)
}
godot_PackedStringArray godot_EditorFileDialog_get_option_values(const godot_EditorFileDialog *self, godot_int option) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileDialog, get_option_values, 647634434, godot_PackedStringArray, self, &option)
}
godot_int godot_EditorFileDialog_get_option_default(const godot_EditorFileDialog *self, godot_int option) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileDialog, get_option_default, 923996154, godot_int, self, &option)
}
void godot_EditorFileDialog_set_option_name(godot_EditorFileDialog *self, godot_int option, const godot_String *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileDialog, set_option_name, 501894301, void, self, &option, name)
}
void godot_EditorFileDialog_set_option_values(godot_EditorFileDialog *self, godot_int option, const godot_PackedStringArray *values) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileDialog, set_option_values, 3353661094, void, self, &option, values)
}
void godot_EditorFileDialog_set_option_default(godot_EditorFileDialog *self, godot_int option, godot_int default_value_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileDialog, set_option_default, 3937882851, void, self, &option, &default_value_index)
}
void godot_EditorFileDialog_set_option_count(godot_EditorFileDialog *self, godot_int count) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileDialog, set_option_count, 1286410249, void, self, &count)
}
godot_int godot_EditorFileDialog_get_option_count(const godot_EditorFileDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileDialog, get_option_count, 3905245786, godot_int, self)
}
void godot_EditorFileDialog_add_option(godot_EditorFileDialog *self, const godot_String *name, const godot_PackedStringArray *values, godot_int default_value_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileDialog, add_option, 149592325, void, self, name, values, &default_value_index)
}
godot_Dictionary godot_EditorFileDialog_get_selected_options(const godot_EditorFileDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileDialog, get_selected_options, 3102165223, godot_Dictionary, self)
}
void godot_EditorFileDialog_clear_filename_filter(godot_EditorFileDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileDialog, clear_filename_filter, 3218959716, void, self)
}
void godot_EditorFileDialog_set_filename_filter(godot_EditorFileDialog *self, const godot_String *filter) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileDialog, set_filename_filter, 83702148, void, self, filter)
}
godot_String godot_EditorFileDialog_get_filename_filter(const godot_EditorFileDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileDialog, get_filename_filter, 201670096, godot_String, self)
}
godot_String godot_EditorFileDialog_get_current_dir(const godot_EditorFileDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileDialog, get_current_dir, 201670096, godot_String, self)
}
godot_String godot_EditorFileDialog_get_current_file(const godot_EditorFileDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileDialog, get_current_file, 201670096, godot_String, self)
}
godot_String godot_EditorFileDialog_get_current_path(const godot_EditorFileDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileDialog, get_current_path, 201670096, godot_String, self)
}
void godot_EditorFileDialog_set_current_dir(godot_EditorFileDialog *self, const godot_String *dir) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileDialog, set_current_dir, 83702148, void, self, dir)
}
void godot_EditorFileDialog_set_current_file(godot_EditorFileDialog *self, const godot_String *file) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileDialog, set_current_file, 83702148, void, self, file)
}
void godot_EditorFileDialog_set_current_path(godot_EditorFileDialog *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileDialog, set_current_path, 83702148, void, self, path)
}
void godot_EditorFileDialog_set_file_mode(godot_EditorFileDialog *self, godot_EditorFileDialog_FileMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileDialog, set_file_mode, 274150415, void, self, &mode)
}
godot_EditorFileDialog_FileMode godot_EditorFileDialog_get_file_mode(const godot_EditorFileDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileDialog, get_file_mode, 2681044145, godot_EditorFileDialog_FileMode, self)
}
godot_VBoxContainer * godot_EditorFileDialog_get_vbox(godot_EditorFileDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileDialog, get_vbox, 915758477, godot_VBoxContainer *, self)
}
godot_LineEdit * godot_EditorFileDialog_get_line_edit(godot_EditorFileDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileDialog, get_line_edit, 4071694264, godot_LineEdit *, self)
}
void godot_EditorFileDialog_set_access(godot_EditorFileDialog *self, godot_EditorFileDialog_Access access) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileDialog, set_access, 3882893764, void, self, &access)
}
godot_EditorFileDialog_Access godot_EditorFileDialog_get_access(const godot_EditorFileDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileDialog, get_access, 778734016, godot_EditorFileDialog_Access, self)
}
void godot_EditorFileDialog_set_show_hidden_files(godot_EditorFileDialog *self, godot_bool show) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileDialog, set_show_hidden_files, 2586408642, void, self, &show)
}
godot_bool godot_EditorFileDialog_is_showing_hidden_files(const godot_EditorFileDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileDialog, is_showing_hidden_files, 36873697, godot_bool, self)
}
void godot_EditorFileDialog_set_display_mode(godot_EditorFileDialog *self, godot_EditorFileDialog_DisplayMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileDialog, set_display_mode, 3049004050, void, self, &mode)
}
godot_EditorFileDialog_DisplayMode godot_EditorFileDialog_get_display_mode(const godot_EditorFileDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileDialog, get_display_mode, 3517174669, godot_EditorFileDialog_DisplayMode, self)
}
void godot_EditorFileDialog_set_disable_overwrite_warning(godot_EditorFileDialog *self, godot_bool disable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileDialog, set_disable_overwrite_warning, 2586408642, void, self, &disable)
}
godot_bool godot_EditorFileDialog_is_overwrite_warning_disabled(const godot_EditorFileDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileDialog, is_overwrite_warning_disabled, 36873697, godot_bool, self)
}
void godot_EditorFileDialog_add_side_menu(godot_EditorFileDialog *self, const godot_Control *menu, const godot_String *title) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileDialog, add_side_menu, 402368861, void, self, menu, title)
}
void godot_EditorFileDialog_popup_file_dialog(godot_EditorFileDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileDialog, popup_file_dialog, 3218959716, void, self)
}
void godot_EditorFileDialog_invalidate(godot_EditorFileDialog *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorFileDialog, invalidate, 3218959716, void, self)
}


#ifdef __cplusplus
}
#endif
