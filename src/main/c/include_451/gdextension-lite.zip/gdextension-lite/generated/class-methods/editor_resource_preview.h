// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_RESOURCE_PREVIEW_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_RESOURCE_PREVIEW_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
GDEXTENSION_LITE_DECL void godot_EditorResourcePreview_queue_resource_preview(godot_EditorResourcePreview *self, const godot_String *path, const godot_Object *receiver, const godot_StringName *receiver_func, const godot_Variant *userdata);
GDEXTENSION_LITE_DECL void godot_EditorResourcePreview_queue_edited_resource_preview(godot_EditorResourcePreview *self, const godot_Resource *resource, const godot_Object *receiver, const godot_StringName *receiver_func, const godot_Variant *userdata);
GDEXTENSION_LITE_DECL void godot_EditorResourcePreview_add_preview_generator(godot_EditorResourcePreview *self, const godot_EditorResourcePreviewGenerator *generator);
GDEXTENSION_LITE_DECL void godot_EditorResourcePreview_remove_preview_generator(godot_EditorResourcePreview *self, const godot_EditorResourcePreviewGenerator *generator);
GDEXTENSION_LITE_DECL void godot_EditorResourcePreview_check_for_invalidation(godot_EditorResourcePreview *self, const godot_String *path);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_RESOURCE_PREVIEW_H__
