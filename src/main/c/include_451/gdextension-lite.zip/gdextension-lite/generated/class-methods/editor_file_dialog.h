// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_FILE_DIALOG_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_FILE_DIALOG_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorFileDialog *godot_new_EditorFileDialog();

// Methods
GDEXTENSION_LITE_DECL void godot_EditorFileDialog_clear_filters(godot_EditorFileDialog *self);
GDEXTENSION_LITE_DECL void godot_EditorFileDialog_add_filter(godot_EditorFileDialog *self, const godot_String *filter, const godot_String *description);
GDEXTENSION_LITE_DECL void godot_EditorFileDialog_set_filters(godot_EditorFileDialog *self, const godot_PackedStringArray *filters);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_EditorFileDialog_get_filters(const godot_EditorFileDialog *self);
GDEXTENSION_LITE_DECL godot_String godot_EditorFileDialog_get_option_name(const godot_EditorFileDialog *self, godot_int option);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_EditorFileDialog_get_option_values(const godot_EditorFileDialog *self, godot_int option);
GDEXTENSION_LITE_DECL godot_int godot_EditorFileDialog_get_option_default(const godot_EditorFileDialog *self, godot_int option);
GDEXTENSION_LITE_DECL void godot_EditorFileDialog_set_option_name(godot_EditorFileDialog *self, godot_int option, const godot_String *name);
GDEXTENSION_LITE_DECL void godot_EditorFileDialog_set_option_values(godot_EditorFileDialog *self, godot_int option, const godot_PackedStringArray *values);
GDEXTENSION_LITE_DECL void godot_EditorFileDialog_set_option_default(godot_EditorFileDialog *self, godot_int option, godot_int default_value_index);
GDEXTENSION_LITE_DECL void godot_EditorFileDialog_set_option_count(godot_EditorFileDialog *self, godot_int count);
GDEXTENSION_LITE_DECL godot_int godot_EditorFileDialog_get_option_count(const godot_EditorFileDialog *self);
GDEXTENSION_LITE_DECL void godot_EditorFileDialog_add_option(godot_EditorFileDialog *self, const godot_String *name, const godot_PackedStringArray *values, godot_int default_value_index);
GDEXTENSION_LITE_DECL godot_Dictionary godot_EditorFileDialog_get_selected_options(const godot_EditorFileDialog *self);
GDEXTENSION_LITE_DECL void godot_EditorFileDialog_clear_filename_filter(godot_EditorFileDialog *self);
GDEXTENSION_LITE_DECL void godot_EditorFileDialog_set_filename_filter(godot_EditorFileDialog *self, const godot_String *filter);
GDEXTENSION_LITE_DECL godot_String godot_EditorFileDialog_get_filename_filter(const godot_EditorFileDialog *self);
GDEXTENSION_LITE_DECL godot_String godot_EditorFileDialog_get_current_dir(const godot_EditorFileDialog *self);
GDEXTENSION_LITE_DECL godot_String godot_EditorFileDialog_get_current_file(const godot_EditorFileDialog *self);
GDEXTENSION_LITE_DECL godot_String godot_EditorFileDialog_get_current_path(const godot_EditorFileDialog *self);
GDEXTENSION_LITE_DECL void godot_EditorFileDialog_set_current_dir(godot_EditorFileDialog *self, const godot_String *dir);
GDEXTENSION_LITE_DECL void godot_EditorFileDialog_set_current_file(godot_EditorFileDialog *self, const godot_String *file);
GDEXTENSION_LITE_DECL void godot_EditorFileDialog_set_current_path(godot_EditorFileDialog *self, const godot_String *path);
GDEXTENSION_LITE_DECL void godot_EditorFileDialog_set_file_mode(godot_EditorFileDialog *self, godot_EditorFileDialog_FileMode mode);
GDEXTENSION_LITE_DECL godot_EditorFileDialog_FileMode godot_EditorFileDialog_get_file_mode(const godot_EditorFileDialog *self);
GDEXTENSION_LITE_DECL godot_VBoxContainer * godot_EditorFileDialog_get_vbox(godot_EditorFileDialog *self);
GDEXTENSION_LITE_DECL godot_LineEdit * godot_EditorFileDialog_get_line_edit(godot_EditorFileDialog *self);
GDEXTENSION_LITE_DECL void godot_EditorFileDialog_set_access(godot_EditorFileDialog *self, godot_EditorFileDialog_Access access);
GDEXTENSION_LITE_DECL godot_EditorFileDialog_Access godot_EditorFileDialog_get_access(const godot_EditorFileDialog *self);
GDEXTENSION_LITE_DECL void godot_EditorFileDialog_set_show_hidden_files(godot_EditorFileDialog *self, godot_bool show);
GDEXTENSION_LITE_DECL godot_bool godot_EditorFileDialog_is_showing_hidden_files(const godot_EditorFileDialog *self);
GDEXTENSION_LITE_DECL void godot_EditorFileDialog_set_display_mode(godot_EditorFileDialog *self, godot_EditorFileDialog_DisplayMode mode);
GDEXTENSION_LITE_DECL godot_EditorFileDialog_DisplayMode godot_EditorFileDialog_get_display_mode(const godot_EditorFileDialog *self);
GDEXTENSION_LITE_DECL void godot_EditorFileDialog_set_disable_overwrite_warning(godot_EditorFileDialog *self, godot_bool disable);
GDEXTENSION_LITE_DECL godot_bool godot_EditorFileDialog_is_overwrite_warning_disabled(const godot_EditorFileDialog *self);
GDEXTENSION_LITE_DECL void godot_EditorFileDialog_add_side_menu(godot_EditorFileDialog *self, const godot_Control *menu, const godot_String *title);
GDEXTENSION_LITE_DECL void godot_EditorFileDialog_popup_file_dialog(godot_EditorFileDialog *self);
GDEXTENSION_LITE_DECL void godot_EditorFileDialog_invalidate(godot_EditorFileDialog *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_FILE_DIALOG_H__
