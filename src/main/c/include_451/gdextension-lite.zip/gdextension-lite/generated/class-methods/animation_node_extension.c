// This file was automatically generated
// Do not modify this file
#include "animation_node_extension.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimationNodeExtension *godot_new_AnimationNodeExtension() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimationNodeExtension);
}

// Methods
godot_PackedFloat32Array godot_AnimationNodeExtension__process_animation_node(godot_AnimationNodeExtension *self, const godot_PackedFloat64Array *playback_info, godot_bool test_only) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeExtension, _process_animation_node, 912931771, godot_PackedFloat32Array, self, playback_info, &test_only)
}
godot_bool godot_AnimationNodeExtension_is_looping(const godot_PackedFloat32Array *node_info) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeExtension, is_looping, 2035584311, godot_bool, NULL, node_info)
}
godot_float godot_AnimationNodeExtension_get_remaining_time(const godot_PackedFloat32Array *node_info, godot_bool break_loop) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeExtension, get_remaining_time, 2851904656, godot_float, NULL, node_info, &break_loop)
}


#ifdef __cplusplus
}
#endif
