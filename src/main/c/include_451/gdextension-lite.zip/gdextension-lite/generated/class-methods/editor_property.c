// This file was automatically generated
// Do not modify this file
#include "editor_property.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorProperty *godot_new_EditorProperty() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorProperty);
}

// Methods
void godot_EditorProperty__update_property(godot_EditorProperty *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorProperty, _update_property, 3218959716, void, self)
}
void godot_EditorProperty__set_read_only(godot_EditorProperty *self, godot_bool read_only) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorProperty, _set_read_only, 2586408642, void, self, &read_only)
}
void godot_EditorProperty_set_label(godot_EditorProperty *self, const godot_String *text) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorProperty, set_label, 83702148, void, self, text)
}
godot_String godot_EditorProperty_get_label(const godot_EditorProperty *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorProperty, get_label, 201670096, godot_String, self)
}
void godot_EditorProperty_set_read_only(godot_EditorProperty *self, godot_bool read_only) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorProperty, set_read_only, 2586408642, void, self, &read_only)
}
godot_bool godot_EditorProperty_is_read_only(const godot_EditorProperty *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorProperty, is_read_only, 36873697, godot_bool, self)
}
void godot_EditorProperty_set_draw_label(godot_EditorProperty *self, godot_bool draw_label) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorProperty, set_draw_label, 2586408642, void, self, &draw_label)
}
godot_bool godot_EditorProperty_is_draw_label(const godot_EditorProperty *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorProperty, is_draw_label, 36873697, godot_bool, self)
}
void godot_EditorProperty_set_draw_background(godot_EditorProperty *self, godot_bool draw_background) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorProperty, set_draw_background, 2586408642, void, self, &draw_background)
}
godot_bool godot_EditorProperty_is_draw_background(const godot_EditorProperty *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorProperty, is_draw_background, 36873697, godot_bool, self)
}
void godot_EditorProperty_set_checkable(godot_EditorProperty *self, godot_bool checkable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorProperty, set_checkable, 2586408642, void, self, &checkable)
}
godot_bool godot_EditorProperty_is_checkable(const godot_EditorProperty *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorProperty, is_checkable, 36873697, godot_bool, self)
}
void godot_EditorProperty_set_checked(godot_EditorProperty *self, godot_bool checked) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorProperty, set_checked, 2586408642, void, self, &checked)
}
godot_bool godot_EditorProperty_is_checked(const godot_EditorProperty *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorProperty, is_checked, 36873697, godot_bool, self)
}
void godot_EditorProperty_set_draw_warning(godot_EditorProperty *self, godot_bool draw_warning) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorProperty, set_draw_warning, 2586408642, void, self, &draw_warning)
}
godot_bool godot_EditorProperty_is_draw_warning(const godot_EditorProperty *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorProperty, is_draw_warning, 36873697, godot_bool, self)
}
void godot_EditorProperty_set_keying(godot_EditorProperty *self, godot_bool keying) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorProperty, set_keying, 2586408642, void, self, &keying)
}
godot_bool godot_EditorProperty_is_keying(const godot_EditorProperty *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorProperty, is_keying, 36873697, godot_bool, self)
}
void godot_EditorProperty_set_deletable(godot_EditorProperty *self, godot_bool deletable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorProperty, set_deletable, 2586408642, void, self, &deletable)
}
godot_bool godot_EditorProperty_is_deletable(const godot_EditorProperty *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorProperty, is_deletable, 36873697, godot_bool, self)
}
godot_StringName godot_EditorProperty_get_edited_property(const godot_EditorProperty *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorProperty, get_edited_property, 2002593661, godot_StringName, self)
}
godot_Object * godot_EditorProperty_get_edited_object(godot_EditorProperty *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorProperty, get_edited_object, 2050059866, godot_Object *, self)
}
void godot_EditorProperty_update_property(godot_EditorProperty *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorProperty, update_property, 3218959716, void, self)
}
void godot_EditorProperty_add_focusable(godot_EditorProperty *self, const godot_Control *control) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorProperty, add_focusable, 1496901182, void, self, control)
}
void godot_EditorProperty_set_bottom_editor(godot_EditorProperty *self, const godot_Control *editor) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorProperty, set_bottom_editor, 1496901182, void, self, editor)
}
void godot_EditorProperty_set_selectable(godot_EditorProperty *self, godot_bool selectable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorProperty, set_selectable, 2586408642, void, self, &selectable)
}
godot_bool godot_EditorProperty_is_selectable(const godot_EditorProperty *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorProperty, is_selectable, 36873697, godot_bool, self)
}
void godot_EditorProperty_set_use_folding(godot_EditorProperty *self, godot_bool use_folding) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorProperty, set_use_folding, 2586408642, void, self, &use_folding)
}
godot_bool godot_EditorProperty_is_using_folding(const godot_EditorProperty *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorProperty, is_using_folding, 36873697, godot_bool, self)
}
void godot_EditorProperty_set_name_split_ratio(godot_EditorProperty *self, godot_float ratio) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorProperty, set_name_split_ratio, 373806689, void, self, &ratio)
}
godot_float godot_EditorProperty_get_name_split_ratio(const godot_EditorProperty *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorProperty, get_name_split_ratio, 1740695150, godot_float, self)
}
void godot_EditorProperty_deselect(godot_EditorProperty *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorProperty, deselect, 3218959716, void, self)
}
godot_bool godot_EditorProperty_is_selected(const godot_EditorProperty *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorProperty, is_selected, 36873697, godot_bool, self)
}
void godot_EditorProperty_select(godot_EditorProperty *self, godot_int focusable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorProperty, select, 1025054187, void, self, &focusable)
}
void godot_EditorProperty_set_object_and_property(godot_EditorProperty *self, const godot_Object *object, const godot_StringName *property) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorProperty, set_object_and_property, 4157606280, void, self, object, property)
}
void godot_EditorProperty_set_label_reference(godot_EditorProperty *self, const godot_Control *control) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorProperty, set_label_reference, 1496901182, void, self, control)
}
void godot_EditorProperty_emit_changed(godot_EditorProperty *self, const godot_StringName *property, const godot_Variant *value, const godot_StringName *field, godot_bool changing) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorProperty, emit_changed, 1822500399, void, self, property, value, field, &changing)
}


#ifdef __cplusplus
}
#endif
