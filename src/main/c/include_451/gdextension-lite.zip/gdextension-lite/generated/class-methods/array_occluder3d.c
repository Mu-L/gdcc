// This file was automatically generated
// Do not modify this file
#include "array_occluder3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_ArrayOccluder3D *godot_new_ArrayOccluder3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(ArrayOccluder3D);
}

// Methods
void godot_ArrayOccluder3D_set_arrays(godot_ArrayOccluder3D *self, const godot_PackedVector3Array *vertices, const godot_PackedInt32Array *indices) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ArrayOccluder3D, set_arrays, 3233972621, void, self, vertices, indices)
}
void godot_ArrayOccluder3D_set_vertices(godot_ArrayOccluder3D *self, const godot_PackedVector3Array *vertices) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ArrayOccluder3D, set_vertices, 334873810, void, self, vertices)
}
void godot_ArrayOccluder3D_set_indices(godot_ArrayOccluder3D *self, const godot_PackedInt32Array *indices) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ArrayOccluder3D, set_indices, 3614634198, void, self, indices)
}


#ifdef __cplusplus
}
#endif
