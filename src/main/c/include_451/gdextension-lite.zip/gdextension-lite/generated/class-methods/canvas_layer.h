// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CANVAS_LAYER_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CANVAS_LAYER_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CanvasLayer *godot_new_CanvasLayer();

// Methods
GDEXTENSION_LITE_DECL void godot_CanvasLayer_set_layer(godot_CanvasLayer *self, godot_int layer);
GDEXTENSION_LITE_DECL godot_int godot_CanvasLayer_get_layer(const godot_CanvasLayer *self);
GDEXTENSION_LITE_DECL void godot_CanvasLayer_set_visible(godot_CanvasLayer *self, godot_bool visible);
GDEXTENSION_LITE_DECL godot_bool godot_CanvasLayer_is_visible(const godot_CanvasLayer *self);
GDEXTENSION_LITE_DECL void godot_CanvasLayer_show(godot_CanvasLayer *self);
GDEXTENSION_LITE_DECL void godot_CanvasLayer_hide(godot_CanvasLayer *self);
GDEXTENSION_LITE_DECL void godot_CanvasLayer_set_transform(godot_CanvasLayer *self, const godot_Transform2D *transform);
GDEXTENSION_LITE_DECL godot_Transform2D godot_CanvasLayer_get_transform(const godot_CanvasLayer *self);
GDEXTENSION_LITE_DECL godot_Transform2D godot_CanvasLayer_get_final_transform(const godot_CanvasLayer *self);
GDEXTENSION_LITE_DECL void godot_CanvasLayer_set_offset(godot_CanvasLayer *self, const godot_Vector2 *offset);
GDEXTENSION_LITE_DECL godot_Vector2 godot_CanvasLayer_get_offset(const godot_CanvasLayer *self);
GDEXTENSION_LITE_DECL void godot_CanvasLayer_set_rotation(godot_CanvasLayer *self, godot_float radians);
GDEXTENSION_LITE_DECL godot_float godot_CanvasLayer_get_rotation(const godot_CanvasLayer *self);
GDEXTENSION_LITE_DECL void godot_CanvasLayer_set_scale(godot_CanvasLayer *self, const godot_Vector2 *scale);
GDEXTENSION_LITE_DECL godot_Vector2 godot_CanvasLayer_get_scale(const godot_CanvasLayer *self);
GDEXTENSION_LITE_DECL void godot_CanvasLayer_set_follow_viewport(godot_CanvasLayer *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CanvasLayer_is_following_viewport(const godot_CanvasLayer *self);
GDEXTENSION_LITE_DECL void godot_CanvasLayer_set_follow_viewport_scale(godot_CanvasLayer *self, godot_float scale);
GDEXTENSION_LITE_DECL godot_float godot_CanvasLayer_get_follow_viewport_scale(const godot_CanvasLayer *self);
GDEXTENSION_LITE_DECL void godot_CanvasLayer_set_custom_viewport(godot_CanvasLayer *self, const godot_Node *viewport);
GDEXTENSION_LITE_DECL godot_Node * godot_CanvasLayer_get_custom_viewport(const godot_CanvasLayer *self);
GDEXTENSION_LITE_DECL godot_RID godot_CanvasLayer_get_canvas(const godot_CanvasLayer *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CANVAS_LAYER_H__
