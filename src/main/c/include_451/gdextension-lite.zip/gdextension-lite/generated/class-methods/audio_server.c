// This file was automatically generated
// Do not modify this file
#include "audio_server.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Singleton
godot_AudioServer *godot_AudioServer_singleton() {
	GDEXTENSION_LITE_GET_SINGLETON_IMPL(AudioServer, "AudioServer");
}

// Methods
void godot_AudioServer_set_bus_count(godot_AudioServer *self, godot_int amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioServer, set_bus_count, 1286410249, void, self, &amount)
}
godot_int godot_AudioServer_get_bus_count(const godot_AudioServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, get_bus_count, 3905245786, godot_int, self)
}
void godot_AudioServer_remove_bus(godot_AudioServer *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioServer, remove_bus, 1286410249, void, self, &index)
}
void godot_AudioServer_add_bus(godot_AudioServer *self, godot_int at_position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioServer, add_bus, 1025054187, void, self, &at_position)
}
void godot_AudioServer_move_bus(godot_AudioServer *self, godot_int index, godot_int to_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioServer, move_bus, 3937882851, void, self, &index, &to_index)
}
void godot_AudioServer_set_bus_name(godot_AudioServer *self, godot_int bus_idx, const godot_String *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioServer, set_bus_name, 501894301, void, self, &bus_idx, name)
}
godot_String godot_AudioServer_get_bus_name(const godot_AudioServer *self, godot_int bus_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, get_bus_name, 844755477, godot_String, self, &bus_idx)
}
godot_int godot_AudioServer_get_bus_index(const godot_AudioServer *self, const godot_StringName *bus_name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, get_bus_index, 2458036349, godot_int, self, bus_name)
}
godot_int godot_AudioServer_get_bus_channels(const godot_AudioServer *self, godot_int bus_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, get_bus_channels, 923996154, godot_int, self, &bus_idx)
}
void godot_AudioServer_set_bus_volume_db(godot_AudioServer *self, godot_int bus_idx, godot_float volume_db) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioServer, set_bus_volume_db, 1602489585, void, self, &bus_idx, &volume_db)
}
godot_float godot_AudioServer_get_bus_volume_db(const godot_AudioServer *self, godot_int bus_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, get_bus_volume_db, 2339986948, godot_float, self, &bus_idx)
}
void godot_AudioServer_set_bus_volume_linear(godot_AudioServer *self, godot_int bus_idx, godot_float volume_linear) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioServer, set_bus_volume_linear, 1602489585, void, self, &bus_idx, &volume_linear)
}
godot_float godot_AudioServer_get_bus_volume_linear(const godot_AudioServer *self, godot_int bus_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, get_bus_volume_linear, 2339986948, godot_float, self, &bus_idx)
}
void godot_AudioServer_set_bus_send(godot_AudioServer *self, godot_int bus_idx, const godot_StringName *send) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioServer, set_bus_send, 3780747571, void, self, &bus_idx, send)
}
godot_StringName godot_AudioServer_get_bus_send(const godot_AudioServer *self, godot_int bus_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, get_bus_send, 659327637, godot_StringName, self, &bus_idx)
}
void godot_AudioServer_set_bus_solo(godot_AudioServer *self, godot_int bus_idx, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioServer, set_bus_solo, 300928843, void, self, &bus_idx, &enable)
}
godot_bool godot_AudioServer_is_bus_solo(const godot_AudioServer *self, godot_int bus_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, is_bus_solo, 1116898809, godot_bool, self, &bus_idx)
}
void godot_AudioServer_set_bus_mute(godot_AudioServer *self, godot_int bus_idx, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioServer, set_bus_mute, 300928843, void, self, &bus_idx, &enable)
}
godot_bool godot_AudioServer_is_bus_mute(const godot_AudioServer *self, godot_int bus_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, is_bus_mute, 1116898809, godot_bool, self, &bus_idx)
}
void godot_AudioServer_set_bus_bypass_effects(godot_AudioServer *self, godot_int bus_idx, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioServer, set_bus_bypass_effects, 300928843, void, self, &bus_idx, &enable)
}
godot_bool godot_AudioServer_is_bus_bypassing_effects(const godot_AudioServer *self, godot_int bus_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, is_bus_bypassing_effects, 1116898809, godot_bool, self, &bus_idx)
}
void godot_AudioServer_add_bus_effect(godot_AudioServer *self, godot_int bus_idx, const godot_AudioEffect *effect, godot_int at_position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioServer, add_bus_effect, 4068819785, void, self, &bus_idx, effect, &at_position)
}
void godot_AudioServer_remove_bus_effect(godot_AudioServer *self, godot_int bus_idx, godot_int effect_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioServer, remove_bus_effect, 3937882851, void, self, &bus_idx, &effect_idx)
}
godot_int godot_AudioServer_get_bus_effect_count(godot_AudioServer *self, godot_int bus_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, get_bus_effect_count, 3744713108, godot_int, self, &bus_idx)
}
godot_AudioEffect * godot_AudioServer_get_bus_effect(godot_AudioServer *self, godot_int bus_idx, godot_int effect_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, get_bus_effect, 726064442, godot_AudioEffect *, self, &bus_idx, &effect_idx)
}
godot_AudioEffectInstance * godot_AudioServer_get_bus_effect_instance(godot_AudioServer *self, godot_int bus_idx, godot_int effect_idx, godot_int channel) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, get_bus_effect_instance, 1829771234, godot_AudioEffectInstance *, self, &bus_idx, &effect_idx, &channel)
}
void godot_AudioServer_swap_bus_effects(godot_AudioServer *self, godot_int bus_idx, godot_int effect_idx, godot_int by_effect_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioServer, swap_bus_effects, 1649997291, void, self, &bus_idx, &effect_idx, &by_effect_idx)
}
void godot_AudioServer_set_bus_effect_enabled(godot_AudioServer *self, godot_int bus_idx, godot_int effect_idx, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioServer, set_bus_effect_enabled, 1383440665, void, self, &bus_idx, &effect_idx, &enabled)
}
godot_bool godot_AudioServer_is_bus_effect_enabled(const godot_AudioServer *self, godot_int bus_idx, godot_int effect_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, is_bus_effect_enabled, 2522259332, godot_bool, self, &bus_idx, &effect_idx)
}
godot_float godot_AudioServer_get_bus_peak_volume_left_db(const godot_AudioServer *self, godot_int bus_idx, godot_int channel) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, get_bus_peak_volume_left_db, 3085491603, godot_float, self, &bus_idx, &channel)
}
godot_float godot_AudioServer_get_bus_peak_volume_right_db(const godot_AudioServer *self, godot_int bus_idx, godot_int channel) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, get_bus_peak_volume_right_db, 3085491603, godot_float, self, &bus_idx, &channel)
}
void godot_AudioServer_set_playback_speed_scale(godot_AudioServer *self, godot_float scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioServer, set_playback_speed_scale, 373806689, void, self, &scale)
}
godot_float godot_AudioServer_get_playback_speed_scale(const godot_AudioServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, get_playback_speed_scale, 1740695150, godot_float, self)
}
void godot_AudioServer_lock(godot_AudioServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioServer, lock, 3218959716, void, self)
}
void godot_AudioServer_unlock(godot_AudioServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioServer, unlock, 3218959716, void, self)
}
godot_AudioServer_SpeakerMode godot_AudioServer_get_speaker_mode(const godot_AudioServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, get_speaker_mode, 2549190337, godot_AudioServer_SpeakerMode, self)
}
godot_float godot_AudioServer_get_mix_rate(const godot_AudioServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, get_mix_rate, 1740695150, godot_float, self)
}
godot_float godot_AudioServer_get_input_mix_rate(const godot_AudioServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, get_input_mix_rate, 1740695150, godot_float, self)
}
godot_String godot_AudioServer_get_driver_name(const godot_AudioServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, get_driver_name, 201670096, godot_String, self)
}
godot_PackedStringArray godot_AudioServer_get_output_device_list(godot_AudioServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, get_output_device_list, 2981934095, godot_PackedStringArray, self)
}
godot_String godot_AudioServer_get_output_device(godot_AudioServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, get_output_device, 2841200299, godot_String, self)
}
void godot_AudioServer_set_output_device(godot_AudioServer *self, const godot_String *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioServer, set_output_device, 83702148, void, self, name)
}
godot_float godot_AudioServer_get_time_to_next_mix(const godot_AudioServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, get_time_to_next_mix, 1740695150, godot_float, self)
}
godot_float godot_AudioServer_get_time_since_last_mix(const godot_AudioServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, get_time_since_last_mix, 1740695150, godot_float, self)
}
godot_float godot_AudioServer_get_output_latency(const godot_AudioServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, get_output_latency, 1740695150, godot_float, self)
}
godot_PackedStringArray godot_AudioServer_get_input_device_list(godot_AudioServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, get_input_device_list, 2981934095, godot_PackedStringArray, self)
}
godot_String godot_AudioServer_get_input_device(godot_AudioServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, get_input_device, 2841200299, godot_String, self)
}
void godot_AudioServer_set_input_device(godot_AudioServer *self, const godot_String *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioServer, set_input_device, 83702148, void, self, name)
}
void godot_AudioServer_set_bus_layout(godot_AudioServer *self, const godot_AudioBusLayout *bus_layout) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioServer, set_bus_layout, 3319058824, void, self, bus_layout)
}
godot_AudioBusLayout * godot_AudioServer_generate_bus_layout(const godot_AudioServer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, generate_bus_layout, 3769973890, godot_AudioBusLayout *, self)
}
void godot_AudioServer_set_enable_tagging_used_audio_streams(godot_AudioServer *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioServer, set_enable_tagging_used_audio_streams, 2586408642, void, self, &enable)
}
godot_bool godot_AudioServer_is_stream_registered_as_sample(godot_AudioServer *self, const godot_AudioStream *stream) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioServer, is_stream_registered_as_sample, 500225754, godot_bool, self, stream)
}
void godot_AudioServer_register_stream_as_sample(godot_AudioServer *self, const godot_AudioStream *stream) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioServer, register_stream_as_sample, 2210767741, void, self, stream)
}


#ifdef __cplusplus
}
#endif
