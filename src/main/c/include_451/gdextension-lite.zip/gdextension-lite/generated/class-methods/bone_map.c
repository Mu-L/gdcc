// This file was automatically generated
// Do not modify this file
#include "bone_map.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_BoneMap *godot_new_BoneMap() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(BoneMap);
}

// Methods
godot_SkeletonProfile * godot_BoneMap_get_profile(const godot_BoneMap *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BoneMap, get_profile, 4291782652, godot_SkeletonProfile *, self)
}
void godot_BoneMap_set_profile(godot_BoneMap *self, const godot_SkeletonProfile *profile) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BoneMap, set_profile, 3870374136, void, self, profile)
}
godot_StringName godot_BoneMap_get_skeleton_bone_name(const godot_BoneMap *self, const godot_StringName *profile_bone_name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BoneMap, get_skeleton_bone_name, 1965194235, godot_StringName, self, profile_bone_name)
}
void godot_BoneMap_set_skeleton_bone_name(godot_BoneMap *self, const godot_StringName *profile_bone_name, const godot_StringName *skeleton_bone_name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(BoneMap, set_skeleton_bone_name, 3740211285, void, self, profile_bone_name, skeleton_bone_name)
}
godot_StringName godot_BoneMap_find_profile_bone_name(const godot_BoneMap *self, const godot_StringName *skeleton_bone_name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(BoneMap, find_profile_bone_name, 1965194235, godot_StringName, self, skeleton_bone_name)
}


#ifdef __cplusplus
}
#endif
