// This file was automatically generated
// Do not modify this file
#include "camera_feed.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CameraFeed *godot_new_CameraFeed() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CameraFeed);
}

// Methods
godot_bool godot_CameraFeed__activate_feed(godot_CameraFeed *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraFeed, _activate_feed, 2240911060, godot_bool, self)
}
void godot_CameraFeed__deactivate_feed(godot_CameraFeed *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraFeed, _deactivate_feed, 3218959716, void, self)
}
godot_int godot_CameraFeed_get_id(const godot_CameraFeed *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraFeed, get_id, 3905245786, godot_int, self)
}
godot_bool godot_CameraFeed_is_active(const godot_CameraFeed *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraFeed, is_active, 36873697, godot_bool, self)
}
void godot_CameraFeed_set_active(godot_CameraFeed *self, godot_bool active) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraFeed, set_active, 2586408642, void, self, &active)
}
godot_String godot_CameraFeed_get_name(const godot_CameraFeed *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraFeed, get_name, 201670096, godot_String, self)
}
void godot_CameraFeed_set_name(godot_CameraFeed *self, const godot_String *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraFeed, set_name, 83702148, void, self, name)
}
godot_CameraFeed_FeedPosition godot_CameraFeed_get_position(const godot_CameraFeed *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraFeed, get_position, 2711679033, godot_CameraFeed_FeedPosition, self)
}
void godot_CameraFeed_set_position(godot_CameraFeed *self, godot_CameraFeed_FeedPosition position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraFeed, set_position, 611162623, void, self, &position)
}
godot_Transform2D godot_CameraFeed_get_transform(const godot_CameraFeed *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraFeed, get_transform, 3814499831, godot_Transform2D, self)
}
void godot_CameraFeed_set_transform(godot_CameraFeed *self, const godot_Transform2D *transform) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraFeed, set_transform, 2761652528, void, self, transform)
}
void godot_CameraFeed_set_rgb_image(godot_CameraFeed *self, const godot_Image *rgb_image) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraFeed, set_rgb_image, 532598488, void, self, rgb_image)
}
void godot_CameraFeed_set_ycbcr_image(godot_CameraFeed *self, const godot_Image *ycbcr_image) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraFeed, set_ycbcr_image, 532598488, void, self, ycbcr_image)
}
void godot_CameraFeed_set_external(godot_CameraFeed *self, godot_int width, godot_int height) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraFeed, set_external, 3937882851, void, self, &width, &height)
}
godot_int godot_CameraFeed_get_texture_tex_id(godot_CameraFeed *self, godot_CameraServer_FeedImage feed_image_type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraFeed, get_texture_tex_id, 1135699418, godot_int, self, &feed_image_type)
}
godot_CameraFeed_FeedDataType godot_CameraFeed_get_datatype(const godot_CameraFeed *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraFeed, get_datatype, 1477782850, godot_CameraFeed_FeedDataType, self)
}
godot_Array godot_CameraFeed_get_formats(const godot_CameraFeed *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraFeed, get_formats, 3995934104, godot_Array, self)
}
godot_bool godot_CameraFeed_set_format(godot_CameraFeed *self, godot_int index, const godot_Dictionary *parameters) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraFeed, set_format, 31872775, godot_bool, self, &index, parameters)
}


#ifdef __cplusplus
}
#endif
