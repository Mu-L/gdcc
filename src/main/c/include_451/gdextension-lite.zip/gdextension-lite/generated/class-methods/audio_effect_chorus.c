// This file was automatically generated
// Do not modify this file
#include "audio_effect_chorus.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectChorus *godot_new_AudioEffectChorus() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectChorus);
}

// Methods
void godot_AudioEffectChorus_set_voice_count(godot_AudioEffectChorus *self, godot_int voices) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectChorus, set_voice_count, 1286410249, void, self, &voices)
}
godot_int godot_AudioEffectChorus_get_voice_count(const godot_AudioEffectChorus *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectChorus, get_voice_count, 3905245786, godot_int, self)
}
void godot_AudioEffectChorus_set_voice_delay_ms(godot_AudioEffectChorus *self, godot_int voice_idx, godot_float delay_ms) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectChorus, set_voice_delay_ms, 1602489585, void, self, &voice_idx, &delay_ms)
}
godot_float godot_AudioEffectChorus_get_voice_delay_ms(const godot_AudioEffectChorus *self, godot_int voice_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectChorus, get_voice_delay_ms, 2339986948, godot_float, self, &voice_idx)
}
void godot_AudioEffectChorus_set_voice_rate_hz(godot_AudioEffectChorus *self, godot_int voice_idx, godot_float rate_hz) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectChorus, set_voice_rate_hz, 1602489585, void, self, &voice_idx, &rate_hz)
}
godot_float godot_AudioEffectChorus_get_voice_rate_hz(const godot_AudioEffectChorus *self, godot_int voice_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectChorus, get_voice_rate_hz, 2339986948, godot_float, self, &voice_idx)
}
void godot_AudioEffectChorus_set_voice_depth_ms(godot_AudioEffectChorus *self, godot_int voice_idx, godot_float depth_ms) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectChorus, set_voice_depth_ms, 1602489585, void, self, &voice_idx, &depth_ms)
}
godot_float godot_AudioEffectChorus_get_voice_depth_ms(const godot_AudioEffectChorus *self, godot_int voice_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectChorus, get_voice_depth_ms, 2339986948, godot_float, self, &voice_idx)
}
void godot_AudioEffectChorus_set_voice_level_db(godot_AudioEffectChorus *self, godot_int voice_idx, godot_float level_db) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectChorus, set_voice_level_db, 1602489585, void, self, &voice_idx, &level_db)
}
godot_float godot_AudioEffectChorus_get_voice_level_db(const godot_AudioEffectChorus *self, godot_int voice_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectChorus, get_voice_level_db, 2339986948, godot_float, self, &voice_idx)
}
void godot_AudioEffectChorus_set_voice_cutoff_hz(godot_AudioEffectChorus *self, godot_int voice_idx, godot_float cutoff_hz) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectChorus, set_voice_cutoff_hz, 1602489585, void, self, &voice_idx, &cutoff_hz)
}
godot_float godot_AudioEffectChorus_get_voice_cutoff_hz(const godot_AudioEffectChorus *self, godot_int voice_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectChorus, get_voice_cutoff_hz, 2339986948, godot_float, self, &voice_idx)
}
void godot_AudioEffectChorus_set_voice_pan(godot_AudioEffectChorus *self, godot_int voice_idx, godot_float pan) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectChorus, set_voice_pan, 1602489585, void, self, &voice_idx, &pan)
}
godot_float godot_AudioEffectChorus_get_voice_pan(const godot_AudioEffectChorus *self, godot_int voice_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectChorus, get_voice_pan, 2339986948, godot_float, self, &voice_idx)
}
void godot_AudioEffectChorus_set_wet(godot_AudioEffectChorus *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectChorus, set_wet, 373806689, void, self, &amount)
}
godot_float godot_AudioEffectChorus_get_wet(const godot_AudioEffectChorus *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectChorus, get_wet, 1740695150, godot_float, self)
}
void godot_AudioEffectChorus_set_dry(godot_AudioEffectChorus *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectChorus, set_dry, 373806689, void, self, &amount)
}
godot_float godot_AudioEffectChorus_get_dry(const godot_AudioEffectChorus *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectChorus, get_dry, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
