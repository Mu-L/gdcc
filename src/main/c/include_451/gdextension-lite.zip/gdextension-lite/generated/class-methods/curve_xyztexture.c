// This file was automatically generated
// Do not modify this file
#include "curve_xyztexture.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CurveXYZTexture *godot_new_CurveXYZTexture() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CurveXYZTexture);
}

// Methods
void godot_CurveXYZTexture_set_width(godot_CurveXYZTexture *self, godot_int width) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CurveXYZTexture, set_width, 1286410249, void, self, &width)
}
void godot_CurveXYZTexture_set_curve_x(godot_CurveXYZTexture *self, const godot_Curve *curve) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CurveXYZTexture, set_curve_x, 270443179, void, self, curve)
}
godot_Curve * godot_CurveXYZTexture_get_curve_x(const godot_CurveXYZTexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CurveXYZTexture, get_curve_x, 2460114913, godot_Curve *, self)
}
void godot_CurveXYZTexture_set_curve_y(godot_CurveXYZTexture *self, const godot_Curve *curve) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CurveXYZTexture, set_curve_y, 270443179, void, self, curve)
}
godot_Curve * godot_CurveXYZTexture_get_curve_y(const godot_CurveXYZTexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CurveXYZTexture, get_curve_y, 2460114913, godot_Curve *, self)
}
void godot_CurveXYZTexture_set_curve_z(godot_CurveXYZTexture *self, const godot_Curve *curve) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CurveXYZTexture, set_curve_z, 270443179, void, self, curve)
}
godot_Curve * godot_CurveXYZTexture_get_curve_z(const godot_CurveXYZTexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CurveXYZTexture, get_curve_z, 2460114913, godot_Curve *, self)
}


#ifdef __cplusplus
}
#endif
