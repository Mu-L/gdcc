// This file was automatically generated
// Do not modify this file
#include "canvas_layer.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CanvasLayer *godot_new_CanvasLayer() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CanvasLayer);
}

// Methods
void godot_CanvasLayer_set_layer(godot_CanvasLayer *self, godot_int layer) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasLayer, set_layer, 1286410249, void, self, &layer)
}
godot_int godot_CanvasLayer_get_layer(const godot_CanvasLayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasLayer, get_layer, 3905245786, godot_int, self)
}
void godot_CanvasLayer_set_visible(godot_CanvasLayer *self, godot_bool visible) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasLayer, set_visible, 2586408642, void, self, &visible)
}
godot_bool godot_CanvasLayer_is_visible(const godot_CanvasLayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasLayer, is_visible, 36873697, godot_bool, self)
}
void godot_CanvasLayer_show(godot_CanvasLayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasLayer, show, 3218959716, void, self)
}
void godot_CanvasLayer_hide(godot_CanvasLayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasLayer, hide, 3218959716, void, self)
}
void godot_CanvasLayer_set_transform(godot_CanvasLayer *self, const godot_Transform2D *transform) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasLayer, set_transform, 2761652528, void, self, transform)
}
godot_Transform2D godot_CanvasLayer_get_transform(const godot_CanvasLayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasLayer, get_transform, 3814499831, godot_Transform2D, self)
}
godot_Transform2D godot_CanvasLayer_get_final_transform(const godot_CanvasLayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasLayer, get_final_transform, 3814499831, godot_Transform2D, self)
}
void godot_CanvasLayer_set_offset(godot_CanvasLayer *self, const godot_Vector2 *offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasLayer, set_offset, 743155724, void, self, offset)
}
godot_Vector2 godot_CanvasLayer_get_offset(const godot_CanvasLayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasLayer, get_offset, 3341600327, godot_Vector2, self)
}
void godot_CanvasLayer_set_rotation(godot_CanvasLayer *self, godot_float radians) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasLayer, set_rotation, 373806689, void, self, &radians)
}
godot_float godot_CanvasLayer_get_rotation(const godot_CanvasLayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasLayer, get_rotation, 1740695150, godot_float, self)
}
void godot_CanvasLayer_set_scale(godot_CanvasLayer *self, const godot_Vector2 *scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasLayer, set_scale, 743155724, void, self, scale)
}
godot_Vector2 godot_CanvasLayer_get_scale(const godot_CanvasLayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasLayer, get_scale, 3341600327, godot_Vector2, self)
}
void godot_CanvasLayer_set_follow_viewport(godot_CanvasLayer *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasLayer, set_follow_viewport, 2586408642, void, self, &enable)
}
godot_bool godot_CanvasLayer_is_following_viewport(const godot_CanvasLayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasLayer, is_following_viewport, 36873697, godot_bool, self)
}
void godot_CanvasLayer_set_follow_viewport_scale(godot_CanvasLayer *self, godot_float scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasLayer, set_follow_viewport_scale, 373806689, void, self, &scale)
}
godot_float godot_CanvasLayer_get_follow_viewport_scale(const godot_CanvasLayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasLayer, get_follow_viewport_scale, 1740695150, godot_float, self)
}
void godot_CanvasLayer_set_custom_viewport(godot_CanvasLayer *self, const godot_Node *viewport) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasLayer, set_custom_viewport, 1078189570, void, self, viewport)
}
godot_Node * godot_CanvasLayer_get_custom_viewport(const godot_CanvasLayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasLayer, get_custom_viewport, 3160264692, godot_Node *, self)
}
godot_RID godot_CanvasLayer_get_canvas(const godot_CanvasLayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasLayer, get_canvas, 2944877500, godot_RID, self)
}


#ifdef __cplusplus
}
#endif
