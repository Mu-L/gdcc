// This file was automatically generated
// Do not modify this file
#include "collision_polygon3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CollisionPolygon3D *godot_new_CollisionPolygon3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CollisionPolygon3D);
}

// Methods
void godot_CollisionPolygon3D_set_depth(godot_CollisionPolygon3D *self, godot_float depth) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionPolygon3D, set_depth, 373806689, void, self, &depth)
}
godot_float godot_CollisionPolygon3D_get_depth(const godot_CollisionPolygon3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionPolygon3D, get_depth, 1740695150, godot_float, self)
}
void godot_CollisionPolygon3D_set_polygon(godot_CollisionPolygon3D *self, const godot_PackedVector2Array *polygon) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionPolygon3D, set_polygon, 1509147220, void, self, polygon)
}
godot_PackedVector2Array godot_CollisionPolygon3D_get_polygon(const godot_CollisionPolygon3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionPolygon3D, get_polygon, 2961356807, godot_PackedVector2Array, self)
}
void godot_CollisionPolygon3D_set_disabled(godot_CollisionPolygon3D *self, godot_bool disabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionPolygon3D, set_disabled, 2586408642, void, self, &disabled)
}
godot_bool godot_CollisionPolygon3D_is_disabled(const godot_CollisionPolygon3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionPolygon3D, is_disabled, 36873697, godot_bool, self)
}
void godot_CollisionPolygon3D_set_debug_color(godot_CollisionPolygon3D *self, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionPolygon3D, set_debug_color, 2920490490, void, self, color)
}
godot_Color godot_CollisionPolygon3D_get_debug_color(const godot_CollisionPolygon3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionPolygon3D, get_debug_color, 3444240500, godot_Color, self)
}
void godot_CollisionPolygon3D_set_enable_debug_fill(godot_CollisionPolygon3D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionPolygon3D, set_enable_debug_fill, 2586408642, void, self, &enable)
}
godot_bool godot_CollisionPolygon3D_get_enable_debug_fill(const godot_CollisionPolygon3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionPolygon3D, get_enable_debug_fill, 36873697, godot_bool, self)
}
void godot_CollisionPolygon3D_set_margin(godot_CollisionPolygon3D *self, godot_float margin) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionPolygon3D, set_margin, 373806689, void, self, &margin)
}
godot_float godot_CollisionPolygon3D_get_margin(const godot_CollisionPolygon3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionPolygon3D, get_margin, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
