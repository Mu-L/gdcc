// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_SERVER_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_SERVER_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Singleton
GDEXTENSION_LITE_DECL godot_AudioServer *godot_AudioServer_singleton();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioServer_set_bus_count(godot_AudioServer *self, godot_int amount);
GDEXTENSION_LITE_DECL godot_int godot_AudioServer_get_bus_count(const godot_AudioServer *self);
GDEXTENSION_LITE_DECL void godot_AudioServer_remove_bus(godot_AudioServer *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_AudioServer_add_bus(godot_AudioServer *self, godot_int at_position);
GDEXTENSION_LITE_DECL void godot_AudioServer_move_bus(godot_AudioServer *self, godot_int index, godot_int to_index);
GDEXTENSION_LITE_DECL void godot_AudioServer_set_bus_name(godot_AudioServer *self, godot_int bus_idx, const godot_String *name);
GDEXTENSION_LITE_DECL godot_String godot_AudioServer_get_bus_name(const godot_AudioServer *self, godot_int bus_idx);
GDEXTENSION_LITE_DECL godot_int godot_AudioServer_get_bus_index(const godot_AudioServer *self, const godot_StringName *bus_name);
GDEXTENSION_LITE_DECL godot_int godot_AudioServer_get_bus_channels(const godot_AudioServer *self, godot_int bus_idx);
GDEXTENSION_LITE_DECL void godot_AudioServer_set_bus_volume_db(godot_AudioServer *self, godot_int bus_idx, godot_float volume_db);
GDEXTENSION_LITE_DECL godot_float godot_AudioServer_get_bus_volume_db(const godot_AudioServer *self, godot_int bus_idx);
GDEXTENSION_LITE_DECL void godot_AudioServer_set_bus_volume_linear(godot_AudioServer *self, godot_int bus_idx, godot_float volume_linear);
GDEXTENSION_LITE_DECL godot_float godot_AudioServer_get_bus_volume_linear(const godot_AudioServer *self, godot_int bus_idx);
GDEXTENSION_LITE_DECL void godot_AudioServer_set_bus_send(godot_AudioServer *self, godot_int bus_idx, const godot_StringName *send);
GDEXTENSION_LITE_DECL godot_StringName godot_AudioServer_get_bus_send(const godot_AudioServer *self, godot_int bus_idx);
GDEXTENSION_LITE_DECL void godot_AudioServer_set_bus_solo(godot_AudioServer *self, godot_int bus_idx, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_AudioServer_is_bus_solo(const godot_AudioServer *self, godot_int bus_idx);
GDEXTENSION_LITE_DECL void godot_AudioServer_set_bus_mute(godot_AudioServer *self, godot_int bus_idx, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_AudioServer_is_bus_mute(const godot_AudioServer *self, godot_int bus_idx);
GDEXTENSION_LITE_DECL void godot_AudioServer_set_bus_bypass_effects(godot_AudioServer *self, godot_int bus_idx, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_AudioServer_is_bus_bypassing_effects(const godot_AudioServer *self, godot_int bus_idx);
GDEXTENSION_LITE_DECL void godot_AudioServer_add_bus_effect(godot_AudioServer *self, godot_int bus_idx, const godot_AudioEffect *effect, godot_int at_position);
GDEXTENSION_LITE_DECL void godot_AudioServer_remove_bus_effect(godot_AudioServer *self, godot_int bus_idx, godot_int effect_idx);
GDEXTENSION_LITE_DECL godot_int godot_AudioServer_get_bus_effect_count(godot_AudioServer *self, godot_int bus_idx);
GDEXTENSION_LITE_DECL godot_AudioEffect * godot_AudioServer_get_bus_effect(godot_AudioServer *self, godot_int bus_idx, godot_int effect_idx);
GDEXTENSION_LITE_DECL godot_AudioEffectInstance * godot_AudioServer_get_bus_effect_instance(godot_AudioServer *self, godot_int bus_idx, godot_int effect_idx, godot_int channel);
GDEXTENSION_LITE_DECL void godot_AudioServer_swap_bus_effects(godot_AudioServer *self, godot_int bus_idx, godot_int effect_idx, godot_int by_effect_idx);
GDEXTENSION_LITE_DECL void godot_AudioServer_set_bus_effect_enabled(godot_AudioServer *self, godot_int bus_idx, godot_int effect_idx, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_AudioServer_is_bus_effect_enabled(const godot_AudioServer *self, godot_int bus_idx, godot_int effect_idx);
GDEXTENSION_LITE_DECL godot_float godot_AudioServer_get_bus_peak_volume_left_db(const godot_AudioServer *self, godot_int bus_idx, godot_int channel);
GDEXTENSION_LITE_DECL godot_float godot_AudioServer_get_bus_peak_volume_right_db(const godot_AudioServer *self, godot_int bus_idx, godot_int channel);
GDEXTENSION_LITE_DECL void godot_AudioServer_set_playback_speed_scale(godot_AudioServer *self, godot_float scale);
GDEXTENSION_LITE_DECL godot_float godot_AudioServer_get_playback_speed_scale(const godot_AudioServer *self);
GDEXTENSION_LITE_DECL void godot_AudioServer_lock(godot_AudioServer *self);
GDEXTENSION_LITE_DECL void godot_AudioServer_unlock(godot_AudioServer *self);
GDEXTENSION_LITE_DECL godot_AudioServer_SpeakerMode godot_AudioServer_get_speaker_mode(const godot_AudioServer *self);
GDEXTENSION_LITE_DECL godot_float godot_AudioServer_get_mix_rate(const godot_AudioServer *self);
GDEXTENSION_LITE_DECL godot_float godot_AudioServer_get_input_mix_rate(const godot_AudioServer *self);
GDEXTENSION_LITE_DECL godot_String godot_AudioServer_get_driver_name(const godot_AudioServer *self);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_AudioServer_get_output_device_list(godot_AudioServer *self);
GDEXTENSION_LITE_DECL godot_String godot_AudioServer_get_output_device(godot_AudioServer *self);
GDEXTENSION_LITE_DECL void godot_AudioServer_set_output_device(godot_AudioServer *self, const godot_String *name);
GDEXTENSION_LITE_DECL godot_float godot_AudioServer_get_time_to_next_mix(const godot_AudioServer *self);
GDEXTENSION_LITE_DECL godot_float godot_AudioServer_get_time_since_last_mix(const godot_AudioServer *self);
GDEXTENSION_LITE_DECL godot_float godot_AudioServer_get_output_latency(const godot_AudioServer *self);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_AudioServer_get_input_device_list(godot_AudioServer *self);
GDEXTENSION_LITE_DECL godot_String godot_AudioServer_get_input_device(godot_AudioServer *self);
GDEXTENSION_LITE_DECL void godot_AudioServer_set_input_device(godot_AudioServer *self, const godot_String *name);
GDEXTENSION_LITE_DECL void godot_AudioServer_set_bus_layout(godot_AudioServer *self, const godot_AudioBusLayout *bus_layout);
GDEXTENSION_LITE_DECL godot_AudioBusLayout * godot_AudioServer_generate_bus_layout(const godot_AudioServer *self);
GDEXTENSION_LITE_DECL void godot_AudioServer_set_enable_tagging_used_audio_streams(godot_AudioServer *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_AudioServer_is_stream_registered_as_sample(godot_AudioServer *self, const godot_AudioStream *stream);
GDEXTENSION_LITE_DECL void godot_AudioServer_register_stream_as_sample(godot_AudioServer *self, const godot_AudioStream *stream);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_SERVER_H__
