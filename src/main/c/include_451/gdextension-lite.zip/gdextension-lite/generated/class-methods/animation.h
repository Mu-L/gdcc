// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_Animation *godot_new_Animation();

// Methods
GDEXTENSION_LITE_DECL godot_int godot_Animation_add_track(godot_Animation *self, godot_Animation_TrackType type, godot_int at_position);
GDEXTENSION_LITE_DECL void godot_Animation_remove_track(godot_Animation *self, godot_int track_idx);
GDEXTENSION_LITE_DECL godot_int godot_Animation_get_track_count(const godot_Animation *self);
GDEXTENSION_LITE_DECL godot_Animation_TrackType godot_Animation_track_get_type(const godot_Animation *self, godot_int track_idx);
GDEXTENSION_LITE_DECL godot_NodePath godot_Animation_track_get_path(const godot_Animation *self, godot_int track_idx);
GDEXTENSION_LITE_DECL void godot_Animation_track_set_path(godot_Animation *self, godot_int track_idx, const godot_NodePath *path);
GDEXTENSION_LITE_DECL godot_int godot_Animation_find_track(const godot_Animation *self, const godot_NodePath *path, godot_Animation_TrackType type);
GDEXTENSION_LITE_DECL void godot_Animation_track_move_up(godot_Animation *self, godot_int track_idx);
GDEXTENSION_LITE_DECL void godot_Animation_track_move_down(godot_Animation *self, godot_int track_idx);
GDEXTENSION_LITE_DECL void godot_Animation_track_move_to(godot_Animation *self, godot_int track_idx, godot_int to_idx);
GDEXTENSION_LITE_DECL void godot_Animation_track_swap(godot_Animation *self, godot_int track_idx, godot_int with_idx);
GDEXTENSION_LITE_DECL void godot_Animation_track_set_imported(godot_Animation *self, godot_int track_idx, godot_bool imported);
GDEXTENSION_LITE_DECL godot_bool godot_Animation_track_is_imported(const godot_Animation *self, godot_int track_idx);
GDEXTENSION_LITE_DECL void godot_Animation_track_set_enabled(godot_Animation *self, godot_int track_idx, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_Animation_track_is_enabled(const godot_Animation *self, godot_int track_idx);
GDEXTENSION_LITE_DECL godot_int godot_Animation_position_track_insert_key(godot_Animation *self, godot_int track_idx, godot_float time, const godot_Vector3 *position);
GDEXTENSION_LITE_DECL godot_int godot_Animation_rotation_track_insert_key(godot_Animation *self, godot_int track_idx, godot_float time, const godot_Quaternion *rotation);
GDEXTENSION_LITE_DECL godot_int godot_Animation_scale_track_insert_key(godot_Animation *self, godot_int track_idx, godot_float time, const godot_Vector3 *scale);
GDEXTENSION_LITE_DECL godot_int godot_Animation_blend_shape_track_insert_key(godot_Animation *self, godot_int track_idx, godot_float time, godot_float amount);
GDEXTENSION_LITE_DECL godot_Vector3 godot_Animation_position_track_interpolate(const godot_Animation *self, godot_int track_idx, godot_float time_sec, godot_bool backward);
GDEXTENSION_LITE_DECL godot_Quaternion godot_Animation_rotation_track_interpolate(const godot_Animation *self, godot_int track_idx, godot_float time_sec, godot_bool backward);
GDEXTENSION_LITE_DECL godot_Vector3 godot_Animation_scale_track_interpolate(const godot_Animation *self, godot_int track_idx, godot_float time_sec, godot_bool backward);
GDEXTENSION_LITE_DECL godot_float godot_Animation_blend_shape_track_interpolate(const godot_Animation *self, godot_int track_idx, godot_float time_sec, godot_bool backward);
GDEXTENSION_LITE_DECL godot_int godot_Animation_track_insert_key(godot_Animation *self, godot_int track_idx, godot_float time, const godot_Variant *key, godot_float transition);
GDEXTENSION_LITE_DECL void godot_Animation_track_remove_key(godot_Animation *self, godot_int track_idx, godot_int key_idx);
GDEXTENSION_LITE_DECL void godot_Animation_track_remove_key_at_time(godot_Animation *self, godot_int track_idx, godot_float time);
GDEXTENSION_LITE_DECL void godot_Animation_track_set_key_value(godot_Animation *self, godot_int track_idx, godot_int key, const godot_Variant *value);
GDEXTENSION_LITE_DECL void godot_Animation_track_set_key_transition(godot_Animation *self, godot_int track_idx, godot_int key_idx, godot_float transition);
GDEXTENSION_LITE_DECL void godot_Animation_track_set_key_time(godot_Animation *self, godot_int track_idx, godot_int key_idx, godot_float time);
GDEXTENSION_LITE_DECL godot_float godot_Animation_track_get_key_transition(const godot_Animation *self, godot_int track_idx, godot_int key_idx);
GDEXTENSION_LITE_DECL godot_int godot_Animation_track_get_key_count(const godot_Animation *self, godot_int track_idx);
GDEXTENSION_LITE_DECL godot_Variant godot_Animation_track_get_key_value(const godot_Animation *self, godot_int track_idx, godot_int key_idx);
GDEXTENSION_LITE_DECL godot_float godot_Animation_track_get_key_time(const godot_Animation *self, godot_int track_idx, godot_int key_idx);
GDEXTENSION_LITE_DECL godot_int godot_Animation_track_find_key(const godot_Animation *self, godot_int track_idx, godot_float time, godot_Animation_FindMode find_mode, godot_bool limit, godot_bool backward);
GDEXTENSION_LITE_DECL void godot_Animation_track_set_interpolation_type(godot_Animation *self, godot_int track_idx, godot_Animation_InterpolationType interpolation);
GDEXTENSION_LITE_DECL godot_Animation_InterpolationType godot_Animation_track_get_interpolation_type(const godot_Animation *self, godot_int track_idx);
GDEXTENSION_LITE_DECL void godot_Animation_track_set_interpolation_loop_wrap(godot_Animation *self, godot_int track_idx, godot_bool interpolation);
GDEXTENSION_LITE_DECL godot_bool godot_Animation_track_get_interpolation_loop_wrap(const godot_Animation *self, godot_int track_idx);
GDEXTENSION_LITE_DECL godot_bool godot_Animation_track_is_compressed(const godot_Animation *self, godot_int track_idx);
GDEXTENSION_LITE_DECL void godot_Animation_value_track_set_update_mode(godot_Animation *self, godot_int track_idx, godot_Animation_UpdateMode mode);
GDEXTENSION_LITE_DECL godot_Animation_UpdateMode godot_Animation_value_track_get_update_mode(const godot_Animation *self, godot_int track_idx);
GDEXTENSION_LITE_DECL godot_Variant godot_Animation_value_track_interpolate(const godot_Animation *self, godot_int track_idx, godot_float time_sec, godot_bool backward);
GDEXTENSION_LITE_DECL godot_StringName godot_Animation_method_track_get_name(const godot_Animation *self, godot_int track_idx, godot_int key_idx);
GDEXTENSION_LITE_DECL godot_Array godot_Animation_method_track_get_params(const godot_Animation *self, godot_int track_idx, godot_int key_idx);
GDEXTENSION_LITE_DECL godot_int godot_Animation_bezier_track_insert_key(godot_Animation *self, godot_int track_idx, godot_float time, godot_float value, const godot_Vector2 *in_handle, const godot_Vector2 *out_handle);
GDEXTENSION_LITE_DECL void godot_Animation_bezier_track_set_key_value(godot_Animation *self, godot_int track_idx, godot_int key_idx, godot_float value);
GDEXTENSION_LITE_DECL void godot_Animation_bezier_track_set_key_in_handle(godot_Animation *self, godot_int track_idx, godot_int key_idx, const godot_Vector2 *in_handle, godot_float balanced_value_time_ratio);
GDEXTENSION_LITE_DECL void godot_Animation_bezier_track_set_key_out_handle(godot_Animation *self, godot_int track_idx, godot_int key_idx, const godot_Vector2 *out_handle, godot_float balanced_value_time_ratio);
GDEXTENSION_LITE_DECL godot_float godot_Animation_bezier_track_get_key_value(const godot_Animation *self, godot_int track_idx, godot_int key_idx);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Animation_bezier_track_get_key_in_handle(const godot_Animation *self, godot_int track_idx, godot_int key_idx);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Animation_bezier_track_get_key_out_handle(const godot_Animation *self, godot_int track_idx, godot_int key_idx);
GDEXTENSION_LITE_DECL godot_float godot_Animation_bezier_track_interpolate(const godot_Animation *self, godot_int track_idx, godot_float time);
GDEXTENSION_LITE_DECL godot_int godot_Animation_audio_track_insert_key(godot_Animation *self, godot_int track_idx, godot_float time, const godot_Resource *stream, godot_float start_offset, godot_float end_offset);
GDEXTENSION_LITE_DECL void godot_Animation_audio_track_set_key_stream(godot_Animation *self, godot_int track_idx, godot_int key_idx, const godot_Resource *stream);
GDEXTENSION_LITE_DECL void godot_Animation_audio_track_set_key_start_offset(godot_Animation *self, godot_int track_idx, godot_int key_idx, godot_float offset);
GDEXTENSION_LITE_DECL void godot_Animation_audio_track_set_key_end_offset(godot_Animation *self, godot_int track_idx, godot_int key_idx, godot_float offset);
GDEXTENSION_LITE_DECL godot_Resource * godot_Animation_audio_track_get_key_stream(const godot_Animation *self, godot_int track_idx, godot_int key_idx);
GDEXTENSION_LITE_DECL godot_float godot_Animation_audio_track_get_key_start_offset(const godot_Animation *self, godot_int track_idx, godot_int key_idx);
GDEXTENSION_LITE_DECL godot_float godot_Animation_audio_track_get_key_end_offset(const godot_Animation *self, godot_int track_idx, godot_int key_idx);
GDEXTENSION_LITE_DECL void godot_Animation_audio_track_set_use_blend(godot_Animation *self, godot_int track_idx, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_Animation_audio_track_is_use_blend(const godot_Animation *self, godot_int track_idx);
GDEXTENSION_LITE_DECL godot_int godot_Animation_animation_track_insert_key(godot_Animation *self, godot_int track_idx, godot_float time, const godot_StringName *animation);
GDEXTENSION_LITE_DECL void godot_Animation_animation_track_set_key_animation(godot_Animation *self, godot_int track_idx, godot_int key_idx, const godot_StringName *animation);
GDEXTENSION_LITE_DECL godot_StringName godot_Animation_animation_track_get_key_animation(const godot_Animation *self, godot_int track_idx, godot_int key_idx);
GDEXTENSION_LITE_DECL void godot_Animation_add_marker(godot_Animation *self, const godot_StringName *name, godot_float time);
GDEXTENSION_LITE_DECL void godot_Animation_remove_marker(godot_Animation *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL godot_bool godot_Animation_has_marker(const godot_Animation *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL godot_StringName godot_Animation_get_marker_at_time(const godot_Animation *self, godot_float time);
GDEXTENSION_LITE_DECL godot_StringName godot_Animation_get_next_marker(const godot_Animation *self, godot_float time);
GDEXTENSION_LITE_DECL godot_StringName godot_Animation_get_prev_marker(const godot_Animation *self, godot_float time);
GDEXTENSION_LITE_DECL godot_float godot_Animation_get_marker_time(const godot_Animation *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_Animation_get_marker_names(const godot_Animation *self);
GDEXTENSION_LITE_DECL godot_Color godot_Animation_get_marker_color(const godot_Animation *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL void godot_Animation_set_marker_color(godot_Animation *self, const godot_StringName *name, const godot_Color *color);
GDEXTENSION_LITE_DECL void godot_Animation_set_length(godot_Animation *self, godot_float time_sec);
GDEXTENSION_LITE_DECL godot_float godot_Animation_get_length(const godot_Animation *self);
GDEXTENSION_LITE_DECL void godot_Animation_set_loop_mode(godot_Animation *self, godot_Animation_LoopMode loop_mode);
GDEXTENSION_LITE_DECL godot_Animation_LoopMode godot_Animation_get_loop_mode(const godot_Animation *self);
GDEXTENSION_LITE_DECL void godot_Animation_set_step(godot_Animation *self, godot_float size_sec);
GDEXTENSION_LITE_DECL godot_float godot_Animation_get_step(const godot_Animation *self);
GDEXTENSION_LITE_DECL void godot_Animation_clear(godot_Animation *self);
GDEXTENSION_LITE_DECL void godot_Animation_copy_track(godot_Animation *self, godot_int track_idx, const godot_Animation *to_animation);
GDEXTENSION_LITE_DECL void godot_Animation_optimize(godot_Animation *self, godot_float allowed_velocity_err, godot_float allowed_angular_err, godot_int precision);
GDEXTENSION_LITE_DECL void godot_Animation_compress(godot_Animation *self, godot_int page_size, godot_int fps, godot_float split_tolerance);
GDEXTENSION_LITE_DECL godot_bool godot_Animation_is_capture_included(const godot_Animation *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_H__
