// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLOR_PICKER_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLOR_PICKER_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_ColorPicker *godot_new_ColorPicker();

// Methods
GDEXTENSION_LITE_DECL void godot_ColorPicker_set_pick_color(godot_ColorPicker *self, const godot_Color *color);
GDEXTENSION_LITE_DECL godot_Color godot_ColorPicker_get_pick_color(const godot_ColorPicker *self);
GDEXTENSION_LITE_DECL void godot_ColorPicker_set_deferred_mode(godot_ColorPicker *self, godot_bool mode);
GDEXTENSION_LITE_DECL godot_bool godot_ColorPicker_is_deferred_mode(const godot_ColorPicker *self);
GDEXTENSION_LITE_DECL void godot_ColorPicker_set_color_mode(godot_ColorPicker *self, godot_ColorPicker_ColorModeType color_mode);
GDEXTENSION_LITE_DECL godot_ColorPicker_ColorModeType godot_ColorPicker_get_color_mode(const godot_ColorPicker *self);
GDEXTENSION_LITE_DECL void godot_ColorPicker_set_edit_alpha(godot_ColorPicker *self, godot_bool show);
GDEXTENSION_LITE_DECL godot_bool godot_ColorPicker_is_editing_alpha(const godot_ColorPicker *self);
GDEXTENSION_LITE_DECL void godot_ColorPicker_set_edit_intensity(godot_ColorPicker *self, godot_bool show);
GDEXTENSION_LITE_DECL godot_bool godot_ColorPicker_is_editing_intensity(const godot_ColorPicker *self);
GDEXTENSION_LITE_DECL void godot_ColorPicker_set_can_add_swatches(godot_ColorPicker *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_ColorPicker_are_swatches_enabled(const godot_ColorPicker *self);
GDEXTENSION_LITE_DECL void godot_ColorPicker_set_presets_visible(godot_ColorPicker *self, godot_bool visible);
GDEXTENSION_LITE_DECL godot_bool godot_ColorPicker_are_presets_visible(const godot_ColorPicker *self);
GDEXTENSION_LITE_DECL void godot_ColorPicker_set_modes_visible(godot_ColorPicker *self, godot_bool visible);
GDEXTENSION_LITE_DECL godot_bool godot_ColorPicker_are_modes_visible(const godot_ColorPicker *self);
GDEXTENSION_LITE_DECL void godot_ColorPicker_set_sampler_visible(godot_ColorPicker *self, godot_bool visible);
GDEXTENSION_LITE_DECL godot_bool godot_ColorPicker_is_sampler_visible(const godot_ColorPicker *self);
GDEXTENSION_LITE_DECL void godot_ColorPicker_set_sliders_visible(godot_ColorPicker *self, godot_bool visible);
GDEXTENSION_LITE_DECL godot_bool godot_ColorPicker_are_sliders_visible(const godot_ColorPicker *self);
GDEXTENSION_LITE_DECL void godot_ColorPicker_set_hex_visible(godot_ColorPicker *self, godot_bool visible);
GDEXTENSION_LITE_DECL godot_bool godot_ColorPicker_is_hex_visible(const godot_ColorPicker *self);
GDEXTENSION_LITE_DECL void godot_ColorPicker_add_preset(godot_ColorPicker *self, const godot_Color *color);
GDEXTENSION_LITE_DECL void godot_ColorPicker_erase_preset(godot_ColorPicker *self, const godot_Color *color);
GDEXTENSION_LITE_DECL godot_PackedColorArray godot_ColorPicker_get_presets(const godot_ColorPicker *self);
GDEXTENSION_LITE_DECL void godot_ColorPicker_add_recent_preset(godot_ColorPicker *self, const godot_Color *color);
GDEXTENSION_LITE_DECL void godot_ColorPicker_erase_recent_preset(godot_ColorPicker *self, const godot_Color *color);
GDEXTENSION_LITE_DECL godot_PackedColorArray godot_ColorPicker_get_recent_presets(const godot_ColorPicker *self);
GDEXTENSION_LITE_DECL void godot_ColorPicker_set_picker_shape(godot_ColorPicker *self, godot_ColorPicker_PickerShapeType shape);
GDEXTENSION_LITE_DECL godot_ColorPicker_PickerShapeType godot_ColorPicker_get_picker_shape(const godot_ColorPicker *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLOR_PICKER_H__
