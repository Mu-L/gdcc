// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_STEREO_ENHANCE_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_STEREO_ENHANCE_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioEffectStereoEnhance *godot_new_AudioEffectStereoEnhance();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioEffectStereoEnhance_set_pan_pullout(godot_AudioEffectStereoEnhance *self, godot_float amount);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectStereoEnhance_get_pan_pullout(const godot_AudioEffectStereoEnhance *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectStereoEnhance_set_time_pullout(godot_AudioEffectStereoEnhance *self, godot_float amount);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectStereoEnhance_get_time_pullout(const godot_AudioEffectStereoEnhance *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectStereoEnhance_set_surround(godot_AudioEffectStereoEnhance *self, godot_float amount);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectStereoEnhance_get_surround(const godot_AudioEffectStereoEnhance *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_STEREO_ENHANCE_H__
