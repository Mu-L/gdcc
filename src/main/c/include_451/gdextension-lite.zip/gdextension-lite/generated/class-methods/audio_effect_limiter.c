// This file was automatically generated
// Do not modify this file
#include "audio_effect_limiter.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectLimiter *godot_new_AudioEffectLimiter() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectLimiter);
}

// Methods
void godot_AudioEffectLimiter_set_ceiling_db(godot_AudioEffectLimiter *self, godot_float ceiling) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectLimiter, set_ceiling_db, 373806689, void, self, &ceiling)
}
godot_float godot_AudioEffectLimiter_get_ceiling_db(const godot_AudioEffectLimiter *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectLimiter, get_ceiling_db, 1740695150, godot_float, self)
}
void godot_AudioEffectLimiter_set_threshold_db(godot_AudioEffectLimiter *self, godot_float threshold) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectLimiter, set_threshold_db, 373806689, void, self, &threshold)
}
godot_float godot_AudioEffectLimiter_get_threshold_db(const godot_AudioEffectLimiter *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectLimiter, get_threshold_db, 1740695150, godot_float, self)
}
void godot_AudioEffectLimiter_set_soft_clip_db(godot_AudioEffectLimiter *self, godot_float soft_clip) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectLimiter, set_soft_clip_db, 373806689, void, self, &soft_clip)
}
godot_float godot_AudioEffectLimiter_get_soft_clip_db(const godot_AudioEffectLimiter *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectLimiter, get_soft_clip_db, 1740695150, godot_float, self)
}
void godot_AudioEffectLimiter_set_soft_clip_ratio(godot_AudioEffectLimiter *self, godot_float soft_clip) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectLimiter, set_soft_clip_ratio, 373806689, void, self, &soft_clip)
}
godot_float godot_AudioEffectLimiter_get_soft_clip_ratio(const godot_AudioEffectLimiter *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectLimiter, get_soft_clip_ratio, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
