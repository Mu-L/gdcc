// This file was automatically generated
// Do not modify this file
#include "convert_transform_modifier3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_ConvertTransformModifier3D *godot_new_ConvertTransformModifier3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(ConvertTransformModifier3D);
}

// Methods
void godot_ConvertTransformModifier3D_set_apply_transform_mode(godot_ConvertTransformModifier3D *self, godot_int index, godot_ConvertTransformModifier3D_TransformMode transform_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ConvertTransformModifier3D, set_apply_transform_mode, 1386463405, void, self, &index, &transform_mode)
}
godot_ConvertTransformModifier3D_TransformMode godot_ConvertTransformModifier3D_get_apply_transform_mode(const godot_ConvertTransformModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConvertTransformModifier3D, get_apply_transform_mode, 3234663511, godot_ConvertTransformModifier3D_TransformMode, self, &index)
}
void godot_ConvertTransformModifier3D_set_apply_axis(godot_ConvertTransformModifier3D *self, godot_int index, godot_Vector3_Axis axis) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ConvertTransformModifier3D, set_apply_axis, 776736805, void, self, &index, &axis)
}
godot_Vector3_Axis godot_ConvertTransformModifier3D_get_apply_axis(const godot_ConvertTransformModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConvertTransformModifier3D, get_apply_axis, 4131134770, godot_Vector3_Axis, self, &index)
}
void godot_ConvertTransformModifier3D_set_apply_range_min(godot_ConvertTransformModifier3D *self, godot_int index, godot_float range_min) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ConvertTransformModifier3D, set_apply_range_min, 1602489585, void, self, &index, &range_min)
}
godot_float godot_ConvertTransformModifier3D_get_apply_range_min(const godot_ConvertTransformModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConvertTransformModifier3D, get_apply_range_min, 2339986948, godot_float, self, &index)
}
void godot_ConvertTransformModifier3D_set_apply_range_max(godot_ConvertTransformModifier3D *self, godot_int index, godot_float range_max) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ConvertTransformModifier3D, set_apply_range_max, 1602489585, void, self, &index, &range_max)
}
godot_float godot_ConvertTransformModifier3D_get_apply_range_max(const godot_ConvertTransformModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConvertTransformModifier3D, get_apply_range_max, 2339986948, godot_float, self, &index)
}
void godot_ConvertTransformModifier3D_set_reference_transform_mode(godot_ConvertTransformModifier3D *self, godot_int index, godot_ConvertTransformModifier3D_TransformMode transform_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ConvertTransformModifier3D, set_reference_transform_mode, 1386463405, void, self, &index, &transform_mode)
}
godot_ConvertTransformModifier3D_TransformMode godot_ConvertTransformModifier3D_get_reference_transform_mode(const godot_ConvertTransformModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConvertTransformModifier3D, get_reference_transform_mode, 3234663511, godot_ConvertTransformModifier3D_TransformMode, self, &index)
}
void godot_ConvertTransformModifier3D_set_reference_axis(godot_ConvertTransformModifier3D *self, godot_int index, godot_Vector3_Axis axis) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ConvertTransformModifier3D, set_reference_axis, 776736805, void, self, &index, &axis)
}
godot_Vector3_Axis godot_ConvertTransformModifier3D_get_reference_axis(const godot_ConvertTransformModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConvertTransformModifier3D, get_reference_axis, 4131134770, godot_Vector3_Axis, self, &index)
}
void godot_ConvertTransformModifier3D_set_reference_range_min(godot_ConvertTransformModifier3D *self, godot_int index, godot_float range_min) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ConvertTransformModifier3D, set_reference_range_min, 1602489585, void, self, &index, &range_min)
}
godot_float godot_ConvertTransformModifier3D_get_reference_range_min(const godot_ConvertTransformModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConvertTransformModifier3D, get_reference_range_min, 2339986948, godot_float, self, &index)
}
void godot_ConvertTransformModifier3D_set_reference_range_max(godot_ConvertTransformModifier3D *self, godot_int index, godot_float range_max) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ConvertTransformModifier3D, set_reference_range_max, 1602489585, void, self, &index, &range_max)
}
godot_float godot_ConvertTransformModifier3D_get_reference_range_max(const godot_ConvertTransformModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConvertTransformModifier3D, get_reference_range_max, 2339986948, godot_float, self, &index)
}
void godot_ConvertTransformModifier3D_set_relative(godot_ConvertTransformModifier3D *self, godot_int index, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ConvertTransformModifier3D, set_relative, 300928843, void, self, &index, &enabled)
}
godot_bool godot_ConvertTransformModifier3D_is_relative(const godot_ConvertTransformModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConvertTransformModifier3D, is_relative, 1116898809, godot_bool, self, &index)
}
void godot_ConvertTransformModifier3D_set_additive(godot_ConvertTransformModifier3D *self, godot_int index, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ConvertTransformModifier3D, set_additive, 300928843, void, self, &index, &enabled)
}
godot_bool godot_ConvertTransformModifier3D_is_additive(const godot_ConvertTransformModifier3D *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConvertTransformModifier3D, is_additive, 1116898809, godot_bool, self, &index)
}


#ifdef __cplusplus
}
#endif
