// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BIT_MAP_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BIT_MAP_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_BitMap *godot_new_BitMap();

// Methods
GDEXTENSION_LITE_DECL void godot_BitMap_create(godot_BitMap *self, const godot_Vector2i *size);
GDEXTENSION_LITE_DECL void godot_BitMap_create_from_image_alpha(godot_BitMap *self, const godot_Image *image, godot_float threshold);
GDEXTENSION_LITE_DECL void godot_BitMap_set_bitv(godot_BitMap *self, const godot_Vector2i *position, godot_bool bit);
GDEXTENSION_LITE_DECL void godot_BitMap_set_bit(godot_BitMap *self, godot_int x, godot_int y, godot_bool bit);
GDEXTENSION_LITE_DECL godot_bool godot_BitMap_get_bitv(const godot_BitMap *self, const godot_Vector2i *position);
GDEXTENSION_LITE_DECL godot_bool godot_BitMap_get_bit(const godot_BitMap *self, godot_int x, godot_int y);
GDEXTENSION_LITE_DECL void godot_BitMap_set_bit_rect(godot_BitMap *self, const godot_Rect2i *rect, godot_bool bit);
GDEXTENSION_LITE_DECL godot_int godot_BitMap_get_true_bit_count(const godot_BitMap *self);
GDEXTENSION_LITE_DECL godot_Vector2i godot_BitMap_get_size(const godot_BitMap *self);
GDEXTENSION_LITE_DECL void godot_BitMap_resize(godot_BitMap *self, const godot_Vector2i *new_size);
GDEXTENSION_LITE_DECL void godot_BitMap_grow_mask(godot_BitMap *self, godot_int pixels, const godot_Rect2i *rect);
GDEXTENSION_LITE_DECL godot_Image * godot_BitMap_convert_to_image(const godot_BitMap *self);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_PackedVector2Array) godot_BitMap_opaque_to_polygons(const godot_BitMap *self, const godot_Rect2i *rect, godot_float epsilon);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BIT_MAP_H__
