// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_PHASER_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_PHASER_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioEffectPhaser *godot_new_AudioEffectPhaser();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioEffectPhaser_set_range_min_hz(godot_AudioEffectPhaser *self, godot_float hz);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectPhaser_get_range_min_hz(const godot_AudioEffectPhaser *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectPhaser_set_range_max_hz(godot_AudioEffectPhaser *self, godot_float hz);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectPhaser_get_range_max_hz(const godot_AudioEffectPhaser *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectPhaser_set_rate_hz(godot_AudioEffectPhaser *self, godot_float hz);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectPhaser_get_rate_hz(const godot_AudioEffectPhaser *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectPhaser_set_feedback(godot_AudioEffectPhaser *self, godot_float fbk);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectPhaser_get_feedback(const godot_AudioEffectPhaser *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectPhaser_set_depth(godot_AudioEffectPhaser *self, godot_float depth);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectPhaser_get_depth(const godot_AudioEffectPhaser *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_PHASER_H__
