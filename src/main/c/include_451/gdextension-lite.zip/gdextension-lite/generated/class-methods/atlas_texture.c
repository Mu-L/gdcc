// This file was automatically generated
// Do not modify this file
#include "atlas_texture.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AtlasTexture *godot_new_AtlasTexture() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AtlasTexture);
}

// Methods
void godot_AtlasTexture_set_atlas(godot_AtlasTexture *self, const godot_Texture2D *atlas) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AtlasTexture, set_atlas, 4051416890, void, self, atlas)
}
godot_Texture2D * godot_AtlasTexture_get_atlas(const godot_AtlasTexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AtlasTexture, get_atlas, 3635182373, godot_Texture2D *, self)
}
void godot_AtlasTexture_set_region(godot_AtlasTexture *self, const godot_Rect2 *region) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AtlasTexture, set_region, 2046264180, void, self, region)
}
godot_Rect2 godot_AtlasTexture_get_region(const godot_AtlasTexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AtlasTexture, get_region, 1639390495, godot_Rect2, self)
}
void godot_AtlasTexture_set_margin(godot_AtlasTexture *self, const godot_Rect2 *margin) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AtlasTexture, set_margin, 2046264180, void, self, margin)
}
godot_Rect2 godot_AtlasTexture_get_margin(const godot_AtlasTexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AtlasTexture, get_margin, 1639390495, godot_Rect2, self)
}
void godot_AtlasTexture_set_filter_clip(godot_AtlasTexture *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AtlasTexture, set_filter_clip, 2586408642, void, self, &enable)
}
godot_bool godot_AtlasTexture_has_filter_clip(const godot_AtlasTexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AtlasTexture, has_filter_clip, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
