// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_TRANSITION_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_TRANSITION_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AnimationNodeTransition *godot_new_AnimationNodeTransition();

// Methods
GDEXTENSION_LITE_DECL void godot_AnimationNodeTransition_set_input_count(godot_AnimationNodeTransition *self, godot_int input_count);
GDEXTENSION_LITE_DECL void godot_AnimationNodeTransition_set_input_as_auto_advance(godot_AnimationNodeTransition *self, godot_int input, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNodeTransition_is_input_set_as_auto_advance(const godot_AnimationNodeTransition *self, godot_int input);
GDEXTENSION_LITE_DECL void godot_AnimationNodeTransition_set_input_break_loop_at_end(godot_AnimationNodeTransition *self, godot_int input, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNodeTransition_is_input_loop_broken_at_end(const godot_AnimationNodeTransition *self, godot_int input);
GDEXTENSION_LITE_DECL void godot_AnimationNodeTransition_set_input_reset(godot_AnimationNodeTransition *self, godot_int input, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNodeTransition_is_input_reset(const godot_AnimationNodeTransition *self, godot_int input);
GDEXTENSION_LITE_DECL void godot_AnimationNodeTransition_set_xfade_time(godot_AnimationNodeTransition *self, godot_float time);
GDEXTENSION_LITE_DECL godot_float godot_AnimationNodeTransition_get_xfade_time(const godot_AnimationNodeTransition *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeTransition_set_xfade_curve(godot_AnimationNodeTransition *self, const godot_Curve *curve);
GDEXTENSION_LITE_DECL godot_Curve * godot_AnimationNodeTransition_get_xfade_curve(const godot_AnimationNodeTransition *self);
GDEXTENSION_LITE_DECL void godot_AnimationNodeTransition_set_allow_transition_to_self(godot_AnimationNodeTransition *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNodeTransition_is_allow_transition_to_self(const godot_AnimationNodeTransition *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_TRANSITION_H__
