// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_DEBUGGER_PLUGIN_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_DEBUGGER_PLUGIN_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorDebuggerPlugin *godot_new_EditorDebuggerPlugin();

// Methods
GDEXTENSION_LITE_DECL void godot_EditorDebuggerPlugin__setup_session(godot_EditorDebuggerPlugin *self, godot_int session_id);
GDEXTENSION_LITE_DECL godot_bool godot_EditorDebuggerPlugin__has_capture(const godot_EditorDebuggerPlugin *self, const godot_String *capture);
GDEXTENSION_LITE_DECL godot_bool godot_EditorDebuggerPlugin__capture(godot_EditorDebuggerPlugin *self, const godot_String *message, const godot_Array *data, godot_int session_id);
GDEXTENSION_LITE_DECL void godot_EditorDebuggerPlugin__goto_script_line(godot_EditorDebuggerPlugin *self, const godot_Script *script, godot_int line);
GDEXTENSION_LITE_DECL void godot_EditorDebuggerPlugin__breakpoints_cleared_in_tree(godot_EditorDebuggerPlugin *self);
GDEXTENSION_LITE_DECL void godot_EditorDebuggerPlugin__breakpoint_set_in_tree(godot_EditorDebuggerPlugin *self, const godot_Script *script, godot_int line, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_EditorDebuggerSession * godot_EditorDebuggerPlugin_get_session(godot_EditorDebuggerPlugin *self, godot_int id);
GDEXTENSION_LITE_DECL godot_Array godot_EditorDebuggerPlugin_get_sessions(godot_EditorDebuggerPlugin *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_DEBUGGER_PLUGIN_H__
