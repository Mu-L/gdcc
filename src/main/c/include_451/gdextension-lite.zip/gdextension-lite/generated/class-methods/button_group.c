// This file was automatically generated
// Do not modify this file
#include "button_group.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_ButtonGroup *godot_new_ButtonGroup() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(ButtonGroup);
}

// Methods
godot_BaseButton * godot_ButtonGroup_get_pressed_button(godot_ButtonGroup *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ButtonGroup, get_pressed_button, 3886434893, godot_BaseButton *, self)
}
godot_TypedArray(godot_BaseButton) godot_ButtonGroup_get_buttons(godot_ButtonGroup *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ButtonGroup, get_buttons, 2915620761, godot_TypedArray(godot_BaseButton), self)
}
void godot_ButtonGroup_set_allow_unpress(godot_ButtonGroup *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ButtonGroup, set_allow_unpress, 2586408642, void, self, &enabled)
}
godot_bool godot_ButtonGroup_is_allow_unpress(godot_ButtonGroup *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ButtonGroup, is_allow_unpress, 2240911060, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
