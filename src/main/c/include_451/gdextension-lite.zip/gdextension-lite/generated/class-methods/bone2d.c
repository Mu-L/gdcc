// This file was automatically generated
// Do not modify this file
#include "bone2d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_Bone2D *godot_new_Bone2D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(Bone2D);
}

// Methods
void godot_Bone2D_set_rest(godot_Bone2D *self, const godot_Transform2D *rest) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Bone2D, set_rest, 2761652528, void, self, rest)
}
godot_Transform2D godot_Bone2D_get_rest(const godot_Bone2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Bone2D, get_rest, 3814499831, godot_Transform2D, self)
}
void godot_Bone2D_apply_rest(godot_Bone2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Bone2D, apply_rest, 3218959716, void, self)
}
godot_Transform2D godot_Bone2D_get_skeleton_rest(const godot_Bone2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Bone2D, get_skeleton_rest, 3814499831, godot_Transform2D, self)
}
godot_int godot_Bone2D_get_index_in_skeleton(const godot_Bone2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Bone2D, get_index_in_skeleton, 3905245786, godot_int, self)
}
void godot_Bone2D_set_autocalculate_length_and_angle(godot_Bone2D *self, godot_bool auto_calculate) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Bone2D, set_autocalculate_length_and_angle, 2586408642, void, self, &auto_calculate)
}
godot_bool godot_Bone2D_get_autocalculate_length_and_angle(const godot_Bone2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Bone2D, get_autocalculate_length_and_angle, 36873697, godot_bool, self)
}
void godot_Bone2D_set_length(godot_Bone2D *self, godot_float length) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Bone2D, set_length, 373806689, void, self, &length)
}
godot_float godot_Bone2D_get_length(const godot_Bone2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Bone2D, get_length, 1740695150, godot_float, self)
}
void godot_Bone2D_set_bone_angle(godot_Bone2D *self, godot_float angle) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Bone2D, set_bone_angle, 373806689, void, self, &angle)
}
godot_float godot_Bone2D_get_bone_angle(const godot_Bone2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Bone2D, get_bone_angle, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
