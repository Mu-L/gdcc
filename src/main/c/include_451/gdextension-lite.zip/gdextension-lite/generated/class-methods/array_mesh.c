// This file was automatically generated
// Do not modify this file
#include "array_mesh.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_ArrayMesh *godot_new_ArrayMesh() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(ArrayMesh);
}

// Methods
void godot_ArrayMesh_add_blend_shape(godot_ArrayMesh *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ArrayMesh, add_blend_shape, 3304788590, void, self, name)
}
godot_int godot_ArrayMesh_get_blend_shape_count(const godot_ArrayMesh *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ArrayMesh, get_blend_shape_count, 3905245786, godot_int, self)
}
godot_StringName godot_ArrayMesh_get_blend_shape_name(const godot_ArrayMesh *self, godot_int index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ArrayMesh, get_blend_shape_name, 659327637, godot_StringName, self, &index)
}
void godot_ArrayMesh_set_blend_shape_name(godot_ArrayMesh *self, godot_int index, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ArrayMesh, set_blend_shape_name, 3780747571, void, self, &index, name)
}
void godot_ArrayMesh_clear_blend_shapes(godot_ArrayMesh *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ArrayMesh, clear_blend_shapes, 3218959716, void, self)
}
void godot_ArrayMesh_set_blend_shape_mode(godot_ArrayMesh *self, godot_Mesh_BlendShapeMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ArrayMesh, set_blend_shape_mode, 227983991, void, self, &mode)
}
godot_Mesh_BlendShapeMode godot_ArrayMesh_get_blend_shape_mode(const godot_ArrayMesh *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ArrayMesh, get_blend_shape_mode, 836485024, godot_Mesh_BlendShapeMode, self)
}
void godot_ArrayMesh_add_surface_from_arrays(godot_ArrayMesh *self, godot_Mesh_PrimitiveType primitive, const godot_Array *arrays, const godot_TypedArray(godot_Array) *blend_shapes, const godot_Dictionary *lods, const godot_Mesh_ArrayFormat *flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ArrayMesh, add_surface_from_arrays, 1796411378, void, self, &primitive, arrays, blend_shapes, lods, flags)
}
void godot_ArrayMesh_clear_surfaces(godot_ArrayMesh *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ArrayMesh, clear_surfaces, 3218959716, void, self)
}
void godot_ArrayMesh_surface_remove(godot_ArrayMesh *self, godot_int surf_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ArrayMesh, surface_remove, 1286410249, void, self, &surf_idx)
}
void godot_ArrayMesh_surface_update_vertex_region(godot_ArrayMesh *self, godot_int surf_idx, godot_int offset, const godot_PackedByteArray *data) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ArrayMesh, surface_update_vertex_region, 3837166854, void, self, &surf_idx, &offset, data)
}
void godot_ArrayMesh_surface_update_attribute_region(godot_ArrayMesh *self, godot_int surf_idx, godot_int offset, const godot_PackedByteArray *data) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ArrayMesh, surface_update_attribute_region, 3837166854, void, self, &surf_idx, &offset, data)
}
void godot_ArrayMesh_surface_update_skin_region(godot_ArrayMesh *self, godot_int surf_idx, godot_int offset, const godot_PackedByteArray *data) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ArrayMesh, surface_update_skin_region, 3837166854, void, self, &surf_idx, &offset, data)
}
godot_int godot_ArrayMesh_surface_get_array_len(const godot_ArrayMesh *self, godot_int surf_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ArrayMesh, surface_get_array_len, 923996154, godot_int, self, &surf_idx)
}
godot_int godot_ArrayMesh_surface_get_array_index_len(const godot_ArrayMesh *self, godot_int surf_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ArrayMesh, surface_get_array_index_len, 923996154, godot_int, self, &surf_idx)
}
godot_Mesh_ArrayFormat godot_ArrayMesh_surface_get_format(const godot_ArrayMesh *self, godot_int surf_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ArrayMesh, surface_get_format, 3718287884, godot_Mesh_ArrayFormat, self, &surf_idx)
}
godot_Mesh_PrimitiveType godot_ArrayMesh_surface_get_primitive_type(const godot_ArrayMesh *self, godot_int surf_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ArrayMesh, surface_get_primitive_type, 4141943888, godot_Mesh_PrimitiveType, self, &surf_idx)
}
godot_int godot_ArrayMesh_surface_find_by_name(const godot_ArrayMesh *self, const godot_String *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ArrayMesh, surface_find_by_name, 1321353865, godot_int, self, name)
}
void godot_ArrayMesh_surface_set_name(godot_ArrayMesh *self, godot_int surf_idx, const godot_String *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ArrayMesh, surface_set_name, 501894301, void, self, &surf_idx, name)
}
godot_String godot_ArrayMesh_surface_get_name(const godot_ArrayMesh *self, godot_int surf_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ArrayMesh, surface_get_name, 844755477, godot_String, self, &surf_idx)
}
void godot_ArrayMesh_regen_normal_maps(godot_ArrayMesh *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ArrayMesh, regen_normal_maps, 3218959716, void, self)
}
godot_Error godot_ArrayMesh_lightmap_unwrap(godot_ArrayMesh *self, const godot_Transform3D *transform, godot_float texel_size) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ArrayMesh, lightmap_unwrap, 1476641071, godot_Error, self, transform, &texel_size)
}
void godot_ArrayMesh_set_custom_aabb(godot_ArrayMesh *self, const godot_AABB *aabb) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ArrayMesh, set_custom_aabb, 259215842, void, self, aabb)
}
godot_AABB godot_ArrayMesh_get_custom_aabb(const godot_ArrayMesh *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ArrayMesh, get_custom_aabb, 1068685055, godot_AABB, self)
}
void godot_ArrayMesh_set_shadow_mesh(godot_ArrayMesh *self, const godot_ArrayMesh *mesh) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ArrayMesh, set_shadow_mesh, 3377897901, void, self, mesh)
}
godot_ArrayMesh * godot_ArrayMesh_get_shadow_mesh(const godot_ArrayMesh *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ArrayMesh, get_shadow_mesh, 3206942465, godot_ArrayMesh *, self)
}


#ifdef __cplusplus
}
#endif
