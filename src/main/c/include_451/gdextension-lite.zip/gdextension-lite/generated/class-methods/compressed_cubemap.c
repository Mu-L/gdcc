// This file was automatically generated
// Do not modify this file
#include "compressed_cubemap.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CompressedCubemap *godot_new_CompressedCubemap() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CompressedCubemap);
}


#ifdef __cplusplus
}
#endif
