// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_LIBRARY_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_LIBRARY_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AnimationLibrary *godot_new_AnimationLibrary();

// Methods
GDEXTENSION_LITE_DECL godot_Error godot_AnimationLibrary_add_animation(godot_AnimationLibrary *self, const godot_StringName *name, const godot_Animation *animation);
GDEXTENSION_LITE_DECL void godot_AnimationLibrary_remove_animation(godot_AnimationLibrary *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL void godot_AnimationLibrary_rename_animation(godot_AnimationLibrary *self, const godot_StringName *name, const godot_StringName *newname);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationLibrary_has_animation(const godot_AnimationLibrary *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL godot_Animation * godot_AnimationLibrary_get_animation(const godot_AnimationLibrary *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_StringName) godot_AnimationLibrary_get_animation_list(const godot_AnimationLibrary *self);
GDEXTENSION_LITE_DECL godot_int godot_AnimationLibrary_get_animation_list_size(const godot_AnimationLibrary *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_LIBRARY_H__
