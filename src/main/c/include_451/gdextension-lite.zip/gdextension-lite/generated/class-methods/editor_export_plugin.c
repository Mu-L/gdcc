// This file was automatically generated
// Do not modify this file
#include "editor_export_plugin.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorExportPlugin *godot_new_EditorExportPlugin() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorExportPlugin);
}

// Methods
void godot_EditorExportPlugin__export_file(godot_EditorExportPlugin *self, const godot_String *path, const godot_String *type, const godot_PackedStringArray *features) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlugin, _export_file, 3533781844, void, self, path, type, features)
}
void godot_EditorExportPlugin__export_begin(godot_EditorExportPlugin *self, const godot_PackedStringArray *features, godot_bool is_debug, const godot_String *path, godot_int flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlugin, _export_begin, 2765511433, void, self, features, &is_debug, path, &flags)
}
void godot_EditorExportPlugin__export_end(godot_EditorExportPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlugin, _export_end, 3218959716, void, self)
}
godot_bool godot_EditorExportPlugin__begin_customize_resources(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform, const godot_PackedStringArray *features) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlugin, _begin_customize_resources, 1312023292, godot_bool, self, platform, features)
}
godot_Resource * godot_EditorExportPlugin__customize_resource(godot_EditorExportPlugin *self, const godot_Resource *resource, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlugin, _customize_resource, 307917495, godot_Resource *, self, resource, path)
}
godot_bool godot_EditorExportPlugin__begin_customize_scenes(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform, const godot_PackedStringArray *features) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlugin, _begin_customize_scenes, 1312023292, godot_bool, self, platform, features)
}
godot_Node * godot_EditorExportPlugin__customize_scene(godot_EditorExportPlugin *self, const godot_Node *scene, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlugin, _customize_scene, 498701822, godot_Node *, self, scene, path)
}
godot_int godot_EditorExportPlugin__get_customization_configuration_hash(const godot_EditorExportPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlugin, _get_customization_configuration_hash, 3905245786, godot_int, self)
}
void godot_EditorExportPlugin__end_customize_scenes(godot_EditorExportPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlugin, _end_customize_scenes, 3218959716, void, self)
}
void godot_EditorExportPlugin__end_customize_resources(godot_EditorExportPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlugin, _end_customize_resources, 3218959716, void, self)
}
godot_TypedArray(godot_Dictionary) godot_EditorExportPlugin__get_export_options(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlugin, _get_export_options, 488349689, godot_TypedArray(godot_Dictionary), self, platform)
}
godot_Dictionary godot_EditorExportPlugin__get_export_options_overrides(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlugin, _get_export_options_overrides, 2837326714, godot_Dictionary, self, platform)
}
godot_bool godot_EditorExportPlugin__should_update_export_options(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlugin, _should_update_export_options, 1866233299, godot_bool, self, platform)
}
godot_bool godot_EditorExportPlugin__get_export_option_visibility(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform, const godot_String *option) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlugin, _get_export_option_visibility, 3537301980, godot_bool, self, platform, option)
}
godot_String godot_EditorExportPlugin__get_export_option_warning(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform, const godot_String *option) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlugin, _get_export_option_warning, 3340251247, godot_String, self, platform, option)
}
godot_PackedStringArray godot_EditorExportPlugin__get_export_features(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform, godot_bool debug) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlugin, _get_export_features, 1057664154, godot_PackedStringArray, self, platform, &debug)
}
godot_String godot_EditorExportPlugin__get_name(const godot_EditorExportPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlugin, _get_name, 201670096, godot_String, self)
}
godot_bool godot_EditorExportPlugin__supports_platform(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlugin, _supports_platform, 1866233299, godot_bool, self, platform)
}
godot_PackedStringArray godot_EditorExportPlugin__get_android_dependencies(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform, godot_bool debug) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlugin, _get_android_dependencies, 1057664154, godot_PackedStringArray, self, platform, &debug)
}
godot_PackedStringArray godot_EditorExportPlugin__get_android_dependencies_maven_repos(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform, godot_bool debug) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlugin, _get_android_dependencies_maven_repos, 1057664154, godot_PackedStringArray, self, platform, &debug)
}
godot_PackedStringArray godot_EditorExportPlugin__get_android_libraries(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform, godot_bool debug) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlugin, _get_android_libraries, 1057664154, godot_PackedStringArray, self, platform, &debug)
}
godot_String godot_EditorExportPlugin__get_android_manifest_activity_element_contents(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform, godot_bool debug) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlugin, _get_android_manifest_activity_element_contents, 4013372917, godot_String, self, platform, &debug)
}
godot_String godot_EditorExportPlugin__get_android_manifest_application_element_contents(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform, godot_bool debug) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlugin, _get_android_manifest_application_element_contents, 4013372917, godot_String, self, platform, &debug)
}
godot_String godot_EditorExportPlugin__get_android_manifest_element_contents(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform, godot_bool debug) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlugin, _get_android_manifest_element_contents, 4013372917, godot_String, self, platform, &debug)
}
godot_PackedByteArray godot_EditorExportPlugin__update_android_prebuilt_manifest(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform, const godot_PackedByteArray *manifest_data) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlugin, _update_android_prebuilt_manifest, 3304965187, godot_PackedByteArray, self, platform, manifest_data)
}
void godot_EditorExportPlugin_add_shared_object(godot_EditorExportPlugin *self, const godot_String *path, const godot_PackedStringArray *tags, const godot_String *target) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlugin, add_shared_object, 3098291045, void, self, path, tags, target)
}
void godot_EditorExportPlugin_add_file(godot_EditorExportPlugin *self, const godot_String *path, const godot_PackedByteArray *file, godot_bool remap) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlugin, add_file, 527928637, void, self, path, file, &remap)
}
void godot_EditorExportPlugin_add_apple_embedded_platform_project_static_lib(godot_EditorExportPlugin *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlugin, add_apple_embedded_platform_project_static_lib, 83702148, void, self, path)
}
void godot_EditorExportPlugin_add_apple_embedded_platform_framework(godot_EditorExportPlugin *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlugin, add_apple_embedded_platform_framework, 83702148, void, self, path)
}
void godot_EditorExportPlugin_add_apple_embedded_platform_embedded_framework(godot_EditorExportPlugin *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlugin, add_apple_embedded_platform_embedded_framework, 83702148, void, self, path)
}
void godot_EditorExportPlugin_add_apple_embedded_platform_plist_content(godot_EditorExportPlugin *self, const godot_String *plist_content) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlugin, add_apple_embedded_platform_plist_content, 83702148, void, self, plist_content)
}
void godot_EditorExportPlugin_add_apple_embedded_platform_linker_flags(godot_EditorExportPlugin *self, const godot_String *flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlugin, add_apple_embedded_platform_linker_flags, 83702148, void, self, flags)
}
void godot_EditorExportPlugin_add_apple_embedded_platform_bundle_file(godot_EditorExportPlugin *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlugin, add_apple_embedded_platform_bundle_file, 83702148, void, self, path)
}
void godot_EditorExportPlugin_add_apple_embedded_platform_cpp_code(godot_EditorExportPlugin *self, const godot_String *code) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlugin, add_apple_embedded_platform_cpp_code, 83702148, void, self, code)
}
void godot_EditorExportPlugin_add_ios_project_static_lib(godot_EditorExportPlugin *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlugin, add_ios_project_static_lib, 83702148, void, self, path)
}
void godot_EditorExportPlugin_add_ios_framework(godot_EditorExportPlugin *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlugin, add_ios_framework, 83702148, void, self, path)
}
void godot_EditorExportPlugin_add_ios_embedded_framework(godot_EditorExportPlugin *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlugin, add_ios_embedded_framework, 83702148, void, self, path)
}
void godot_EditorExportPlugin_add_ios_plist_content(godot_EditorExportPlugin *self, const godot_String *plist_content) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlugin, add_ios_plist_content, 83702148, void, self, plist_content)
}
void godot_EditorExportPlugin_add_ios_linker_flags(godot_EditorExportPlugin *self, const godot_String *flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlugin, add_ios_linker_flags, 83702148, void, self, flags)
}
void godot_EditorExportPlugin_add_ios_bundle_file(godot_EditorExportPlugin *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlugin, add_ios_bundle_file, 83702148, void, self, path)
}
void godot_EditorExportPlugin_add_ios_cpp_code(godot_EditorExportPlugin *self, const godot_String *code) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlugin, add_ios_cpp_code, 83702148, void, self, code)
}
void godot_EditorExportPlugin_add_macos_plugin_file(godot_EditorExportPlugin *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlugin, add_macos_plugin_file, 83702148, void, self, path)
}
void godot_EditorExportPlugin_skip(godot_EditorExportPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorExportPlugin, skip, 3218959716, void, self)
}
godot_Variant godot_EditorExportPlugin_get_option(const godot_EditorExportPlugin *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlugin, get_option, 2760726917, godot_Variant, self, name)
}
godot_EditorExportPreset * godot_EditorExportPlugin_get_export_preset(const godot_EditorExportPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlugin, get_export_preset, 1610607222, godot_EditorExportPreset *, self)
}
godot_EditorExportPlatform * godot_EditorExportPlugin_get_export_platform(const godot_EditorExportPlugin *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorExportPlugin, get_export_platform, 282254641, godot_EditorExportPlatform *, self)
}


#ifdef __cplusplus
}
#endif
