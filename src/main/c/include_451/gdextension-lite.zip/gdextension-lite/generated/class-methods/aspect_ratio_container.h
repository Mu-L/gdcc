// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ASPECT_RATIO_CONTAINER_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ASPECT_RATIO_CONTAINER_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AspectRatioContainer *godot_new_AspectRatioContainer();

// Methods
GDEXTENSION_LITE_DECL void godot_AspectRatioContainer_set_ratio(godot_AspectRatioContainer *self, godot_float ratio);
GDEXTENSION_LITE_DECL godot_float godot_AspectRatioContainer_get_ratio(const godot_AspectRatioContainer *self);
GDEXTENSION_LITE_DECL void godot_AspectRatioContainer_set_stretch_mode(godot_AspectRatioContainer *self, godot_AspectRatioContainer_StretchMode stretch_mode);
GDEXTENSION_LITE_DECL godot_AspectRatioContainer_StretchMode godot_AspectRatioContainer_get_stretch_mode(const godot_AspectRatioContainer *self);
GDEXTENSION_LITE_DECL void godot_AspectRatioContainer_set_alignment_horizontal(godot_AspectRatioContainer *self, godot_AspectRatioContainer_AlignmentMode alignment_horizontal);
GDEXTENSION_LITE_DECL godot_AspectRatioContainer_AlignmentMode godot_AspectRatioContainer_get_alignment_horizontal(const godot_AspectRatioContainer *self);
GDEXTENSION_LITE_DECL void godot_AspectRatioContainer_set_alignment_vertical(godot_AspectRatioContainer *self, godot_AspectRatioContainer_AlignmentMode alignment_vertical);
GDEXTENSION_LITE_DECL godot_AspectRatioContainer_AlignmentMode godot_AspectRatioContainer_get_alignment_vertical(const godot_AspectRatioContainer *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ASPECT_RATIO_CONTAINER_H__
