// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLLISION_POLYGON3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLLISION_POLYGON3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CollisionPolygon3D *godot_new_CollisionPolygon3D();

// Methods
GDEXTENSION_LITE_DECL void godot_CollisionPolygon3D_set_depth(godot_CollisionPolygon3D *self, godot_float depth);
GDEXTENSION_LITE_DECL godot_float godot_CollisionPolygon3D_get_depth(const godot_CollisionPolygon3D *self);
GDEXTENSION_LITE_DECL void godot_CollisionPolygon3D_set_polygon(godot_CollisionPolygon3D *self, const godot_PackedVector2Array *polygon);
GDEXTENSION_LITE_DECL godot_PackedVector2Array godot_CollisionPolygon3D_get_polygon(const godot_CollisionPolygon3D *self);
GDEXTENSION_LITE_DECL void godot_CollisionPolygon3D_set_disabled(godot_CollisionPolygon3D *self, godot_bool disabled);
GDEXTENSION_LITE_DECL godot_bool godot_CollisionPolygon3D_is_disabled(const godot_CollisionPolygon3D *self);
GDEXTENSION_LITE_DECL void godot_CollisionPolygon3D_set_debug_color(godot_CollisionPolygon3D *self, const godot_Color *color);
GDEXTENSION_LITE_DECL godot_Color godot_CollisionPolygon3D_get_debug_color(const godot_CollisionPolygon3D *self);
GDEXTENSION_LITE_DECL void godot_CollisionPolygon3D_set_enable_debug_fill(godot_CollisionPolygon3D *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CollisionPolygon3D_get_enable_debug_fill(const godot_CollisionPolygon3D *self);
GDEXTENSION_LITE_DECL void godot_CollisionPolygon3D_set_margin(godot_CollisionPolygon3D *self, godot_float margin);
GDEXTENSION_LITE_DECL godot_float godot_CollisionPolygon3D_get_margin(const godot_CollisionPolygon3D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLLISION_POLYGON3D_H__
