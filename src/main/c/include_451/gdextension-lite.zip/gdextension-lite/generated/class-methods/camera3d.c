// This file was automatically generated
// Do not modify this file
#include "camera3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_Camera3D *godot_new_Camera3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(Camera3D);
}

// Methods
godot_Vector3 godot_Camera3D_project_ray_normal(const godot_Camera3D *self, const godot_Vector2 *screen_point) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, project_ray_normal, 1718073306, godot_Vector3, self, screen_point)
}
godot_Vector3 godot_Camera3D_project_local_ray_normal(const godot_Camera3D *self, const godot_Vector2 *screen_point) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, project_local_ray_normal, 1718073306, godot_Vector3, self, screen_point)
}
godot_Vector3 godot_Camera3D_project_ray_origin(const godot_Camera3D *self, const godot_Vector2 *screen_point) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, project_ray_origin, 1718073306, godot_Vector3, self, screen_point)
}
godot_Vector2 godot_Camera3D_unproject_position(const godot_Camera3D *self, const godot_Vector3 *world_point) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, unproject_position, 3758901831, godot_Vector2, self, world_point)
}
godot_bool godot_Camera3D_is_position_behind(const godot_Camera3D *self, const godot_Vector3 *world_point) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, is_position_behind, 3108956480, godot_bool, self, world_point)
}
godot_Vector3 godot_Camera3D_project_position(const godot_Camera3D *self, const godot_Vector2 *screen_point, godot_float z_depth) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, project_position, 2171975744, godot_Vector3, self, screen_point, &z_depth)
}
void godot_Camera3D_set_perspective(godot_Camera3D *self, godot_float fov, godot_float z_near, godot_float z_far) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera3D, set_perspective, 2385087082, void, self, &fov, &z_near, &z_far)
}
void godot_Camera3D_set_orthogonal(godot_Camera3D *self, godot_float size, godot_float z_near, godot_float z_far) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera3D, set_orthogonal, 2385087082, void, self, &size, &z_near, &z_far)
}
void godot_Camera3D_set_frustum(godot_Camera3D *self, godot_float size, const godot_Vector2 *offset, godot_float z_near, godot_float z_far) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera3D, set_frustum, 354890663, void, self, &size, offset, &z_near, &z_far)
}
void godot_Camera3D_make_current(godot_Camera3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera3D, make_current, 3218959716, void, self)
}
void godot_Camera3D_clear_current(godot_Camera3D *self, godot_bool enable_next) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera3D, clear_current, 3216645846, void, self, &enable_next)
}
void godot_Camera3D_set_current(godot_Camera3D *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera3D, set_current, 2586408642, void, self, &enabled)
}
godot_bool godot_Camera3D_is_current(const godot_Camera3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, is_current, 36873697, godot_bool, self)
}
godot_Transform3D godot_Camera3D_get_camera_transform(const godot_Camera3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, get_camera_transform, 3229777777, godot_Transform3D, self)
}
godot_Projection godot_Camera3D_get_camera_projection(const godot_Camera3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, get_camera_projection, 2910717950, godot_Projection, self)
}
godot_float godot_Camera3D_get_fov(const godot_Camera3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, get_fov, 1740695150, godot_float, self)
}
godot_Vector2 godot_Camera3D_get_frustum_offset(const godot_Camera3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, get_frustum_offset, 3341600327, godot_Vector2, self)
}
godot_float godot_Camera3D_get_size(const godot_Camera3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, get_size, 1740695150, godot_float, self)
}
godot_float godot_Camera3D_get_far(const godot_Camera3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, get_far, 1740695150, godot_float, self)
}
godot_float godot_Camera3D_get_near(const godot_Camera3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, get_near, 1740695150, godot_float, self)
}
void godot_Camera3D_set_fov(godot_Camera3D *self, godot_float fov) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera3D, set_fov, 373806689, void, self, &fov)
}
void godot_Camera3D_set_frustum_offset(godot_Camera3D *self, const godot_Vector2 *offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera3D, set_frustum_offset, 743155724, void, self, offset)
}
void godot_Camera3D_set_size(godot_Camera3D *self, godot_float size) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera3D, set_size, 373806689, void, self, &size)
}
void godot_Camera3D_set_far(godot_Camera3D *self, godot_float far) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera3D, set_far, 373806689, void, self, &far)
}
void godot_Camera3D_set_near(godot_Camera3D *self, godot_float near) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera3D, set_near, 373806689, void, self, &near)
}
godot_Camera3D_ProjectionType godot_Camera3D_get_projection(const godot_Camera3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, get_projection, 2624185235, godot_Camera3D_ProjectionType, self)
}
void godot_Camera3D_set_projection(godot_Camera3D *self, godot_Camera3D_ProjectionType mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera3D, set_projection, 4218540108, void, self, &mode)
}
void godot_Camera3D_set_h_offset(godot_Camera3D *self, godot_float offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera3D, set_h_offset, 373806689, void, self, &offset)
}
godot_float godot_Camera3D_get_h_offset(const godot_Camera3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, get_h_offset, 1740695150, godot_float, self)
}
void godot_Camera3D_set_v_offset(godot_Camera3D *self, godot_float offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera3D, set_v_offset, 373806689, void, self, &offset)
}
godot_float godot_Camera3D_get_v_offset(const godot_Camera3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, get_v_offset, 1740695150, godot_float, self)
}
void godot_Camera3D_set_cull_mask(godot_Camera3D *self, godot_int mask) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera3D, set_cull_mask, 1286410249, void, self, &mask)
}
godot_int godot_Camera3D_get_cull_mask(const godot_Camera3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, get_cull_mask, 3905245786, godot_int, self)
}
void godot_Camera3D_set_environment(godot_Camera3D *self, const godot_Environment *env) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera3D, set_environment, 4143518816, void, self, env)
}
godot_Environment * godot_Camera3D_get_environment(const godot_Camera3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, get_environment, 3082064660, godot_Environment *, self)
}
void godot_Camera3D_set_attributes(godot_Camera3D *self, const godot_CameraAttributes *env) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera3D, set_attributes, 2817810567, void, self, env)
}
godot_CameraAttributes * godot_Camera3D_get_attributes(const godot_Camera3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, get_attributes, 3921283215, godot_CameraAttributes *, self)
}
void godot_Camera3D_set_compositor(godot_Camera3D *self, const godot_Compositor *compositor) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera3D, set_compositor, 1586754307, void, self, compositor)
}
godot_Compositor * godot_Camera3D_get_compositor(const godot_Camera3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, get_compositor, 3647707413, godot_Compositor *, self)
}
void godot_Camera3D_set_keep_aspect_mode(godot_Camera3D *self, godot_Camera3D_KeepAspect mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera3D, set_keep_aspect_mode, 1740651252, void, self, &mode)
}
godot_Camera3D_KeepAspect godot_Camera3D_get_keep_aspect_mode(const godot_Camera3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, get_keep_aspect_mode, 2790278316, godot_Camera3D_KeepAspect, self)
}
void godot_Camera3D_set_doppler_tracking(godot_Camera3D *self, godot_Camera3D_DopplerTracking mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera3D, set_doppler_tracking, 3109431270, void, self, &mode)
}
godot_Camera3D_DopplerTracking godot_Camera3D_get_doppler_tracking(const godot_Camera3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, get_doppler_tracking, 1584483649, godot_Camera3D_DopplerTracking, self)
}
godot_TypedArray(godot_Plane) godot_Camera3D_get_frustum(const godot_Camera3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, get_frustum, 3995934104, godot_TypedArray(godot_Plane), self)
}
godot_bool godot_Camera3D_is_position_in_frustum(const godot_Camera3D *self, const godot_Vector3 *world_point) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, is_position_in_frustum, 3108956480, godot_bool, self, world_point)
}
godot_RID godot_Camera3D_get_camera_rid(const godot_Camera3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, get_camera_rid, 2944877500, godot_RID, self)
}
godot_RID godot_Camera3D_get_pyramid_shape_rid(godot_Camera3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, get_pyramid_shape_rid, 529393457, godot_RID, self)
}
void godot_Camera3D_set_cull_mask_value(godot_Camera3D *self, godot_int layer_number, godot_bool value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Camera3D, set_cull_mask_value, 300928843, void, self, &layer_number, &value)
}
godot_bool godot_Camera3D_get_cull_mask_value(const godot_Camera3D *self, godot_int layer_number) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Camera3D, get_cull_mask_value, 1116898809, godot_bool, self, &layer_number)
}


#ifdef __cplusplus
}
#endif
