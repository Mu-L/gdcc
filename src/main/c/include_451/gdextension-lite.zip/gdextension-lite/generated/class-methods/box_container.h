// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BOX_CONTAINER_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BOX_CONTAINER_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_BoxContainer *godot_new_BoxContainer();

// Methods
GDEXTENSION_LITE_DECL godot_Control * godot_BoxContainer_add_spacer(godot_BoxContainer *self, godot_bool begin);
GDEXTENSION_LITE_DECL void godot_BoxContainer_set_alignment(godot_BoxContainer *self, godot_BoxContainer_AlignmentMode alignment);
GDEXTENSION_LITE_DECL godot_BoxContainer_AlignmentMode godot_BoxContainer_get_alignment(const godot_BoxContainer *self);
GDEXTENSION_LITE_DECL void godot_BoxContainer_set_vertical(godot_BoxContainer *self, godot_bool vertical);
GDEXTENSION_LITE_DECL godot_bool godot_BoxContainer_is_vertical(const godot_BoxContainer *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BOX_CONTAINER_H__
