// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_RANDOMIZER_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_RANDOMIZER_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioStreamRandomizer *godot_new_AudioStreamRandomizer();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioStreamRandomizer_add_stream(godot_AudioStreamRandomizer *self, godot_int index, const godot_AudioStream *stream, godot_float weight);
GDEXTENSION_LITE_DECL void godot_AudioStreamRandomizer_move_stream(godot_AudioStreamRandomizer *self, godot_int index_from, godot_int index_to);
GDEXTENSION_LITE_DECL void godot_AudioStreamRandomizer_remove_stream(godot_AudioStreamRandomizer *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_AudioStreamRandomizer_set_stream(godot_AudioStreamRandomizer *self, godot_int index, const godot_AudioStream *stream);
GDEXTENSION_LITE_DECL godot_AudioStream * godot_AudioStreamRandomizer_get_stream(const godot_AudioStreamRandomizer *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_AudioStreamRandomizer_set_stream_probability_weight(godot_AudioStreamRandomizer *self, godot_int index, godot_float weight);
GDEXTENSION_LITE_DECL godot_float godot_AudioStreamRandomizer_get_stream_probability_weight(const godot_AudioStreamRandomizer *self, godot_int index);
GDEXTENSION_LITE_DECL void godot_AudioStreamRandomizer_set_streams_count(godot_AudioStreamRandomizer *self, godot_int count);
GDEXTENSION_LITE_DECL godot_int godot_AudioStreamRandomizer_get_streams_count(const godot_AudioStreamRandomizer *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamRandomizer_set_random_pitch(godot_AudioStreamRandomizer *self, godot_float scale);
GDEXTENSION_LITE_DECL godot_float godot_AudioStreamRandomizer_get_random_pitch(const godot_AudioStreamRandomizer *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamRandomizer_set_random_volume_offset_db(godot_AudioStreamRandomizer *self, godot_float db_offset);
GDEXTENSION_LITE_DECL godot_float godot_AudioStreamRandomizer_get_random_volume_offset_db(const godot_AudioStreamRandomizer *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamRandomizer_set_playback_mode(godot_AudioStreamRandomizer *self, godot_AudioStreamRandomizer_PlaybackMode mode);
GDEXTENSION_LITE_DECL godot_AudioStreamRandomizer_PlaybackMode godot_AudioStreamRandomizer_get_playback_mode(const godot_AudioStreamRandomizer *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_RANDOMIZER_H__
