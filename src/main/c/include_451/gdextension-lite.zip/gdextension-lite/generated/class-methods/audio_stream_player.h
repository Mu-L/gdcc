// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_PLAYER_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_PLAYER_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioStreamPlayer *godot_new_AudioStreamPlayer();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioStreamPlayer_set_stream(godot_AudioStreamPlayer *self, const godot_AudioStream *stream);
GDEXTENSION_LITE_DECL godot_AudioStream * godot_AudioStreamPlayer_get_stream(const godot_AudioStreamPlayer *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlayer_set_volume_db(godot_AudioStreamPlayer *self, godot_float volume_db);
GDEXTENSION_LITE_DECL godot_float godot_AudioStreamPlayer_get_volume_db(const godot_AudioStreamPlayer *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlayer_set_volume_linear(godot_AudioStreamPlayer *self, godot_float volume_linear);
GDEXTENSION_LITE_DECL godot_float godot_AudioStreamPlayer_get_volume_linear(const godot_AudioStreamPlayer *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlayer_set_pitch_scale(godot_AudioStreamPlayer *self, godot_float pitch_scale);
GDEXTENSION_LITE_DECL godot_float godot_AudioStreamPlayer_get_pitch_scale(const godot_AudioStreamPlayer *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlayer_play(godot_AudioStreamPlayer *self, godot_float from_position);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlayer_seek(godot_AudioStreamPlayer *self, godot_float to_position);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlayer_stop(godot_AudioStreamPlayer *self);
GDEXTENSION_LITE_DECL godot_bool godot_AudioStreamPlayer_is_playing(const godot_AudioStreamPlayer *self);
GDEXTENSION_LITE_DECL godot_float godot_AudioStreamPlayer_get_playback_position(godot_AudioStreamPlayer *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlayer_set_bus(godot_AudioStreamPlayer *self, const godot_StringName *bus);
GDEXTENSION_LITE_DECL godot_StringName godot_AudioStreamPlayer_get_bus(const godot_AudioStreamPlayer *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlayer_set_autoplay(godot_AudioStreamPlayer *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_AudioStreamPlayer_is_autoplay_enabled(const godot_AudioStreamPlayer *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlayer_set_mix_target(godot_AudioStreamPlayer *self, godot_AudioStreamPlayer_MixTarget mix_target);
GDEXTENSION_LITE_DECL godot_AudioStreamPlayer_MixTarget godot_AudioStreamPlayer_get_mix_target(const godot_AudioStreamPlayer *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlayer_set_playing(godot_AudioStreamPlayer *self, godot_bool enable);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlayer_set_stream_paused(godot_AudioStreamPlayer *self, godot_bool pause);
GDEXTENSION_LITE_DECL godot_bool godot_AudioStreamPlayer_get_stream_paused(const godot_AudioStreamPlayer *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlayer_set_max_polyphony(godot_AudioStreamPlayer *self, godot_int max_polyphony);
GDEXTENSION_LITE_DECL godot_int godot_AudioStreamPlayer_get_max_polyphony(const godot_AudioStreamPlayer *self);
GDEXTENSION_LITE_DECL godot_bool godot_AudioStreamPlayer_has_stream_playback(godot_AudioStreamPlayer *self);
GDEXTENSION_LITE_DECL godot_AudioStreamPlayback * godot_AudioStreamPlayer_get_stream_playback(godot_AudioStreamPlayer *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamPlayer_set_playback_type(godot_AudioStreamPlayer *self, godot_AudioServer_PlaybackType playback_type);
GDEXTENSION_LITE_DECL godot_AudioServer_PlaybackType godot_AudioStreamPlayer_get_playback_type(const godot_AudioStreamPlayer *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_PLAYER_H__
