// This file was automatically generated
// Do not modify this file
#include "audio_effect_capture.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectCapture *godot_new_AudioEffectCapture() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectCapture);
}

// Methods
godot_bool godot_AudioEffectCapture_can_get_buffer(const godot_AudioEffectCapture *self, godot_int frames) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectCapture, can_get_buffer, 1116898809, godot_bool, self, &frames)
}
godot_PackedVector2Array godot_AudioEffectCapture_get_buffer(godot_AudioEffectCapture *self, godot_int frames) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectCapture, get_buffer, 2649534757, godot_PackedVector2Array, self, &frames)
}
void godot_AudioEffectCapture_clear_buffer(godot_AudioEffectCapture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectCapture, clear_buffer, 3218959716, void, self)
}
void godot_AudioEffectCapture_set_buffer_length(godot_AudioEffectCapture *self, godot_float buffer_length_seconds) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectCapture, set_buffer_length, 373806689, void, self, &buffer_length_seconds)
}
godot_float godot_AudioEffectCapture_get_buffer_length(godot_AudioEffectCapture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectCapture, get_buffer_length, 191475506, godot_float, self)
}
godot_int godot_AudioEffectCapture_get_frames_available(const godot_AudioEffectCapture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectCapture, get_frames_available, 3905245786, godot_int, self)
}
godot_int godot_AudioEffectCapture_get_discarded_frames(const godot_AudioEffectCapture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectCapture, get_discarded_frames, 3905245786, godot_int, self)
}
godot_int godot_AudioEffectCapture_get_buffer_length_frames(const godot_AudioEffectCapture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectCapture, get_buffer_length_frames, 3905245786, godot_int, self)
}
godot_int godot_AudioEffectCapture_get_pushed_frames(const godot_AudioEffectCapture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectCapture, get_pushed_frames, 3905245786, godot_int, self)
}


#ifdef __cplusplus
}
#endif
