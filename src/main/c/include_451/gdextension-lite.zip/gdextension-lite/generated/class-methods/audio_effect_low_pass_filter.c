// This file was automatically generated
// Do not modify this file
#include "audio_effect_low_pass_filter.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectLowPassFilter *godot_new_AudioEffectLowPassFilter() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectLowPassFilter);
}


#ifdef __cplusplus
}
#endif
