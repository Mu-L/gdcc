// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_OGG_VORBIS_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_OGG_VORBIS_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioStreamOggVorbis *godot_new_AudioStreamOggVorbis();

// Methods
GDEXTENSION_LITE_DECL godot_AudioStreamOggVorbis * godot_AudioStreamOggVorbis_load_from_buffer(const godot_PackedByteArray *stream_data);
GDEXTENSION_LITE_DECL godot_AudioStreamOggVorbis * godot_AudioStreamOggVorbis_load_from_file(const godot_String *path);
GDEXTENSION_LITE_DECL void godot_AudioStreamOggVorbis_set_packet_sequence(godot_AudioStreamOggVorbis *self, const godot_OggPacketSequence *packet_sequence);
GDEXTENSION_LITE_DECL godot_OggPacketSequence * godot_AudioStreamOggVorbis_get_packet_sequence(const godot_AudioStreamOggVorbis *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamOggVorbis_set_loop(godot_AudioStreamOggVorbis *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_AudioStreamOggVorbis_has_loop(const godot_AudioStreamOggVorbis *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamOggVorbis_set_loop_offset(godot_AudioStreamOggVorbis *self, godot_float seconds);
GDEXTENSION_LITE_DECL godot_float godot_AudioStreamOggVorbis_get_loop_offset(const godot_AudioStreamOggVorbis *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamOggVorbis_set_bpm(godot_AudioStreamOggVorbis *self, godot_float bpm);
GDEXTENSION_LITE_DECL godot_float godot_AudioStreamOggVorbis_get_bpm(const godot_AudioStreamOggVorbis *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamOggVorbis_set_beat_count(godot_AudioStreamOggVorbis *self, godot_int count);
GDEXTENSION_LITE_DECL godot_int godot_AudioStreamOggVorbis_get_beat_count(const godot_AudioStreamOggVorbis *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamOggVorbis_set_bar_beats(godot_AudioStreamOggVorbis *self, godot_int count);
GDEXTENSION_LITE_DECL godot_int godot_AudioStreamOggVorbis_get_bar_beats(const godot_AudioStreamOggVorbis *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamOggVorbis_set_tags(godot_AudioStreamOggVorbis *self, const godot_Dictionary *tags);
GDEXTENSION_LITE_DECL godot_Dictionary godot_AudioStreamOggVorbis_get_tags(const godot_AudioStreamOggVorbis *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_OGG_VORBIS_H__
