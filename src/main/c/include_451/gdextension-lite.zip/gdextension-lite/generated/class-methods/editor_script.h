// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_SCRIPT_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_SCRIPT_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorScript *godot_new_EditorScript();

// Methods
GDEXTENSION_LITE_DECL void godot_EditorScript__run(godot_EditorScript *self);
GDEXTENSION_LITE_DECL void godot_EditorScript_add_root_node(godot_EditorScript *self, const godot_Node *node);
GDEXTENSION_LITE_DECL godot_Node * godot_EditorScript_get_scene(const godot_EditorScript *self);
GDEXTENSION_LITE_DECL godot_EditorInterface * godot_EditorScript_get_editor_interface(const godot_EditorScript *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_SCRIPT_H__
