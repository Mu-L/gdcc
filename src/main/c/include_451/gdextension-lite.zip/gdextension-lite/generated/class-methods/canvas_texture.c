// This file was automatically generated
// Do not modify this file
#include "canvas_texture.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CanvasTexture *godot_new_CanvasTexture() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CanvasTexture);
}

// Methods
void godot_CanvasTexture_set_diffuse_texture(godot_CanvasTexture *self, const godot_Texture2D *texture) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasTexture, set_diffuse_texture, 4051416890, void, self, texture)
}
godot_Texture2D * godot_CanvasTexture_get_diffuse_texture(const godot_CanvasTexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasTexture, get_diffuse_texture, 3635182373, godot_Texture2D *, self)
}
void godot_CanvasTexture_set_normal_texture(godot_CanvasTexture *self, const godot_Texture2D *texture) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasTexture, set_normal_texture, 4051416890, void, self, texture)
}
godot_Texture2D * godot_CanvasTexture_get_normal_texture(const godot_CanvasTexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasTexture, get_normal_texture, 3635182373, godot_Texture2D *, self)
}
void godot_CanvasTexture_set_specular_texture(godot_CanvasTexture *self, const godot_Texture2D *texture) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasTexture, set_specular_texture, 4051416890, void, self, texture)
}
godot_Texture2D * godot_CanvasTexture_get_specular_texture(const godot_CanvasTexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasTexture, get_specular_texture, 3635182373, godot_Texture2D *, self)
}
void godot_CanvasTexture_set_specular_color(godot_CanvasTexture *self, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasTexture, set_specular_color, 2920490490, void, self, color)
}
godot_Color godot_CanvasTexture_get_specular_color(const godot_CanvasTexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasTexture, get_specular_color, 3444240500, godot_Color, self)
}
void godot_CanvasTexture_set_specular_shininess(godot_CanvasTexture *self, godot_float shininess) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasTexture, set_specular_shininess, 373806689, void, self, &shininess)
}
godot_float godot_CanvasTexture_get_specular_shininess(const godot_CanvasTexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasTexture, get_specular_shininess, 1740695150, godot_float, self)
}
void godot_CanvasTexture_set_texture_filter(godot_CanvasTexture *self, godot_CanvasItem_TextureFilter filter) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasTexture, set_texture_filter, 1037999706, void, self, &filter)
}
godot_CanvasItem_TextureFilter godot_CanvasTexture_get_texture_filter(const godot_CanvasTexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasTexture, get_texture_filter, 121960042, godot_CanvasItem_TextureFilter, self)
}
void godot_CanvasTexture_set_texture_repeat(godot_CanvasTexture *self, godot_CanvasItem_TextureRepeat repeat) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CanvasTexture, set_texture_repeat, 1716472974, void, self, &repeat)
}
godot_CanvasItem_TextureRepeat godot_CanvasTexture_get_texture_repeat(const godot_CanvasTexture *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CanvasTexture, get_texture_repeat, 2667158319, godot_CanvasItem_TextureRepeat, self)
}


#ifdef __cplusplus
}
#endif
