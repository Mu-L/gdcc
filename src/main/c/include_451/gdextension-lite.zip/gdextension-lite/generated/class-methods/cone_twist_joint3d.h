// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONE_TWIST_JOINT3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONE_TWIST_JOINT3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_ConeTwistJoint3D *godot_new_ConeTwistJoint3D();

// Methods
GDEXTENSION_LITE_DECL void godot_ConeTwistJoint3D_set_param(godot_ConeTwistJoint3D *self, godot_ConeTwistJoint3D_Param param, godot_float value);
GDEXTENSION_LITE_DECL godot_float godot_ConeTwistJoint3D_get_param(const godot_ConeTwistJoint3D *self, godot_ConeTwistJoint3D_Param param);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONE_TWIST_JOINT3D_H__
