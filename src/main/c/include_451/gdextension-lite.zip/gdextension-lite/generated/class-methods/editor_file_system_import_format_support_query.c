// This file was automatically generated
// Do not modify this file
#include "editor_file_system_import_format_support_query.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorFileSystemImportFormatSupportQuery *godot_new_EditorFileSystemImportFormatSupportQuery() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorFileSystemImportFormatSupportQuery);
}

// Methods
godot_bool godot_EditorFileSystemImportFormatSupportQuery__is_active(const godot_EditorFileSystemImportFormatSupportQuery *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileSystemImportFormatSupportQuery, _is_active, 36873697, godot_bool, self)
}
godot_PackedStringArray godot_EditorFileSystemImportFormatSupportQuery__get_file_extensions(const godot_EditorFileSystemImportFormatSupportQuery *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileSystemImportFormatSupportQuery, _get_file_extensions, 1139954409, godot_PackedStringArray, self)
}
godot_bool godot_EditorFileSystemImportFormatSupportQuery__query(const godot_EditorFileSystemImportFormatSupportQuery *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorFileSystemImportFormatSupportQuery, _query, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
