// This file was automatically generated
// Do not modify this file
#include "aescontext.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AESContext *godot_new_AESContext() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AESContext);
}

// Methods
godot_Error godot_AESContext_start(godot_AESContext *self, godot_AESContext_Mode mode, const godot_PackedByteArray *key, const godot_PackedByteArray *iv) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AESContext, start, 3122411423, godot_Error, self, &mode, key, iv)
}
godot_PackedByteArray godot_AESContext_update(godot_AESContext *self, const godot_PackedByteArray *src) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AESContext, update, 527836100, godot_PackedByteArray, self, src)
}
godot_PackedByteArray godot_AESContext_get_iv_state(godot_AESContext *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AESContext, get_iv_state, 2115431945, godot_PackedByteArray, self)
}
void godot_AESContext_finish(godot_AESContext *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AESContext, finish, 3218959716, void, self)
}


#ifdef __cplusplus
}
#endif
