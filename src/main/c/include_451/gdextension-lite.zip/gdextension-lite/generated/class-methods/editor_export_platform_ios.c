// This file was automatically generated
// Do not modify this file
#include "editor_export_platform_ios.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorExportPlatformIOS *godot_new_EditorExportPlatformIOS() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorExportPlatformIOS);
}


#ifdef __cplusplus
}
#endif
