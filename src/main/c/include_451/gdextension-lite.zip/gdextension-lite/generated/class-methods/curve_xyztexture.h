// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CURVE_XYZTEXTURE_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CURVE_XYZTEXTURE_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CurveXYZTexture *godot_new_CurveXYZTexture();

// Methods
GDEXTENSION_LITE_DECL void godot_CurveXYZTexture_set_width(godot_CurveXYZTexture *self, godot_int width);
GDEXTENSION_LITE_DECL void godot_CurveXYZTexture_set_curve_x(godot_CurveXYZTexture *self, const godot_Curve *curve);
GDEXTENSION_LITE_DECL godot_Curve * godot_CurveXYZTexture_get_curve_x(const godot_CurveXYZTexture *self);
GDEXTENSION_LITE_DECL void godot_CurveXYZTexture_set_curve_y(godot_CurveXYZTexture *self, const godot_Curve *curve);
GDEXTENSION_LITE_DECL godot_Curve * godot_CurveXYZTexture_get_curve_y(const godot_CurveXYZTexture *self);
GDEXTENSION_LITE_DECL void godot_CurveXYZTexture_set_curve_z(godot_CurveXYZTexture *self, const godot_Curve *curve);
GDEXTENSION_LITE_DECL godot_Curve * godot_CurveXYZTexture_get_curve_z(const godot_CurveXYZTexture *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CURVE_XYZTEXTURE_H__
