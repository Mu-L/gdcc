// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_INSTANCE_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_INSTANCE_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioEffectInstance *godot_new_AudioEffectInstance();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioEffectInstance__process(godot_AudioEffectInstance *self, const void* src_buffer, godot_AudioFrame* dst_buffer, godot_int frame_count);
GDEXTENSION_LITE_DECL godot_bool godot_AudioEffectInstance__process_silence(const godot_AudioEffectInstance *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_INSTANCE_H__
