// This file was automatically generated
// Do not modify this file
#include "csgshape3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
godot_bool godot_CSGShape3D_is_root_shape(const godot_CSGShape3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGShape3D, is_root_shape, 36873697, godot_bool, self)
}
void godot_CSGShape3D_set_operation(godot_CSGShape3D *self, godot_CSGShape3D_Operation operation) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGShape3D, set_operation, 811425055, void, self, &operation)
}
godot_CSGShape3D_Operation godot_CSGShape3D_get_operation(const godot_CSGShape3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGShape3D, get_operation, 2662425879, godot_CSGShape3D_Operation, self)
}
void godot_CSGShape3D_set_snap(godot_CSGShape3D *self, godot_float snap) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGShape3D, set_snap, 373806689, void, self, &snap)
}
godot_float godot_CSGShape3D_get_snap(const godot_CSGShape3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGShape3D, get_snap, 1740695150, godot_float, self)
}
void godot_CSGShape3D_set_use_collision(godot_CSGShape3D *self, godot_bool operation) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGShape3D, set_use_collision, 2586408642, void, self, &operation)
}
godot_bool godot_CSGShape3D_is_using_collision(const godot_CSGShape3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGShape3D, is_using_collision, 36873697, godot_bool, self)
}
void godot_CSGShape3D_set_collision_layer(godot_CSGShape3D *self, godot_int layer) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGShape3D, set_collision_layer, 1286410249, void, self, &layer)
}
godot_int godot_CSGShape3D_get_collision_layer(const godot_CSGShape3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGShape3D, get_collision_layer, 3905245786, godot_int, self)
}
void godot_CSGShape3D_set_collision_mask(godot_CSGShape3D *self, godot_int mask) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGShape3D, set_collision_mask, 1286410249, void, self, &mask)
}
godot_int godot_CSGShape3D_get_collision_mask(const godot_CSGShape3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGShape3D, get_collision_mask, 3905245786, godot_int, self)
}
void godot_CSGShape3D_set_collision_mask_value(godot_CSGShape3D *self, godot_int layer_number, godot_bool value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGShape3D, set_collision_mask_value, 300928843, void, self, &layer_number, &value)
}
godot_bool godot_CSGShape3D_get_collision_mask_value(const godot_CSGShape3D *self, godot_int layer_number) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGShape3D, get_collision_mask_value, 1116898809, godot_bool, self, &layer_number)
}
void godot_CSGShape3D_set_collision_layer_value(godot_CSGShape3D *self, godot_int layer_number, godot_bool value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGShape3D, set_collision_layer_value, 300928843, void, self, &layer_number, &value)
}
godot_bool godot_CSGShape3D_get_collision_layer_value(const godot_CSGShape3D *self, godot_int layer_number) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGShape3D, get_collision_layer_value, 1116898809, godot_bool, self, &layer_number)
}
void godot_CSGShape3D_set_collision_priority(godot_CSGShape3D *self, godot_float priority) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGShape3D, set_collision_priority, 373806689, void, self, &priority)
}
godot_float godot_CSGShape3D_get_collision_priority(const godot_CSGShape3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGShape3D, get_collision_priority, 1740695150, godot_float, self)
}
godot_ConcavePolygonShape3D * godot_CSGShape3D_bake_collision_shape(godot_CSGShape3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGShape3D, bake_collision_shape, 36102322, godot_ConcavePolygonShape3D *, self)
}
void godot_CSGShape3D_set_calculate_tangents(godot_CSGShape3D *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGShape3D, set_calculate_tangents, 2586408642, void, self, &enabled)
}
godot_bool godot_CSGShape3D_is_calculating_tangents(const godot_CSGShape3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGShape3D, is_calculating_tangents, 36873697, godot_bool, self)
}
godot_Array godot_CSGShape3D_get_meshes(const godot_CSGShape3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGShape3D, get_meshes, 3995934104, godot_Array, self)
}
godot_ArrayMesh * godot_CSGShape3D_bake_static_mesh(godot_CSGShape3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGShape3D, bake_static_mesh, 1605880883, godot_ArrayMesh *, self)
}


#ifdef __cplusplus
}
#endif
