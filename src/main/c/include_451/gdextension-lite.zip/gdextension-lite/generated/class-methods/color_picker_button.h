// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLOR_PICKER_BUTTON_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLOR_PICKER_BUTTON_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_ColorPickerButton *godot_new_ColorPickerButton();

// Methods
GDEXTENSION_LITE_DECL void godot_ColorPickerButton_set_pick_color(godot_ColorPickerButton *self, const godot_Color *color);
GDEXTENSION_LITE_DECL godot_Color godot_ColorPickerButton_get_pick_color(const godot_ColorPickerButton *self);
GDEXTENSION_LITE_DECL godot_ColorPicker * godot_ColorPickerButton_get_picker(godot_ColorPickerButton *self);
GDEXTENSION_LITE_DECL godot_PopupPanel * godot_ColorPickerButton_get_popup(godot_ColorPickerButton *self);
GDEXTENSION_LITE_DECL void godot_ColorPickerButton_set_edit_alpha(godot_ColorPickerButton *self, godot_bool show);
GDEXTENSION_LITE_DECL godot_bool godot_ColorPickerButton_is_editing_alpha(const godot_ColorPickerButton *self);
GDEXTENSION_LITE_DECL void godot_ColorPickerButton_set_edit_intensity(godot_ColorPickerButton *self, godot_bool show);
GDEXTENSION_LITE_DECL godot_bool godot_ColorPickerButton_is_editing_intensity(const godot_ColorPickerButton *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLOR_PICKER_BUTTON_H__
