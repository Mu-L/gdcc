// This file was automatically generated
// Do not modify this file
#include "audio_effect_eq21.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectEQ21 *godot_new_AudioEffectEQ21() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectEQ21);
}


#ifdef __cplusplus
}
#endif
