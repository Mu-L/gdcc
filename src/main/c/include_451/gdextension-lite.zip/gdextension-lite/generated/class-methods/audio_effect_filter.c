// This file was automatically generated
// Do not modify this file
#include "audio_effect_filter.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectFilter *godot_new_AudioEffectFilter() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectFilter);
}

// Methods
void godot_AudioEffectFilter_set_cutoff(godot_AudioEffectFilter *self, godot_float freq) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectFilter, set_cutoff, 373806689, void, self, &freq)
}
godot_float godot_AudioEffectFilter_get_cutoff(const godot_AudioEffectFilter *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectFilter, get_cutoff, 1740695150, godot_float, self)
}
void godot_AudioEffectFilter_set_resonance(godot_AudioEffectFilter *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectFilter, set_resonance, 373806689, void, self, &amount)
}
godot_float godot_AudioEffectFilter_get_resonance(const godot_AudioEffectFilter *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectFilter, get_resonance, 1740695150, godot_float, self)
}
void godot_AudioEffectFilter_set_gain(godot_AudioEffectFilter *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectFilter, set_gain, 373806689, void, self, &amount)
}
godot_float godot_AudioEffectFilter_get_gain(const godot_AudioEffectFilter *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectFilter, get_gain, 1740695150, godot_float, self)
}
void godot_AudioEffectFilter_set_db(godot_AudioEffectFilter *self, godot_AudioEffectFilter_FilterDB amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectFilter, set_db, 771740901, void, self, &amount)
}
godot_AudioEffectFilter_FilterDB godot_AudioEffectFilter_get_db(const godot_AudioEffectFilter *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectFilter, get_db, 3981721890, godot_AudioEffectFilter_FilterDB, self)
}


#ifdef __cplusplus
}
#endif
