// This file was automatically generated
// Do not modify this file
#include "animation_node_state_machine_playback.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimationNodeStateMachinePlayback *godot_new_AnimationNodeStateMachinePlayback() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimationNodeStateMachinePlayback);
}

// Methods
void godot_AnimationNodeStateMachinePlayback_travel(godot_AnimationNodeStateMachinePlayback *self, const godot_StringName *to_node, godot_bool reset_on_teleport) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachinePlayback, travel, 3823612587, void, self, to_node, &reset_on_teleport)
}
void godot_AnimationNodeStateMachinePlayback_start(godot_AnimationNodeStateMachinePlayback *self, const godot_StringName *node, godot_bool reset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachinePlayback, start, 3823612587, void, self, node, &reset)
}
void godot_AnimationNodeStateMachinePlayback_next(godot_AnimationNodeStateMachinePlayback *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachinePlayback, next, 3218959716, void, self)
}
void godot_AnimationNodeStateMachinePlayback_stop(godot_AnimationNodeStateMachinePlayback *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachinePlayback, stop, 3218959716, void, self)
}
godot_bool godot_AnimationNodeStateMachinePlayback_is_playing(const godot_AnimationNodeStateMachinePlayback *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachinePlayback, is_playing, 36873697, godot_bool, self)
}
godot_StringName godot_AnimationNodeStateMachinePlayback_get_current_node(const godot_AnimationNodeStateMachinePlayback *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachinePlayback, get_current_node, 2002593661, godot_StringName, self)
}
godot_float godot_AnimationNodeStateMachinePlayback_get_current_play_position(const godot_AnimationNodeStateMachinePlayback *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachinePlayback, get_current_play_position, 1740695150, godot_float, self)
}
godot_float godot_AnimationNodeStateMachinePlayback_get_current_length(const godot_AnimationNodeStateMachinePlayback *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachinePlayback, get_current_length, 1740695150, godot_float, self)
}
godot_StringName godot_AnimationNodeStateMachinePlayback_get_fading_from_node(const godot_AnimationNodeStateMachinePlayback *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachinePlayback, get_fading_from_node, 2002593661, godot_StringName, self)
}
godot_TypedArray(godot_StringName) godot_AnimationNodeStateMachinePlayback_get_travel_path(const godot_AnimationNodeStateMachinePlayback *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachinePlayback, get_travel_path, 3995934104, godot_TypedArray(godot_StringName), self)
}


#ifdef __cplusplus
}
#endif
