// This file was automatically generated
// Do not modify this file
#include "animation_player.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimationPlayer *godot_new_AnimationPlayer() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimationPlayer);
}

// Methods
void godot_AnimationPlayer_animation_set_next(godot_AnimationPlayer *self, const godot_StringName *animation_from, const godot_StringName *animation_to) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, animation_set_next, 3740211285, void, self, animation_from, animation_to)
}
godot_StringName godot_AnimationPlayer_animation_get_next(const godot_AnimationPlayer *self, const godot_StringName *animation_from) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationPlayer, animation_get_next, 1965194235, godot_StringName, self, animation_from)
}
void godot_AnimationPlayer_set_blend_time(godot_AnimationPlayer *self, const godot_StringName *animation_from, const godot_StringName *animation_to, godot_float sec) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, set_blend_time, 3231131886, void, self, animation_from, animation_to, &sec)
}
godot_float godot_AnimationPlayer_get_blend_time(const godot_AnimationPlayer *self, const godot_StringName *animation_from, const godot_StringName *animation_to) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationPlayer, get_blend_time, 1958752504, godot_float, self, animation_from, animation_to)
}
void godot_AnimationPlayer_set_default_blend_time(godot_AnimationPlayer *self, godot_float sec) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, set_default_blend_time, 373806689, void, self, &sec)
}
godot_float godot_AnimationPlayer_get_default_blend_time(const godot_AnimationPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationPlayer, get_default_blend_time, 1740695150, godot_float, self)
}
void godot_AnimationPlayer_set_auto_capture(godot_AnimationPlayer *self, godot_bool auto_capture) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, set_auto_capture, 2586408642, void, self, &auto_capture)
}
godot_bool godot_AnimationPlayer_is_auto_capture(const godot_AnimationPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationPlayer, is_auto_capture, 36873697, godot_bool, self)
}
void godot_AnimationPlayer_set_auto_capture_duration(godot_AnimationPlayer *self, godot_float auto_capture_duration) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, set_auto_capture_duration, 373806689, void, self, &auto_capture_duration)
}
godot_float godot_AnimationPlayer_get_auto_capture_duration(const godot_AnimationPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationPlayer, get_auto_capture_duration, 1740695150, godot_float, self)
}
void godot_AnimationPlayer_set_auto_capture_transition_type(godot_AnimationPlayer *self, godot_Tween_TransitionType auto_capture_transition_type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, set_auto_capture_transition_type, 1058637742, void, self, &auto_capture_transition_type)
}
godot_Tween_TransitionType godot_AnimationPlayer_get_auto_capture_transition_type(const godot_AnimationPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationPlayer, get_auto_capture_transition_type, 3842314528, godot_Tween_TransitionType, self)
}
void godot_AnimationPlayer_set_auto_capture_ease_type(godot_AnimationPlayer *self, godot_Tween_EaseType auto_capture_ease_type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, set_auto_capture_ease_type, 1208105857, void, self, &auto_capture_ease_type)
}
godot_Tween_EaseType godot_AnimationPlayer_get_auto_capture_ease_type(const godot_AnimationPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationPlayer, get_auto_capture_ease_type, 631880200, godot_Tween_EaseType, self)
}
void godot_AnimationPlayer_play(godot_AnimationPlayer *self, const godot_StringName *name, godot_float custom_blend, godot_float custom_speed, godot_bool from_end) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, play, 3118260607, void, self, name, &custom_blend, &custom_speed, &from_end)
}
void godot_AnimationPlayer_play_section_with_markers(godot_AnimationPlayer *self, const godot_StringName *name, const godot_StringName *start_marker, const godot_StringName *end_marker, godot_float custom_blend, godot_float custom_speed, godot_bool from_end) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, play_section_with_markers, 1421431412, void, self, name, start_marker, end_marker, &custom_blend, &custom_speed, &from_end)
}
void godot_AnimationPlayer_play_section(godot_AnimationPlayer *self, const godot_StringName *name, godot_float start_time, godot_float end_time, godot_float custom_blend, godot_float custom_speed, godot_bool from_end) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, play_section, 284774635, void, self, name, &start_time, &end_time, &custom_blend, &custom_speed, &from_end)
}
void godot_AnimationPlayer_play_backwards(godot_AnimationPlayer *self, const godot_StringName *name, godot_float custom_blend) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, play_backwards, 2787282401, void, self, name, &custom_blend)
}
void godot_AnimationPlayer_play_section_with_markers_backwards(godot_AnimationPlayer *self, const godot_StringName *name, const godot_StringName *start_marker, const godot_StringName *end_marker, godot_float custom_blend) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, play_section_with_markers_backwards, 910195100, void, self, name, start_marker, end_marker, &custom_blend)
}
void godot_AnimationPlayer_play_section_backwards(godot_AnimationPlayer *self, const godot_StringName *name, godot_float start_time, godot_float end_time, godot_float custom_blend) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, play_section_backwards, 831955981, void, self, name, &start_time, &end_time, &custom_blend)
}
void godot_AnimationPlayer_play_with_capture(godot_AnimationPlayer *self, const godot_StringName *name, godot_float duration, godot_float custom_blend, godot_float custom_speed, godot_bool from_end, godot_Tween_TransitionType trans_type, godot_Tween_EaseType ease_type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, play_with_capture, 1572969103, void, self, name, &duration, &custom_blend, &custom_speed, &from_end, &trans_type, &ease_type)
}
void godot_AnimationPlayer_pause(godot_AnimationPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, pause, 3218959716, void, self)
}
void godot_AnimationPlayer_stop(godot_AnimationPlayer *self, godot_bool keep_state) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, stop, 107499316, void, self, &keep_state)
}
godot_bool godot_AnimationPlayer_is_playing(const godot_AnimationPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationPlayer, is_playing, 36873697, godot_bool, self)
}
void godot_AnimationPlayer_set_current_animation(godot_AnimationPlayer *self, const godot_String *animation) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, set_current_animation, 83702148, void, self, animation)
}
godot_String godot_AnimationPlayer_get_current_animation(const godot_AnimationPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationPlayer, get_current_animation, 201670096, godot_String, self)
}
void godot_AnimationPlayer_set_assigned_animation(godot_AnimationPlayer *self, const godot_String *animation) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, set_assigned_animation, 83702148, void, self, animation)
}
godot_String godot_AnimationPlayer_get_assigned_animation(const godot_AnimationPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationPlayer, get_assigned_animation, 201670096, godot_String, self)
}
void godot_AnimationPlayer_queue(godot_AnimationPlayer *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, queue, 3304788590, void, self, name)
}
godot_PackedStringArray godot_AnimationPlayer_get_queue(godot_AnimationPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationPlayer, get_queue, 2981934095, godot_PackedStringArray, self)
}
void godot_AnimationPlayer_clear_queue(godot_AnimationPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, clear_queue, 3218959716, void, self)
}
void godot_AnimationPlayer_set_speed_scale(godot_AnimationPlayer *self, godot_float speed) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, set_speed_scale, 373806689, void, self, &speed)
}
godot_float godot_AnimationPlayer_get_speed_scale(const godot_AnimationPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationPlayer, get_speed_scale, 1740695150, godot_float, self)
}
godot_float godot_AnimationPlayer_get_playing_speed(const godot_AnimationPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationPlayer, get_playing_speed, 1740695150, godot_float, self)
}
void godot_AnimationPlayer_set_autoplay(godot_AnimationPlayer *self, const godot_String *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, set_autoplay, 83702148, void, self, name)
}
godot_String godot_AnimationPlayer_get_autoplay(const godot_AnimationPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationPlayer, get_autoplay, 201670096, godot_String, self)
}
void godot_AnimationPlayer_set_movie_quit_on_finish_enabled(godot_AnimationPlayer *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, set_movie_quit_on_finish_enabled, 2586408642, void, self, &enabled)
}
godot_bool godot_AnimationPlayer_is_movie_quit_on_finish_enabled(const godot_AnimationPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationPlayer, is_movie_quit_on_finish_enabled, 36873697, godot_bool, self)
}
godot_float godot_AnimationPlayer_get_current_animation_position(const godot_AnimationPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationPlayer, get_current_animation_position, 1740695150, godot_float, self)
}
godot_float godot_AnimationPlayer_get_current_animation_length(const godot_AnimationPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationPlayer, get_current_animation_length, 1740695150, godot_float, self)
}
void godot_AnimationPlayer_set_section_with_markers(godot_AnimationPlayer *self, const godot_StringName *start_marker, const godot_StringName *end_marker) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, set_section_with_markers, 794792241, void, self, start_marker, end_marker)
}
void godot_AnimationPlayer_set_section(godot_AnimationPlayer *self, godot_float start_time, godot_float end_time) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, set_section, 3749779719, void, self, &start_time, &end_time)
}
void godot_AnimationPlayer_reset_section(godot_AnimationPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, reset_section, 3218959716, void, self)
}
godot_float godot_AnimationPlayer_get_section_start_time(const godot_AnimationPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationPlayer, get_section_start_time, 1740695150, godot_float, self)
}
godot_float godot_AnimationPlayer_get_section_end_time(const godot_AnimationPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationPlayer, get_section_end_time, 1740695150, godot_float, self)
}
godot_bool godot_AnimationPlayer_has_section(const godot_AnimationPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationPlayer, has_section, 36873697, godot_bool, self)
}
void godot_AnimationPlayer_seek(godot_AnimationPlayer *self, godot_float seconds, godot_bool update, godot_bool update_only) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, seek, 1807872683, void, self, &seconds, &update, &update_only)
}
void godot_AnimationPlayer_set_process_callback(godot_AnimationPlayer *self, godot_AnimationPlayer_AnimationProcessCallback mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, set_process_callback, 1663839457, void, self, &mode)
}
godot_AnimationPlayer_AnimationProcessCallback godot_AnimationPlayer_get_process_callback(const godot_AnimationPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationPlayer, get_process_callback, 4207496604, godot_AnimationPlayer_AnimationProcessCallback, self)
}
void godot_AnimationPlayer_set_method_call_mode(godot_AnimationPlayer *self, godot_AnimationPlayer_AnimationMethodCallMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, set_method_call_mode, 3413514846, void, self, &mode)
}
godot_AnimationPlayer_AnimationMethodCallMode godot_AnimationPlayer_get_method_call_mode(const godot_AnimationPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationPlayer, get_method_call_mode, 3583380054, godot_AnimationPlayer_AnimationMethodCallMode, self)
}
void godot_AnimationPlayer_set_root(godot_AnimationPlayer *self, const godot_NodePath *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationPlayer, set_root, 1348162250, void, self, path)
}
godot_NodePath godot_AnimationPlayer_get_root(const godot_AnimationPlayer *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationPlayer, get_root, 4075236667, godot_NodePath, self)
}


#ifdef __cplusplus
}
#endif
