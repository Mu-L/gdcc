// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COMPOSITOR_EFFECT_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COMPOSITOR_EFFECT_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CompositorEffect *godot_new_CompositorEffect();

// Methods
GDEXTENSION_LITE_DECL void godot_CompositorEffect__render_callback(godot_CompositorEffect *self, godot_int effect_callback_type, const godot_RenderData *render_data);
GDEXTENSION_LITE_DECL void godot_CompositorEffect_set_enabled(godot_CompositorEffect *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_CompositorEffect_get_enabled(const godot_CompositorEffect *self);
GDEXTENSION_LITE_DECL void godot_CompositorEffect_set_effect_callback_type(godot_CompositorEffect *self, godot_CompositorEffect_EffectCallbackType effect_callback_type);
GDEXTENSION_LITE_DECL godot_CompositorEffect_EffectCallbackType godot_CompositorEffect_get_effect_callback_type(const godot_CompositorEffect *self);
GDEXTENSION_LITE_DECL void godot_CompositorEffect_set_access_resolved_color(godot_CompositorEffect *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CompositorEffect_get_access_resolved_color(const godot_CompositorEffect *self);
GDEXTENSION_LITE_DECL void godot_CompositorEffect_set_access_resolved_depth(godot_CompositorEffect *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CompositorEffect_get_access_resolved_depth(const godot_CompositorEffect *self);
GDEXTENSION_LITE_DECL void godot_CompositorEffect_set_needs_motion_vectors(godot_CompositorEffect *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CompositorEffect_get_needs_motion_vectors(const godot_CompositorEffect *self);
GDEXTENSION_LITE_DECL void godot_CompositorEffect_set_needs_normal_roughness(godot_CompositorEffect *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CompositorEffect_get_needs_normal_roughness(const godot_CompositorEffect *self);
GDEXTENSION_LITE_DECL void godot_CompositorEffect_set_needs_separate_specular(godot_CompositorEffect *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CompositorEffect_get_needs_separate_specular(const godot_CompositorEffect *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COMPOSITOR_EFFECT_H__
