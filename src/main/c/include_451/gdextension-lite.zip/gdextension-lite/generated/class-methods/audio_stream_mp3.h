// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_MP3_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_MP3_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioStreamMP3 *godot_new_AudioStreamMP3();

// Methods
GDEXTENSION_LITE_DECL godot_AudioStreamMP3 * godot_AudioStreamMP3_load_from_buffer(const godot_PackedByteArray *stream_data);
GDEXTENSION_LITE_DECL godot_AudioStreamMP3 * godot_AudioStreamMP3_load_from_file(const godot_String *path);
GDEXTENSION_LITE_DECL void godot_AudioStreamMP3_set_data(godot_AudioStreamMP3 *self, const godot_PackedByteArray *data);
GDEXTENSION_LITE_DECL godot_PackedByteArray godot_AudioStreamMP3_get_data(const godot_AudioStreamMP3 *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamMP3_set_loop(godot_AudioStreamMP3 *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_AudioStreamMP3_has_loop(const godot_AudioStreamMP3 *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamMP3_set_loop_offset(godot_AudioStreamMP3 *self, godot_float seconds);
GDEXTENSION_LITE_DECL godot_float godot_AudioStreamMP3_get_loop_offset(const godot_AudioStreamMP3 *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamMP3_set_bpm(godot_AudioStreamMP3 *self, godot_float bpm);
GDEXTENSION_LITE_DECL godot_float godot_AudioStreamMP3_get_bpm(const godot_AudioStreamMP3 *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamMP3_set_beat_count(godot_AudioStreamMP3 *self, godot_int count);
GDEXTENSION_LITE_DECL godot_int godot_AudioStreamMP3_get_beat_count(const godot_AudioStreamMP3 *self);
GDEXTENSION_LITE_DECL void godot_AudioStreamMP3_set_bar_beats(godot_AudioStreamMP3 *self, godot_int count);
GDEXTENSION_LITE_DECL godot_int godot_AudioStreamMP3_get_bar_beats(const godot_AudioStreamMP3 *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_STREAM_MP3_H__
