// This file was automatically generated
// Do not modify this file
#include "audio_stream_synchronized.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioStreamSynchronized *godot_new_AudioStreamSynchronized() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioStreamSynchronized);
}

// Methods
void godot_AudioStreamSynchronized_set_stream_count(godot_AudioStreamSynchronized *self, godot_int stream_count) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamSynchronized, set_stream_count, 1286410249, void, self, &stream_count)
}
godot_int godot_AudioStreamSynchronized_get_stream_count(const godot_AudioStreamSynchronized *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamSynchronized, get_stream_count, 3905245786, godot_int, self)
}
void godot_AudioStreamSynchronized_set_sync_stream(godot_AudioStreamSynchronized *self, godot_int stream_index, const godot_AudioStream *audio_stream) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamSynchronized, set_sync_stream, 111075094, void, self, &stream_index, audio_stream)
}
godot_AudioStream * godot_AudioStreamSynchronized_get_sync_stream(const godot_AudioStreamSynchronized *self, godot_int stream_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamSynchronized, get_sync_stream, 2739380747, godot_AudioStream *, self, &stream_index)
}
void godot_AudioStreamSynchronized_set_sync_stream_volume(godot_AudioStreamSynchronized *self, godot_int stream_index, godot_float volume_db) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamSynchronized, set_sync_stream_volume, 1602489585, void, self, &stream_index, &volume_db)
}
godot_float godot_AudioStreamSynchronized_get_sync_stream_volume(const godot_AudioStreamSynchronized *self, godot_int stream_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamSynchronized, get_sync_stream_volume, 2339986948, godot_float, self, &stream_index)
}


#ifdef __cplusplus
}
#endif
