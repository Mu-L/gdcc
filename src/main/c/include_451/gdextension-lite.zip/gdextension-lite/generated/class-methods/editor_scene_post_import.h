// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_SCENE_POST_IMPORT_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_SCENE_POST_IMPORT_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorScenePostImport *godot_new_EditorScenePostImport();

// Methods
GDEXTENSION_LITE_DECL godot_Object * godot_EditorScenePostImport__post_import(godot_EditorScenePostImport *self, const godot_Node *scene);
GDEXTENSION_LITE_DECL godot_String godot_EditorScenePostImport_get_source_file(const godot_EditorScenePostImport *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_SCENE_POST_IMPORT_H__
