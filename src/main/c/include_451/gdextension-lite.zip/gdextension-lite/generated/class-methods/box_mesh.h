// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BOX_MESH_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BOX_MESH_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_BoxMesh *godot_new_BoxMesh();

// Methods
GDEXTENSION_LITE_DECL void godot_BoxMesh_set_size(godot_BoxMesh *self, const godot_Vector3 *size);
GDEXTENSION_LITE_DECL godot_Vector3 godot_BoxMesh_get_size(const godot_BoxMesh *self);
GDEXTENSION_LITE_DECL void godot_BoxMesh_set_subdivide_width(godot_BoxMesh *self, godot_int subdivide);
GDEXTENSION_LITE_DECL godot_int godot_BoxMesh_get_subdivide_width(const godot_BoxMesh *self);
GDEXTENSION_LITE_DECL void godot_BoxMesh_set_subdivide_height(godot_BoxMesh *self, godot_int divisions);
GDEXTENSION_LITE_DECL godot_int godot_BoxMesh_get_subdivide_height(const godot_BoxMesh *self);
GDEXTENSION_LITE_DECL void godot_BoxMesh_set_subdivide_depth(godot_BoxMesh *self, godot_int divisions);
GDEXTENSION_LITE_DECL godot_int godot_BoxMesh_get_subdivide_depth(const godot_BoxMesh *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_BOX_MESH_H__
