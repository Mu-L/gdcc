// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CURVE2D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CURVE2D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_Curve2D *godot_new_Curve2D();

// Methods
GDEXTENSION_LITE_DECL godot_int godot_Curve2D_get_point_count(const godot_Curve2D *self);
GDEXTENSION_LITE_DECL void godot_Curve2D_set_point_count(godot_Curve2D *self, godot_int count);
GDEXTENSION_LITE_DECL void godot_Curve2D_add_point(godot_Curve2D *self, const godot_Vector2 *position, const godot_Vector2 *in, const godot_Vector2 *out, godot_int index);
GDEXTENSION_LITE_DECL void godot_Curve2D_set_point_position(godot_Curve2D *self, godot_int idx, const godot_Vector2 *position);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Curve2D_get_point_position(const godot_Curve2D *self, godot_int idx);
GDEXTENSION_LITE_DECL void godot_Curve2D_set_point_in(godot_Curve2D *self, godot_int idx, const godot_Vector2 *position);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Curve2D_get_point_in(const godot_Curve2D *self, godot_int idx);
GDEXTENSION_LITE_DECL void godot_Curve2D_set_point_out(godot_Curve2D *self, godot_int idx, const godot_Vector2 *position);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Curve2D_get_point_out(const godot_Curve2D *self, godot_int idx);
GDEXTENSION_LITE_DECL void godot_Curve2D_remove_point(godot_Curve2D *self, godot_int idx);
GDEXTENSION_LITE_DECL void godot_Curve2D_clear_points(godot_Curve2D *self);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Curve2D_sample(const godot_Curve2D *self, godot_int idx, godot_float t);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Curve2D_samplef(const godot_Curve2D *self, godot_float fofs);
GDEXTENSION_LITE_DECL void godot_Curve2D_set_bake_interval(godot_Curve2D *self, godot_float distance);
GDEXTENSION_LITE_DECL godot_float godot_Curve2D_get_bake_interval(const godot_Curve2D *self);
GDEXTENSION_LITE_DECL godot_float godot_Curve2D_get_baked_length(const godot_Curve2D *self);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Curve2D_sample_baked(const godot_Curve2D *self, godot_float offset, godot_bool cubic);
GDEXTENSION_LITE_DECL godot_Transform2D godot_Curve2D_sample_baked_with_rotation(const godot_Curve2D *self, godot_float offset, godot_bool cubic);
GDEXTENSION_LITE_DECL godot_PackedVector2Array godot_Curve2D_get_baked_points(const godot_Curve2D *self);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Curve2D_get_closest_point(const godot_Curve2D *self, const godot_Vector2 *to_point);
GDEXTENSION_LITE_DECL godot_float godot_Curve2D_get_closest_offset(const godot_Curve2D *self, const godot_Vector2 *to_point);
GDEXTENSION_LITE_DECL godot_PackedVector2Array godot_Curve2D_tessellate(const godot_Curve2D *self, godot_int max_stages, godot_float tolerance_degrees);
GDEXTENSION_LITE_DECL godot_PackedVector2Array godot_Curve2D_tessellate_even_length(const godot_Curve2D *self, godot_int max_stages, godot_float tolerance_length);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CURVE2D_H__
