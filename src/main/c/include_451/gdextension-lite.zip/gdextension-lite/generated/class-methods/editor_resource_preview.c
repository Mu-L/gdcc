// This file was automatically generated
// Do not modify this file
#include "editor_resource_preview.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
void godot_EditorResourcePreview_queue_resource_preview(godot_EditorResourcePreview *self, const godot_String *path, const godot_Object *receiver, const godot_StringName *receiver_func, const godot_Variant *userdata) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorResourcePreview, queue_resource_preview, 233177534, void, self, path, receiver, receiver_func, userdata)
}
void godot_EditorResourcePreview_queue_edited_resource_preview(godot_EditorResourcePreview *self, const godot_Resource *resource, const godot_Object *receiver, const godot_StringName *receiver_func, const godot_Variant *userdata) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorResourcePreview, queue_edited_resource_preview, 1608376650, void, self, resource, receiver, receiver_func, userdata)
}
void godot_EditorResourcePreview_add_preview_generator(godot_EditorResourcePreview *self, const godot_EditorResourcePreviewGenerator *generator) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorResourcePreview, add_preview_generator, 332288124, void, self, generator)
}
void godot_EditorResourcePreview_remove_preview_generator(godot_EditorResourcePreview *self, const godot_EditorResourcePreviewGenerator *generator) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorResourcePreview, remove_preview_generator, 332288124, void, self, generator)
}
void godot_EditorResourcePreview_check_for_invalidation(godot_EditorResourcePreview *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorResourcePreview, check_for_invalidation, 83702148, void, self, path)
}


#ifdef __cplusplus
}
#endif
