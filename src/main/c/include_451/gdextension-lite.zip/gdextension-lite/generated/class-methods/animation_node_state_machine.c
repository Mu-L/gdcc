// This file was automatically generated
// Do not modify this file
#include "animation_node_state_machine.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimationNodeStateMachine *godot_new_AnimationNodeStateMachine() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimationNodeStateMachine);
}

// Methods
void godot_AnimationNodeStateMachine_add_node(godot_AnimationNodeStateMachine *self, const godot_StringName *name, const godot_AnimationNode *node, const godot_Vector2 *position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachine, add_node, 1980270704, void, self, name, node, position)
}
void godot_AnimationNodeStateMachine_replace_node(godot_AnimationNodeStateMachine *self, const godot_StringName *name, const godot_AnimationNode *node) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachine, replace_node, 2559412862, void, self, name, node)
}
godot_AnimationNode * godot_AnimationNodeStateMachine_get_node(const godot_AnimationNodeStateMachine *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachine, get_node, 625644256, godot_AnimationNode *, self, name)
}
void godot_AnimationNodeStateMachine_remove_node(godot_AnimationNodeStateMachine *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachine, remove_node, 3304788590, void, self, name)
}
void godot_AnimationNodeStateMachine_rename_node(godot_AnimationNodeStateMachine *self, const godot_StringName *name, const godot_StringName *new_name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachine, rename_node, 3740211285, void, self, name, new_name)
}
godot_bool godot_AnimationNodeStateMachine_has_node(const godot_AnimationNodeStateMachine *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachine, has_node, 2619796661, godot_bool, self, name)
}
godot_StringName godot_AnimationNodeStateMachine_get_node_name(const godot_AnimationNodeStateMachine *self, const godot_AnimationNode *node) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachine, get_node_name, 739213945, godot_StringName, self, node)
}
godot_TypedArray(godot_StringName) godot_AnimationNodeStateMachine_get_node_list(const godot_AnimationNodeStateMachine *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachine, get_node_list, 3995934104, godot_TypedArray(godot_StringName), self)
}
void godot_AnimationNodeStateMachine_set_node_position(godot_AnimationNodeStateMachine *self, const godot_StringName *name, const godot_Vector2 *position) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachine, set_node_position, 1999414630, void, self, name, position)
}
godot_Vector2 godot_AnimationNodeStateMachine_get_node_position(const godot_AnimationNodeStateMachine *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachine, get_node_position, 3100822709, godot_Vector2, self, name)
}
godot_bool godot_AnimationNodeStateMachine_has_transition(const godot_AnimationNodeStateMachine *self, const godot_StringName *from, const godot_StringName *to) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachine, has_transition, 471820014, godot_bool, self, from, to)
}
void godot_AnimationNodeStateMachine_add_transition(godot_AnimationNodeStateMachine *self, const godot_StringName *from, const godot_StringName *to, const godot_AnimationNodeStateMachineTransition *transition) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachine, add_transition, 795486887, void, self, from, to, transition)
}
godot_AnimationNodeStateMachineTransition * godot_AnimationNodeStateMachine_get_transition(const godot_AnimationNodeStateMachine *self, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachine, get_transition, 4192381260, godot_AnimationNodeStateMachineTransition *, self, &idx)
}
godot_StringName godot_AnimationNodeStateMachine_get_transition_from(const godot_AnimationNodeStateMachine *self, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachine, get_transition_from, 659327637, godot_StringName, self, &idx)
}
godot_StringName godot_AnimationNodeStateMachine_get_transition_to(const godot_AnimationNodeStateMachine *self, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachine, get_transition_to, 659327637, godot_StringName, self, &idx)
}
godot_int godot_AnimationNodeStateMachine_get_transition_count(const godot_AnimationNodeStateMachine *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachine, get_transition_count, 3905245786, godot_int, self)
}
void godot_AnimationNodeStateMachine_remove_transition_by_index(godot_AnimationNodeStateMachine *self, godot_int idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachine, remove_transition_by_index, 1286410249, void, self, &idx)
}
void godot_AnimationNodeStateMachine_remove_transition(godot_AnimationNodeStateMachine *self, const godot_StringName *from, const godot_StringName *to) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachine, remove_transition, 3740211285, void, self, from, to)
}
void godot_AnimationNodeStateMachine_set_graph_offset(godot_AnimationNodeStateMachine *self, const godot_Vector2 *offset) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachine, set_graph_offset, 743155724, void, self, offset)
}
godot_Vector2 godot_AnimationNodeStateMachine_get_graph_offset(const godot_AnimationNodeStateMachine *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachine, get_graph_offset, 3341600327, godot_Vector2, self)
}
void godot_AnimationNodeStateMachine_set_state_machine_type(godot_AnimationNodeStateMachine *self, godot_AnimationNodeStateMachine_StateMachineType state_machine_type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachine, set_state_machine_type, 2584759088, void, self, &state_machine_type)
}
godot_AnimationNodeStateMachine_StateMachineType godot_AnimationNodeStateMachine_get_state_machine_type(const godot_AnimationNodeStateMachine *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachine, get_state_machine_type, 1140726469, godot_AnimationNodeStateMachine_StateMachineType, self)
}
void godot_AnimationNodeStateMachine_set_allow_transition_to_self(godot_AnimationNodeStateMachine *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachine, set_allow_transition_to_self, 2586408642, void, self, &enable)
}
godot_bool godot_AnimationNodeStateMachine_is_allow_transition_to_self(const godot_AnimationNodeStateMachine *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachine, is_allow_transition_to_self, 36873697, godot_bool, self)
}
void godot_AnimationNodeStateMachine_set_reset_ends(godot_AnimationNodeStateMachine *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeStateMachine, set_reset_ends, 2586408642, void, self, &enable)
}
godot_bool godot_AnimationNodeStateMachine_are_ends_reset(const godot_AnimationNodeStateMachine *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeStateMachine, are_ends_reset, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
