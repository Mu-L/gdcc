// This file was automatically generated
// Do not modify this file
#include "editor_scene_format_importer.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorSceneFormatImporter *godot_new_EditorSceneFormatImporter() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorSceneFormatImporter);
}

// Methods
godot_PackedStringArray godot_EditorSceneFormatImporter__get_extensions(const godot_EditorSceneFormatImporter *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorSceneFormatImporter, _get_extensions, 1139954409, godot_PackedStringArray, self)
}
godot_Object * godot_EditorSceneFormatImporter__import_scene(godot_EditorSceneFormatImporter *self, const godot_String *path, godot_int flags, const godot_Dictionary *options) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorSceneFormatImporter, _import_scene, 3749238728, godot_Object *, self, path, &flags, options)
}
void godot_EditorSceneFormatImporter__get_import_options(godot_EditorSceneFormatImporter *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorSceneFormatImporter, _get_import_options, 83702148, void, self, path)
}
godot_Variant godot_EditorSceneFormatImporter__get_option_visibility(const godot_EditorSceneFormatImporter *self, const godot_String *path, godot_bool for_animation, const godot_String *option) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorSceneFormatImporter, _get_option_visibility, 298836892, godot_Variant, self, path, &for_animation, option)
}
void godot_EditorSceneFormatImporter_add_import_option(godot_EditorSceneFormatImporter *self, const godot_String *name, const godot_Variant *value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorSceneFormatImporter, add_import_option, 402577236, void, self, name, value)
}
void godot_EditorSceneFormatImporter_add_import_option_advanced(godot_EditorSceneFormatImporter *self, godot_Variant_Type type, const godot_String *name, const godot_Variant *default_value, godot_PropertyHint hint, const godot_String *hint_string, godot_int usage_flags) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorSceneFormatImporter, add_import_option_advanced, 3674075649, void, self, &type, name, default_value, &hint, hint_string, &usage_flags)
}


#ifdef __cplusplus
}
#endif
