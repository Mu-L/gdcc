// This file was automatically generated
// Do not modify this file
#include "audio_effect_eq.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectEQ *godot_new_AudioEffectEQ() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectEQ);
}

// Methods
void godot_AudioEffectEQ_set_band_gain_db(godot_AudioEffectEQ *self, godot_int band_idx, godot_float volume_db) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioEffectEQ, set_band_gain_db, 1602489585, void, self, &band_idx, &volume_db)
}
godot_float godot_AudioEffectEQ_get_band_gain_db(const godot_AudioEffectEQ *self, godot_int band_idx) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectEQ, get_band_gain_db, 2339986948, godot_float, self, &band_idx)
}
godot_int godot_AudioEffectEQ_get_band_count(const godot_AudioEffectEQ *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioEffectEQ, get_band_count, 3905245786, godot_int, self)
}


#ifdef __cplusplus
}
#endif
