// This file was automatically generated
// Do not modify this file
#include "audio_stream_playlist.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioStreamPlaylist *godot_new_AudioStreamPlaylist() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioStreamPlaylist);
}

// Methods
void godot_AudioStreamPlaylist_set_stream_count(godot_AudioStreamPlaylist *self, godot_int stream_count) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlaylist, set_stream_count, 1286410249, void, self, &stream_count)
}
godot_int godot_AudioStreamPlaylist_get_stream_count(const godot_AudioStreamPlaylist *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlaylist, get_stream_count, 3905245786, godot_int, self)
}
godot_float godot_AudioStreamPlaylist_get_bpm(const godot_AudioStreamPlaylist *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlaylist, get_bpm, 1740695150, godot_float, self)
}
void godot_AudioStreamPlaylist_set_list_stream(godot_AudioStreamPlaylist *self, godot_int stream_index, const godot_AudioStream *audio_stream) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlaylist, set_list_stream, 111075094, void, self, &stream_index, audio_stream)
}
godot_AudioStream * godot_AudioStreamPlaylist_get_list_stream(const godot_AudioStreamPlaylist *self, godot_int stream_index) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlaylist, get_list_stream, 2739380747, godot_AudioStream *, self, &stream_index)
}
void godot_AudioStreamPlaylist_set_shuffle(godot_AudioStreamPlaylist *self, godot_bool shuffle) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlaylist, set_shuffle, 2586408642, void, self, &shuffle)
}
godot_bool godot_AudioStreamPlaylist_get_shuffle(const godot_AudioStreamPlaylist *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlaylist, get_shuffle, 36873697, godot_bool, self)
}
void godot_AudioStreamPlaylist_set_fade_time(godot_AudioStreamPlaylist *self, godot_float dec) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlaylist, set_fade_time, 373806689, void, self, &dec)
}
godot_float godot_AudioStreamPlaylist_get_fade_time(const godot_AudioStreamPlaylist *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlaylist, get_fade_time, 1740695150, godot_float, self)
}
void godot_AudioStreamPlaylist_set_loop(godot_AudioStreamPlaylist *self, godot_bool loop) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamPlaylist, set_loop, 2586408642, void, self, &loop)
}
godot_bool godot_AudioStreamPlaylist_has_loop(const godot_AudioStreamPlaylist *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamPlaylist, has_loop, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
