// This file was automatically generated
// Do not modify this file
#include "animated_sprite3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimatedSprite3D *godot_new_AnimatedSprite3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimatedSprite3D);
}

// Methods
void godot_AnimatedSprite3D_set_sprite_frames(godot_AnimatedSprite3D *self, const godot_SpriteFrames *sprite_frames) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimatedSprite3D, set_sprite_frames, 905781144, void, self, sprite_frames)
}
godot_SpriteFrames * godot_AnimatedSprite3D_get_sprite_frames(const godot_AnimatedSprite3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimatedSprite3D, get_sprite_frames, 3804851214, godot_SpriteFrames *, self)
}
void godot_AnimatedSprite3D_set_animation(godot_AnimatedSprite3D *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimatedSprite3D, set_animation, 3304788590, void, self, name)
}
godot_StringName godot_AnimatedSprite3D_get_animation(const godot_AnimatedSprite3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimatedSprite3D, get_animation, 2002593661, godot_StringName, self)
}
void godot_AnimatedSprite3D_set_autoplay(godot_AnimatedSprite3D *self, const godot_String *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimatedSprite3D, set_autoplay, 83702148, void, self, name)
}
godot_String godot_AnimatedSprite3D_get_autoplay(const godot_AnimatedSprite3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimatedSprite3D, get_autoplay, 201670096, godot_String, self)
}
godot_bool godot_AnimatedSprite3D_is_playing(const godot_AnimatedSprite3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimatedSprite3D, is_playing, 36873697, godot_bool, self)
}
void godot_AnimatedSprite3D_play(godot_AnimatedSprite3D *self, const godot_StringName *name, godot_float custom_speed, godot_bool from_end) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimatedSprite3D, play, 3269405555, void, self, name, &custom_speed, &from_end)
}
void godot_AnimatedSprite3D_play_backwards(godot_AnimatedSprite3D *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimatedSprite3D, play_backwards, 3323268493, void, self, name)
}
void godot_AnimatedSprite3D_pause(godot_AnimatedSprite3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimatedSprite3D, pause, 3218959716, void, self)
}
void godot_AnimatedSprite3D_stop(godot_AnimatedSprite3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimatedSprite3D, stop, 3218959716, void, self)
}
void godot_AnimatedSprite3D_set_frame(godot_AnimatedSprite3D *self, godot_int frame) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimatedSprite3D, set_frame, 1286410249, void, self, &frame)
}
godot_int godot_AnimatedSprite3D_get_frame(const godot_AnimatedSprite3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimatedSprite3D, get_frame, 3905245786, godot_int, self)
}
void godot_AnimatedSprite3D_set_frame_progress(godot_AnimatedSprite3D *self, godot_float progress) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimatedSprite3D, set_frame_progress, 373806689, void, self, &progress)
}
godot_float godot_AnimatedSprite3D_get_frame_progress(const godot_AnimatedSprite3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimatedSprite3D, get_frame_progress, 1740695150, godot_float, self)
}
void godot_AnimatedSprite3D_set_frame_and_progress(godot_AnimatedSprite3D *self, godot_int frame, godot_float progress) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimatedSprite3D, set_frame_and_progress, 1602489585, void, self, &frame, &progress)
}
void godot_AnimatedSprite3D_set_speed_scale(godot_AnimatedSprite3D *self, godot_float speed_scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimatedSprite3D, set_speed_scale, 373806689, void, self, &speed_scale)
}
godot_float godot_AnimatedSprite3D_get_speed_scale(const godot_AnimatedSprite3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimatedSprite3D, get_speed_scale, 1740695150, godot_float, self)
}
godot_float godot_AnimatedSprite3D_get_playing_speed(const godot_AnimatedSprite3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimatedSprite3D, get_playing_speed, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
