// This file was automatically generated
// Do not modify this file
#include "audio_effect_eq10.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectEQ10 *godot_new_AudioEffectEQ10() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectEQ10);
}


#ifdef __cplusplus
}
#endif
