// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_FILE_SYSTEM_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_FILE_SYSTEM_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
GDEXTENSION_LITE_DECL godot_EditorFileSystemDirectory * godot_EditorFileSystem_get_filesystem(godot_EditorFileSystem *self);
GDEXTENSION_LITE_DECL godot_bool godot_EditorFileSystem_is_scanning(const godot_EditorFileSystem *self);
GDEXTENSION_LITE_DECL godot_float godot_EditorFileSystem_get_scanning_progress(const godot_EditorFileSystem *self);
GDEXTENSION_LITE_DECL void godot_EditorFileSystem_scan(godot_EditorFileSystem *self);
GDEXTENSION_LITE_DECL void godot_EditorFileSystem_scan_sources(godot_EditorFileSystem *self);
GDEXTENSION_LITE_DECL void godot_EditorFileSystem_update_file(godot_EditorFileSystem *self, const godot_String *path);
GDEXTENSION_LITE_DECL godot_EditorFileSystemDirectory * godot_EditorFileSystem_get_filesystem_path(godot_EditorFileSystem *self, const godot_String *path);
GDEXTENSION_LITE_DECL godot_String godot_EditorFileSystem_get_file_type(const godot_EditorFileSystem *self, const godot_String *path);
GDEXTENSION_LITE_DECL void godot_EditorFileSystem_reimport_files(godot_EditorFileSystem *self, const godot_PackedStringArray *files);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_FILE_SYSTEM_H__
