// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AESCONTEXT_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AESCONTEXT_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AESContext *godot_new_AESContext();

// Methods
GDEXTENSION_LITE_DECL godot_Error godot_AESContext_start(godot_AESContext *self, godot_AESContext_Mode mode, const godot_PackedByteArray *key, const godot_PackedByteArray *iv);
GDEXTENSION_LITE_DECL godot_PackedByteArray godot_AESContext_update(godot_AESContext *self, const godot_PackedByteArray *src);
GDEXTENSION_LITE_DECL godot_PackedByteArray godot_AESContext_get_iv_state(godot_AESContext *self);
GDEXTENSION_LITE_DECL void godot_AESContext_finish(godot_AESContext *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AESCONTEXT_H__
