// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CUBEMAP_ARRAY_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CUBEMAP_ARRAY_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CubemapArray *godot_new_CubemapArray();

// Methods
GDEXTENSION_LITE_DECL godot_Resource * godot_CubemapArray_create_placeholder(const godot_CubemapArray *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CUBEMAP_ARRAY_H__
