// This file was automatically generated
// Do not modify this file
#include "callback_tweener.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CallbackTweener *godot_new_CallbackTweener() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CallbackTweener);
}

// Methods
godot_CallbackTweener * godot_CallbackTweener_set_delay(godot_CallbackTweener *self, godot_float delay) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CallbackTweener, set_delay, 3008182292, godot_CallbackTweener *, self, &delay)
}


#ifdef __cplusplus
}
#endif
