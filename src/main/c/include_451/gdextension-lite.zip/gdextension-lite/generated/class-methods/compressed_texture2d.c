// This file was automatically generated
// Do not modify this file
#include "compressed_texture2d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CompressedTexture2D *godot_new_CompressedTexture2D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CompressedTexture2D);
}

// Methods
godot_Error godot_CompressedTexture2D_load(godot_CompressedTexture2D *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CompressedTexture2D, load, 166001499, godot_Error, self, path)
}
godot_String godot_CompressedTexture2D_get_load_path(const godot_CompressedTexture2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CompressedTexture2D, get_load_path, 201670096, godot_String, self)
}


#ifdef __cplusplus
}
#endif
