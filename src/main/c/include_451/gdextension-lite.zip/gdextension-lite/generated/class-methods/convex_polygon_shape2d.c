// This file was automatically generated
// Do not modify this file
#include "convex_polygon_shape2d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_ConvexPolygonShape2D *godot_new_ConvexPolygonShape2D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(ConvexPolygonShape2D);
}

// Methods
void godot_ConvexPolygonShape2D_set_point_cloud(godot_ConvexPolygonShape2D *self, const godot_PackedVector2Array *point_cloud) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ConvexPolygonShape2D, set_point_cloud, 1509147220, void, self, point_cloud)
}
void godot_ConvexPolygonShape2D_set_points(godot_ConvexPolygonShape2D *self, const godot_PackedVector2Array *points) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ConvexPolygonShape2D, set_points, 1509147220, void, self, points)
}
godot_PackedVector2Array godot_ConvexPolygonShape2D_get_points(const godot_ConvexPolygonShape2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConvexPolygonShape2D, get_points, 2961356807, godot_PackedVector2Array, self)
}


#ifdef __cplusplus
}
#endif
