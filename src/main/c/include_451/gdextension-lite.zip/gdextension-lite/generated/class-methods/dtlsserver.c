// This file was automatically generated
// Do not modify this file
#include "dtlsserver.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_DTLSServer *godot_new_DTLSServer() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(DTLSServer);
}

// Methods
godot_Error godot_DTLSServer_setup(godot_DTLSServer *self, const godot_TLSOptions *server_options) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DTLSServer, setup, 1262296096, godot_Error, self, server_options)
}
godot_PacketPeerDTLS * godot_DTLSServer_take_connection(godot_DTLSServer *self, const godot_PacketPeerUDP *udp_peer) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(DTLSServer, take_connection, 3946580474, godot_PacketPeerDTLS *, self, udp_peer)
}


#ifdef __cplusplus
}
#endif
