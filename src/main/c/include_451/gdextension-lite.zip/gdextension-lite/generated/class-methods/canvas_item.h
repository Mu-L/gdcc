// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CANVAS_ITEM_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CANVAS_ITEM_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Methods
GDEXTENSION_LITE_DECL void godot_CanvasItem__draw(godot_CanvasItem *self);
GDEXTENSION_LITE_DECL godot_RID godot_CanvasItem_get_canvas_item(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL void godot_CanvasItem_set_visible(godot_CanvasItem *self, godot_bool visible);
GDEXTENSION_LITE_DECL godot_bool godot_CanvasItem_is_visible(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL godot_bool godot_CanvasItem_is_visible_in_tree(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL void godot_CanvasItem_show(godot_CanvasItem *self);
GDEXTENSION_LITE_DECL void godot_CanvasItem_hide(godot_CanvasItem *self);
GDEXTENSION_LITE_DECL void godot_CanvasItem_queue_redraw(godot_CanvasItem *self);
GDEXTENSION_LITE_DECL void godot_CanvasItem_move_to_front(godot_CanvasItem *self);
GDEXTENSION_LITE_DECL void godot_CanvasItem_set_as_top_level(godot_CanvasItem *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CanvasItem_is_set_as_top_level(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL void godot_CanvasItem_set_light_mask(godot_CanvasItem *self, godot_int light_mask);
GDEXTENSION_LITE_DECL godot_int godot_CanvasItem_get_light_mask(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL void godot_CanvasItem_set_modulate(godot_CanvasItem *self, const godot_Color *modulate);
GDEXTENSION_LITE_DECL godot_Color godot_CanvasItem_get_modulate(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL void godot_CanvasItem_set_self_modulate(godot_CanvasItem *self, const godot_Color *self_modulate);
GDEXTENSION_LITE_DECL godot_Color godot_CanvasItem_get_self_modulate(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL void godot_CanvasItem_set_z_index(godot_CanvasItem *self, godot_int z_index);
GDEXTENSION_LITE_DECL godot_int godot_CanvasItem_get_z_index(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL void godot_CanvasItem_set_z_as_relative(godot_CanvasItem *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CanvasItem_is_z_relative(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL void godot_CanvasItem_set_y_sort_enabled(godot_CanvasItem *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_CanvasItem_is_y_sort_enabled(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL void godot_CanvasItem_set_draw_behind_parent(godot_CanvasItem *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CanvasItem_is_draw_behind_parent_enabled(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_line(godot_CanvasItem *self, const godot_Vector2 *from, const godot_Vector2 *to, const godot_Color *color, godot_float width, godot_bool antialiased);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_dashed_line(godot_CanvasItem *self, const godot_Vector2 *from, const godot_Vector2 *to, const godot_Color *color, godot_float width, godot_float dash, godot_bool aligned, godot_bool antialiased);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_polyline(godot_CanvasItem *self, const godot_PackedVector2Array *points, const godot_Color *color, godot_float width, godot_bool antialiased);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_polyline_colors(godot_CanvasItem *self, const godot_PackedVector2Array *points, const godot_PackedColorArray *colors, godot_float width, godot_bool antialiased);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_arc(godot_CanvasItem *self, const godot_Vector2 *center, godot_float radius, godot_float start_angle, godot_float end_angle, godot_int point_count, const godot_Color *color, godot_float width, godot_bool antialiased);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_multiline(godot_CanvasItem *self, const godot_PackedVector2Array *points, const godot_Color *color, godot_float width, godot_bool antialiased);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_multiline_colors(godot_CanvasItem *self, const godot_PackedVector2Array *points, const godot_PackedColorArray *colors, godot_float width, godot_bool antialiased);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_rect(godot_CanvasItem *self, const godot_Rect2 *rect, const godot_Color *color, godot_bool filled, godot_float width, godot_bool antialiased);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_circle(godot_CanvasItem *self, const godot_Vector2 *position, godot_float radius, const godot_Color *color, godot_bool filled, godot_float width, godot_bool antialiased);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_texture(godot_CanvasItem *self, const godot_Texture2D *texture, const godot_Vector2 *position, const godot_Color *modulate);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_texture_rect(godot_CanvasItem *self, const godot_Texture2D *texture, const godot_Rect2 *rect, godot_bool tile, const godot_Color *modulate, godot_bool transpose);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_texture_rect_region(godot_CanvasItem *self, const godot_Texture2D *texture, const godot_Rect2 *rect, const godot_Rect2 *src_rect, const godot_Color *modulate, godot_bool transpose, godot_bool clip_uv);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_msdf_texture_rect_region(godot_CanvasItem *self, const godot_Texture2D *texture, const godot_Rect2 *rect, const godot_Rect2 *src_rect, const godot_Color *modulate, godot_float outline, godot_float pixel_range, godot_float scale);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_lcd_texture_rect_region(godot_CanvasItem *self, const godot_Texture2D *texture, const godot_Rect2 *rect, const godot_Rect2 *src_rect, const godot_Color *modulate);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_style_box(godot_CanvasItem *self, const godot_StyleBox *style_box, const godot_Rect2 *rect);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_primitive(godot_CanvasItem *self, const godot_PackedVector2Array *points, const godot_PackedColorArray *colors, const godot_PackedVector2Array *uvs, const godot_Texture2D *texture);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_polygon(godot_CanvasItem *self, const godot_PackedVector2Array *points, const godot_PackedColorArray *colors, const godot_PackedVector2Array *uvs, const godot_Texture2D *texture);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_colored_polygon(godot_CanvasItem *self, const godot_PackedVector2Array *points, const godot_Color *color, const godot_PackedVector2Array *uvs, const godot_Texture2D *texture);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_string(const godot_CanvasItem *self, const godot_Font *font, const godot_Vector2 *pos, const godot_String *text, godot_HorizontalAlignment alignment, godot_float width, godot_int font_size, const godot_Color *modulate, const godot_TextServer_JustificationFlag *justification_flags, godot_TextServer_Direction direction, godot_TextServer_Orientation orientation, godot_float oversampling);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_multiline_string(const godot_CanvasItem *self, const godot_Font *font, const godot_Vector2 *pos, const godot_String *text, godot_HorizontalAlignment alignment, godot_float width, godot_int font_size, godot_int max_lines, const godot_Color *modulate, const godot_TextServer_LineBreakFlag *brk_flags, const godot_TextServer_JustificationFlag *justification_flags, godot_TextServer_Direction direction, godot_TextServer_Orientation orientation, godot_float oversampling);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_string_outline(const godot_CanvasItem *self, const godot_Font *font, const godot_Vector2 *pos, const godot_String *text, godot_HorizontalAlignment alignment, godot_float width, godot_int font_size, godot_int size, const godot_Color *modulate, const godot_TextServer_JustificationFlag *justification_flags, godot_TextServer_Direction direction, godot_TextServer_Orientation orientation, godot_float oversampling);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_multiline_string_outline(const godot_CanvasItem *self, const godot_Font *font, const godot_Vector2 *pos, const godot_String *text, godot_HorizontalAlignment alignment, godot_float width, godot_int font_size, godot_int max_lines, godot_int size, const godot_Color *modulate, const godot_TextServer_LineBreakFlag *brk_flags, const godot_TextServer_JustificationFlag *justification_flags, godot_TextServer_Direction direction, godot_TextServer_Orientation orientation, godot_float oversampling);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_char(const godot_CanvasItem *self, const godot_Font *font, const godot_Vector2 *pos, const godot_String *chr, godot_int font_size, const godot_Color *modulate, godot_float oversampling);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_char_outline(const godot_CanvasItem *self, const godot_Font *font, const godot_Vector2 *pos, const godot_String *chr, godot_int font_size, godot_int size, const godot_Color *modulate, godot_float oversampling);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_mesh(godot_CanvasItem *self, const godot_Mesh *mesh, const godot_Texture2D *texture, const godot_Transform2D *transform, const godot_Color *modulate);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_multimesh(godot_CanvasItem *self, const godot_MultiMesh *multimesh, const godot_Texture2D *texture);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_set_transform(godot_CanvasItem *self, const godot_Vector2 *position, godot_float rotation, const godot_Vector2 *scale);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_set_transform_matrix(godot_CanvasItem *self, const godot_Transform2D *xform);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_animation_slice(godot_CanvasItem *self, godot_float animation_length, godot_float slice_begin, godot_float slice_end, godot_float offset);
GDEXTENSION_LITE_DECL void godot_CanvasItem_draw_end_animation(godot_CanvasItem *self);
GDEXTENSION_LITE_DECL godot_Transform2D godot_CanvasItem_get_transform(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL godot_Transform2D godot_CanvasItem_get_global_transform(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL godot_Transform2D godot_CanvasItem_get_global_transform_with_canvas(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL godot_Transform2D godot_CanvasItem_get_viewport_transform(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL godot_Rect2 godot_CanvasItem_get_viewport_rect(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL godot_Transform2D godot_CanvasItem_get_canvas_transform(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL godot_Transform2D godot_CanvasItem_get_screen_transform(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL godot_Vector2 godot_CanvasItem_get_local_mouse_position(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL godot_Vector2 godot_CanvasItem_get_global_mouse_position(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL godot_RID godot_CanvasItem_get_canvas(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL godot_CanvasLayer * godot_CanvasItem_get_canvas_layer_node(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL godot_World2D * godot_CanvasItem_get_world_2d(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL void godot_CanvasItem_set_material(godot_CanvasItem *self, const godot_Material *material);
GDEXTENSION_LITE_DECL godot_Material * godot_CanvasItem_get_material(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL void godot_CanvasItem_set_instance_shader_parameter(godot_CanvasItem *self, const godot_StringName *name, const godot_Variant *value);
GDEXTENSION_LITE_DECL godot_Variant godot_CanvasItem_get_instance_shader_parameter(const godot_CanvasItem *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL void godot_CanvasItem_set_use_parent_material(godot_CanvasItem *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CanvasItem_get_use_parent_material(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL void godot_CanvasItem_set_notify_local_transform(godot_CanvasItem *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CanvasItem_is_local_transform_notification_enabled(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL void godot_CanvasItem_set_notify_transform(godot_CanvasItem *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_CanvasItem_is_transform_notification_enabled(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL void godot_CanvasItem_force_update_transform(godot_CanvasItem *self);
GDEXTENSION_LITE_DECL godot_Vector2 godot_CanvasItem_make_canvas_position_local(const godot_CanvasItem *self, const godot_Vector2 *viewport_point);
GDEXTENSION_LITE_DECL godot_InputEvent * godot_CanvasItem_make_input_local(const godot_CanvasItem *self, const godot_InputEvent *event);
GDEXTENSION_LITE_DECL void godot_CanvasItem_set_visibility_layer(godot_CanvasItem *self, godot_int layer);
GDEXTENSION_LITE_DECL godot_int godot_CanvasItem_get_visibility_layer(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL void godot_CanvasItem_set_visibility_layer_bit(godot_CanvasItem *self, godot_int layer, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_CanvasItem_get_visibility_layer_bit(const godot_CanvasItem *self, godot_int layer);
GDEXTENSION_LITE_DECL void godot_CanvasItem_set_texture_filter(godot_CanvasItem *self, godot_CanvasItem_TextureFilter mode);
GDEXTENSION_LITE_DECL godot_CanvasItem_TextureFilter godot_CanvasItem_get_texture_filter(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL void godot_CanvasItem_set_texture_repeat(godot_CanvasItem *self, godot_CanvasItem_TextureRepeat mode);
GDEXTENSION_LITE_DECL godot_CanvasItem_TextureRepeat godot_CanvasItem_get_texture_repeat(const godot_CanvasItem *self);
GDEXTENSION_LITE_DECL void godot_CanvasItem_set_clip_children_mode(godot_CanvasItem *self, godot_CanvasItem_ClipChildrenMode mode);
GDEXTENSION_LITE_DECL godot_CanvasItem_ClipChildrenMode godot_CanvasItem_get_clip_children_mode(const godot_CanvasItem *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CANVAS_ITEM_H__
