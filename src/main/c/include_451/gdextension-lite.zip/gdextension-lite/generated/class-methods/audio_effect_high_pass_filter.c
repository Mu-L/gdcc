// This file was automatically generated
// Do not modify this file
#include "audio_effect_high_pass_filter.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioEffectHighPassFilter *godot_new_AudioEffectHighPassFilter() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioEffectHighPassFilter);
}


#ifdef __cplusplus
}
#endif
