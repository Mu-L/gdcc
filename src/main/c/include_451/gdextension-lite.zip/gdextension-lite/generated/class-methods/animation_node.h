// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AnimationNode *godot_new_AnimationNode();

// Methods
GDEXTENSION_LITE_DECL godot_Dictionary godot_AnimationNode__get_child_nodes(const godot_AnimationNode *self);
GDEXTENSION_LITE_DECL godot_Array godot_AnimationNode__get_parameter_list(const godot_AnimationNode *self);
GDEXTENSION_LITE_DECL godot_AnimationNode * godot_AnimationNode__get_child_by_name(const godot_AnimationNode *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL godot_Variant godot_AnimationNode__get_parameter_default_value(const godot_AnimationNode *self, const godot_StringName *parameter);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNode__is_parameter_read_only(const godot_AnimationNode *self, const godot_StringName *parameter);
GDEXTENSION_LITE_DECL godot_float godot_AnimationNode__process(godot_AnimationNode *self, godot_float time, godot_bool seek, godot_bool is_external_seeking, godot_bool test_only);
GDEXTENSION_LITE_DECL godot_String godot_AnimationNode__get_caption(const godot_AnimationNode *self);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNode__has_filter(const godot_AnimationNode *self);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNode_add_input(godot_AnimationNode *self, const godot_String *name);
GDEXTENSION_LITE_DECL void godot_AnimationNode_remove_input(godot_AnimationNode *self, godot_int index);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNode_set_input_name(godot_AnimationNode *self, godot_int input, const godot_String *name);
GDEXTENSION_LITE_DECL godot_String godot_AnimationNode_get_input_name(const godot_AnimationNode *self, godot_int input);
GDEXTENSION_LITE_DECL godot_int godot_AnimationNode_get_input_count(const godot_AnimationNode *self);
GDEXTENSION_LITE_DECL godot_int godot_AnimationNode_find_input(const godot_AnimationNode *self, const godot_String *name);
GDEXTENSION_LITE_DECL void godot_AnimationNode_set_filter_path(godot_AnimationNode *self, const godot_NodePath *path, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNode_is_path_filtered(const godot_AnimationNode *self, const godot_NodePath *path);
GDEXTENSION_LITE_DECL void godot_AnimationNode_set_filter_enabled(godot_AnimationNode *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNode_is_filter_enabled(const godot_AnimationNode *self);
GDEXTENSION_LITE_DECL godot_int godot_AnimationNode_get_processing_animation_tree_instance_id(const godot_AnimationNode *self);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNode_is_process_testing(const godot_AnimationNode *self);
GDEXTENSION_LITE_DECL void godot_AnimationNode_blend_animation(godot_AnimationNode *self, const godot_StringName *animation, godot_float time, godot_float delta, godot_bool seeked, godot_bool is_external_seeking, godot_float blend, godot_Animation_LoopedFlag looped_flag);
GDEXTENSION_LITE_DECL godot_float godot_AnimationNode_blend_node(godot_AnimationNode *self, const godot_StringName *name, const godot_AnimationNode *node, godot_float time, godot_bool seek, godot_bool is_external_seeking, godot_float blend, godot_AnimationNode_FilterAction filter, godot_bool sync, godot_bool test_only);
GDEXTENSION_LITE_DECL godot_float godot_AnimationNode_blend_input(godot_AnimationNode *self, godot_int input_index, godot_float time, godot_bool seek, godot_bool is_external_seeking, godot_float blend, godot_AnimationNode_FilterAction filter, godot_bool sync, godot_bool test_only);
GDEXTENSION_LITE_DECL void godot_AnimationNode_set_parameter(godot_AnimationNode *self, const godot_StringName *name, const godot_Variant *value);
GDEXTENSION_LITE_DECL godot_Variant godot_AnimationNode_get_parameter(const godot_AnimationNode *self, const godot_StringName *name);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_H__
