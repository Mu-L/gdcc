// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CANVAS_ITEM_MATERIAL_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CANVAS_ITEM_MATERIAL_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CanvasItemMaterial *godot_new_CanvasItemMaterial();

// Methods
GDEXTENSION_LITE_DECL void godot_CanvasItemMaterial_set_blend_mode(godot_CanvasItemMaterial *self, godot_CanvasItemMaterial_BlendMode blend_mode);
GDEXTENSION_LITE_DECL godot_CanvasItemMaterial_BlendMode godot_CanvasItemMaterial_get_blend_mode(const godot_CanvasItemMaterial *self);
GDEXTENSION_LITE_DECL void godot_CanvasItemMaterial_set_light_mode(godot_CanvasItemMaterial *self, godot_CanvasItemMaterial_LightMode light_mode);
GDEXTENSION_LITE_DECL godot_CanvasItemMaterial_LightMode godot_CanvasItemMaterial_get_light_mode(const godot_CanvasItemMaterial *self);
GDEXTENSION_LITE_DECL void godot_CanvasItemMaterial_set_particles_animation(godot_CanvasItemMaterial *self, godot_bool particles_anim);
GDEXTENSION_LITE_DECL godot_bool godot_CanvasItemMaterial_get_particles_animation(const godot_CanvasItemMaterial *self);
GDEXTENSION_LITE_DECL void godot_CanvasItemMaterial_set_particles_anim_h_frames(godot_CanvasItemMaterial *self, godot_int frames);
GDEXTENSION_LITE_DECL godot_int godot_CanvasItemMaterial_get_particles_anim_h_frames(const godot_CanvasItemMaterial *self);
GDEXTENSION_LITE_DECL void godot_CanvasItemMaterial_set_particles_anim_v_frames(godot_CanvasItemMaterial *self, godot_int frames);
GDEXTENSION_LITE_DECL godot_int godot_CanvasItemMaterial_get_particles_anim_v_frames(const godot_CanvasItemMaterial *self);
GDEXTENSION_LITE_DECL void godot_CanvasItemMaterial_set_particles_anim_loop(godot_CanvasItemMaterial *self, godot_bool loop);
GDEXTENSION_LITE_DECL godot_bool godot_CanvasItemMaterial_get_particles_anim_loop(const godot_CanvasItemMaterial *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CANVAS_ITEM_MATERIAL_H__
