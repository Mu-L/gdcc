// This file was automatically generated
// Do not modify this file
#include "animation_node_one_shot.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimationNodeOneShot *godot_new_AnimationNodeOneShot() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimationNodeOneShot);
}

// Methods
void godot_AnimationNodeOneShot_set_fadein_time(godot_AnimationNodeOneShot *self, godot_float time) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeOneShot, set_fadein_time, 373806689, void, self, &time)
}
godot_float godot_AnimationNodeOneShot_get_fadein_time(const godot_AnimationNodeOneShot *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeOneShot, get_fadein_time, 1740695150, godot_float, self)
}
void godot_AnimationNodeOneShot_set_fadein_curve(godot_AnimationNodeOneShot *self, const godot_Curve *curve) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeOneShot, set_fadein_curve, 270443179, void, self, curve)
}
godot_Curve * godot_AnimationNodeOneShot_get_fadein_curve(const godot_AnimationNodeOneShot *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeOneShot, get_fadein_curve, 2460114913, godot_Curve *, self)
}
void godot_AnimationNodeOneShot_set_fadeout_time(godot_AnimationNodeOneShot *self, godot_float time) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeOneShot, set_fadeout_time, 373806689, void, self, &time)
}
godot_float godot_AnimationNodeOneShot_get_fadeout_time(const godot_AnimationNodeOneShot *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeOneShot, get_fadeout_time, 1740695150, godot_float, self)
}
void godot_AnimationNodeOneShot_set_fadeout_curve(godot_AnimationNodeOneShot *self, const godot_Curve *curve) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeOneShot, set_fadeout_curve, 270443179, void, self, curve)
}
godot_Curve * godot_AnimationNodeOneShot_get_fadeout_curve(const godot_AnimationNodeOneShot *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeOneShot, get_fadeout_curve, 2460114913, godot_Curve *, self)
}
void godot_AnimationNodeOneShot_set_break_loop_at_end(godot_AnimationNodeOneShot *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeOneShot, set_break_loop_at_end, 2586408642, void, self, &enable)
}
godot_bool godot_AnimationNodeOneShot_is_loop_broken_at_end(const godot_AnimationNodeOneShot *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeOneShot, is_loop_broken_at_end, 36873697, godot_bool, self)
}
void godot_AnimationNodeOneShot_set_autorestart(godot_AnimationNodeOneShot *self, godot_bool active) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeOneShot, set_autorestart, 2586408642, void, self, &active)
}
godot_bool godot_AnimationNodeOneShot_has_autorestart(const godot_AnimationNodeOneShot *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeOneShot, has_autorestart, 36873697, godot_bool, self)
}
void godot_AnimationNodeOneShot_set_autorestart_delay(godot_AnimationNodeOneShot *self, godot_float time) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeOneShot, set_autorestart_delay, 373806689, void, self, &time)
}
godot_float godot_AnimationNodeOneShot_get_autorestart_delay(const godot_AnimationNodeOneShot *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeOneShot, get_autorestart_delay, 1740695150, godot_float, self)
}
void godot_AnimationNodeOneShot_set_autorestart_random_delay(godot_AnimationNodeOneShot *self, godot_float time) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeOneShot, set_autorestart_random_delay, 373806689, void, self, &time)
}
godot_float godot_AnimationNodeOneShot_get_autorestart_random_delay(const godot_AnimationNodeOneShot *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeOneShot, get_autorestart_random_delay, 1740695150, godot_float, self)
}
void godot_AnimationNodeOneShot_set_mix_mode(godot_AnimationNodeOneShot *self, godot_AnimationNodeOneShot_MixMode mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AnimationNodeOneShot, set_mix_mode, 1018899799, void, self, &mode)
}
godot_AnimationNodeOneShot_MixMode godot_AnimationNodeOneShot_get_mix_mode(const godot_AnimationNodeOneShot *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AnimationNodeOneShot, get_mix_mode, 3076550526, godot_AnimationNodeOneShot_MixMode, self)
}


#ifdef __cplusplus
}
#endif
