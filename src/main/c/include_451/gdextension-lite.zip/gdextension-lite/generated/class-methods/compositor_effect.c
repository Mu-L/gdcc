// This file was automatically generated
// Do not modify this file
#include "compositor_effect.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CompositorEffect *godot_new_CompositorEffect() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CompositorEffect);
}

// Methods
void godot_CompositorEffect__render_callback(godot_CompositorEffect *self, godot_int effect_callback_type, const godot_RenderData *render_data) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CompositorEffect, _render_callback, 2153422729, void, self, &effect_callback_type, render_data)
}
void godot_CompositorEffect_set_enabled(godot_CompositorEffect *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CompositorEffect, set_enabled, 2586408642, void, self, &enabled)
}
godot_bool godot_CompositorEffect_get_enabled(const godot_CompositorEffect *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CompositorEffect, get_enabled, 36873697, godot_bool, self)
}
void godot_CompositorEffect_set_effect_callback_type(godot_CompositorEffect *self, godot_CompositorEffect_EffectCallbackType effect_callback_type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CompositorEffect, set_effect_callback_type, 1390728419, void, self, &effect_callback_type)
}
godot_CompositorEffect_EffectCallbackType godot_CompositorEffect_get_effect_callback_type(const godot_CompositorEffect *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CompositorEffect, get_effect_callback_type, 1221912590, godot_CompositorEffect_EffectCallbackType, self)
}
void godot_CompositorEffect_set_access_resolved_color(godot_CompositorEffect *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CompositorEffect, set_access_resolved_color, 2586408642, void, self, &enable)
}
godot_bool godot_CompositorEffect_get_access_resolved_color(const godot_CompositorEffect *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CompositorEffect, get_access_resolved_color, 36873697, godot_bool, self)
}
void godot_CompositorEffect_set_access_resolved_depth(godot_CompositorEffect *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CompositorEffect, set_access_resolved_depth, 2586408642, void, self, &enable)
}
godot_bool godot_CompositorEffect_get_access_resolved_depth(const godot_CompositorEffect *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CompositorEffect, get_access_resolved_depth, 36873697, godot_bool, self)
}
void godot_CompositorEffect_set_needs_motion_vectors(godot_CompositorEffect *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CompositorEffect, set_needs_motion_vectors, 2586408642, void, self, &enable)
}
godot_bool godot_CompositorEffect_get_needs_motion_vectors(const godot_CompositorEffect *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CompositorEffect, get_needs_motion_vectors, 36873697, godot_bool, self)
}
void godot_CompositorEffect_set_needs_normal_roughness(godot_CompositorEffect *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CompositorEffect, set_needs_normal_roughness, 2586408642, void, self, &enable)
}
godot_bool godot_CompositorEffect_get_needs_normal_roughness(const godot_CompositorEffect *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CompositorEffect, get_needs_normal_roughness, 36873697, godot_bool, self)
}
void godot_CompositorEffect_set_needs_separate_specular(godot_CompositorEffect *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CompositorEffect, set_needs_separate_specular, 2586408642, void, self, &enable)
}
godot_bool godot_CompositorEffect_get_needs_separate_specular(const godot_CompositorEffect *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CompositorEffect, get_needs_separate_specular, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
