// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONCAVE_POLYGON_SHAPE3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONCAVE_POLYGON_SHAPE3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_ConcavePolygonShape3D *godot_new_ConcavePolygonShape3D();

// Methods
GDEXTENSION_LITE_DECL void godot_ConcavePolygonShape3D_set_faces(godot_ConcavePolygonShape3D *self, const godot_PackedVector3Array *faces);
GDEXTENSION_LITE_DECL godot_PackedVector3Array godot_ConcavePolygonShape3D_get_faces(const godot_ConcavePolygonShape3D *self);
GDEXTENSION_LITE_DECL void godot_ConcavePolygonShape3D_set_backface_collision_enabled(godot_ConcavePolygonShape3D *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_ConcavePolygonShape3D_is_backface_collision_enabled(const godot_ConcavePolygonShape3D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONCAVE_POLYGON_SHAPE3D_H__
