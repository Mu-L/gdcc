// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CRYPTO_KEY_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CRYPTO_KEY_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CryptoKey *godot_new_CryptoKey();

// Methods
GDEXTENSION_LITE_DECL godot_Error godot_CryptoKey_save(godot_CryptoKey *self, const godot_String *path, godot_bool public_only);
GDEXTENSION_LITE_DECL godot_Error godot_CryptoKey_load(godot_CryptoKey *self, const godot_String *path, godot_bool public_only);
GDEXTENSION_LITE_DECL godot_bool godot_CryptoKey_is_public_only(const godot_CryptoKey *self);
GDEXTENSION_LITE_DECL godot_String godot_CryptoKey_save_to_string(godot_CryptoKey *self, godot_bool public_only);
GDEXTENSION_LITE_DECL godot_Error godot_CryptoKey_load_from_string(godot_CryptoKey *self, const godot_String *string_key, godot_bool public_only);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CRYPTO_KEY_H__
