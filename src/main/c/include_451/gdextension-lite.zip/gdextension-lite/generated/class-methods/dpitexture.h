// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_DPITEXTURE_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_DPITEXTURE_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_DPITexture *godot_new_DPITexture();

// Methods
GDEXTENSION_LITE_DECL godot_DPITexture * godot_DPITexture_create_from_string(const godot_String *source, godot_float scale, godot_float saturation, const godot_Dictionary *color_map);
GDEXTENSION_LITE_DECL void godot_DPITexture_set_source(godot_DPITexture *self, const godot_String *source);
GDEXTENSION_LITE_DECL godot_String godot_DPITexture_get_source(const godot_DPITexture *self);
GDEXTENSION_LITE_DECL void godot_DPITexture_set_base_scale(godot_DPITexture *self, godot_float base_scale);
GDEXTENSION_LITE_DECL godot_float godot_DPITexture_get_base_scale(const godot_DPITexture *self);
GDEXTENSION_LITE_DECL void godot_DPITexture_set_saturation(godot_DPITexture *self, godot_float saturation);
GDEXTENSION_LITE_DECL godot_float godot_DPITexture_get_saturation(const godot_DPITexture *self);
GDEXTENSION_LITE_DECL void godot_DPITexture_set_color_map(godot_DPITexture *self, const godot_Dictionary *color_map);
GDEXTENSION_LITE_DECL godot_Dictionary godot_DPITexture_get_color_map(const godot_DPITexture *self);
GDEXTENSION_LITE_DECL void godot_DPITexture_set_size_override(godot_DPITexture *self, const godot_Vector2i *size);
GDEXTENSION_LITE_DECL godot_RID godot_DPITexture_get_scaled_rid(const godot_DPITexture *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_DPITEXTURE_H__
