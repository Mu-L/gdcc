// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_RESOURCE_PREVIEW_GENERATOR_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_RESOURCE_PREVIEW_GENERATOR_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorResourcePreviewGenerator *godot_new_EditorResourcePreviewGenerator();

// Methods
GDEXTENSION_LITE_DECL godot_bool godot_EditorResourcePreviewGenerator__handles(const godot_EditorResourcePreviewGenerator *self, const godot_String *type);
GDEXTENSION_LITE_DECL godot_Texture2D * godot_EditorResourcePreviewGenerator__generate(const godot_EditorResourcePreviewGenerator *self, const godot_Resource *resource, const godot_Vector2i *size, const godot_Dictionary *metadata);
GDEXTENSION_LITE_DECL godot_Texture2D * godot_EditorResourcePreviewGenerator__generate_from_path(const godot_EditorResourcePreviewGenerator *self, const godot_String *path, const godot_Vector2i *size, const godot_Dictionary *metadata);
GDEXTENSION_LITE_DECL godot_bool godot_EditorResourcePreviewGenerator__generate_small_preview_automatically(const godot_EditorResourcePreviewGenerator *self);
GDEXTENSION_LITE_DECL godot_bool godot_EditorResourcePreviewGenerator__can_generate_small_preview(const godot_EditorResourcePreviewGenerator *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_RESOURCE_PREVIEW_GENERATOR_H__
