// This file was automatically generated
// Do not modify this file
#include "csgcylinder3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CSGCylinder3D *godot_new_CSGCylinder3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CSGCylinder3D);
}

// Methods
void godot_CSGCylinder3D_set_radius(godot_CSGCylinder3D *self, godot_float radius) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGCylinder3D, set_radius, 373806689, void, self, &radius)
}
godot_float godot_CSGCylinder3D_get_radius(const godot_CSGCylinder3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGCylinder3D, get_radius, 1740695150, godot_float, self)
}
void godot_CSGCylinder3D_set_height(godot_CSGCylinder3D *self, godot_float height) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGCylinder3D, set_height, 373806689, void, self, &height)
}
godot_float godot_CSGCylinder3D_get_height(const godot_CSGCylinder3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGCylinder3D, get_height, 1740695150, godot_float, self)
}
void godot_CSGCylinder3D_set_sides(godot_CSGCylinder3D *self, godot_int sides) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGCylinder3D, set_sides, 1286410249, void, self, &sides)
}
godot_int godot_CSGCylinder3D_get_sides(const godot_CSGCylinder3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGCylinder3D, get_sides, 3905245786, godot_int, self)
}
void godot_CSGCylinder3D_set_cone(godot_CSGCylinder3D *self, godot_bool cone) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGCylinder3D, set_cone, 2586408642, void, self, &cone)
}
godot_bool godot_CSGCylinder3D_is_cone(const godot_CSGCylinder3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGCylinder3D, is_cone, 36873697, godot_bool, self)
}
void godot_CSGCylinder3D_set_material(godot_CSGCylinder3D *self, const godot_Material *material) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGCylinder3D, set_material, 2757459619, void, self, material)
}
godot_Material * godot_CSGCylinder3D_get_material(const godot_CSGCylinder3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGCylinder3D, get_material, 5934680, godot_Material *, self)
}
void godot_CSGCylinder3D_set_smooth_faces(godot_CSGCylinder3D *self, godot_bool smooth_faces) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGCylinder3D, set_smooth_faces, 2586408642, void, self, &smooth_faces)
}
godot_bool godot_CSGCylinder3D_get_smooth_faces(const godot_CSGCylinder3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGCylinder3D, get_smooth_faces, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
