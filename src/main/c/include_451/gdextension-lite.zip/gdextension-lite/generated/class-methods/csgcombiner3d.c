// This file was automatically generated
// Do not modify this file
#include "csgcombiner3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CSGCombiner3D *godot_new_CSGCombiner3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CSGCombiner3D);
}


#ifdef __cplusplus
}
#endif
