// This file was automatically generated
// Do not modify this file
#include "csgsphere3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CSGSphere3D *godot_new_CSGSphere3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CSGSphere3D);
}

// Methods
void godot_CSGSphere3D_set_radius(godot_CSGSphere3D *self, godot_float radius) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGSphere3D, set_radius, 373806689, void, self, &radius)
}
godot_float godot_CSGSphere3D_get_radius(const godot_CSGSphere3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGSphere3D, get_radius, 1740695150, godot_float, self)
}
void godot_CSGSphere3D_set_radial_segments(godot_CSGSphere3D *self, godot_int radial_segments) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGSphere3D, set_radial_segments, 1286410249, void, self, &radial_segments)
}
godot_int godot_CSGSphere3D_get_radial_segments(const godot_CSGSphere3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGSphere3D, get_radial_segments, 3905245786, godot_int, self)
}
void godot_CSGSphere3D_set_rings(godot_CSGSphere3D *self, godot_int rings) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGSphere3D, set_rings, 1286410249, void, self, &rings)
}
godot_int godot_CSGSphere3D_get_rings(const godot_CSGSphere3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGSphere3D, get_rings, 3905245786, godot_int, self)
}
void godot_CSGSphere3D_set_smooth_faces(godot_CSGSphere3D *self, godot_bool smooth_faces) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGSphere3D, set_smooth_faces, 2586408642, void, self, &smooth_faces)
}
godot_bool godot_CSGSphere3D_get_smooth_faces(const godot_CSGSphere3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGSphere3D, get_smooth_faces, 36873697, godot_bool, self)
}
void godot_CSGSphere3D_set_material(godot_CSGSphere3D *self, const godot_Material *material) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CSGSphere3D, set_material, 2757459619, void, self, material)
}
godot_Material * godot_CSGSphere3D_get_material(const godot_CSGSphere3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CSGSphere3D, get_material, 5934680, godot_Material *, self)
}


#ifdef __cplusplus
}
#endif
