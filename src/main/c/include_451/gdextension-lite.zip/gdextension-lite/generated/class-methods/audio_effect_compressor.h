// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_COMPRESSOR_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_COMPRESSOR_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioEffectCompressor *godot_new_AudioEffectCompressor();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioEffectCompressor_set_threshold(godot_AudioEffectCompressor *self, godot_float threshold);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectCompressor_get_threshold(const godot_AudioEffectCompressor *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectCompressor_set_ratio(godot_AudioEffectCompressor *self, godot_float ratio);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectCompressor_get_ratio(const godot_AudioEffectCompressor *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectCompressor_set_gain(godot_AudioEffectCompressor *self, godot_float gain);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectCompressor_get_gain(const godot_AudioEffectCompressor *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectCompressor_set_attack_us(godot_AudioEffectCompressor *self, godot_float attack_us);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectCompressor_get_attack_us(const godot_AudioEffectCompressor *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectCompressor_set_release_ms(godot_AudioEffectCompressor *self, godot_float release_ms);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectCompressor_get_release_ms(const godot_AudioEffectCompressor *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectCompressor_set_mix(godot_AudioEffectCompressor *self, godot_float mix);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectCompressor_get_mix(const godot_AudioEffectCompressor *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectCompressor_set_sidechain(godot_AudioEffectCompressor *self, const godot_StringName *sidechain);
GDEXTENSION_LITE_DECL godot_StringName godot_AudioEffectCompressor_get_sidechain(const godot_AudioEffectCompressor *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_COMPRESSOR_H__
