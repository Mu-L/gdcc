// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_DAMPED_SPRING_JOINT2D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_DAMPED_SPRING_JOINT2D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_DampedSpringJoint2D *godot_new_DampedSpringJoint2D();

// Methods
GDEXTENSION_LITE_DECL void godot_DampedSpringJoint2D_set_length(godot_DampedSpringJoint2D *self, godot_float length);
GDEXTENSION_LITE_DECL godot_float godot_DampedSpringJoint2D_get_length(const godot_DampedSpringJoint2D *self);
GDEXTENSION_LITE_DECL void godot_DampedSpringJoint2D_set_rest_length(godot_DampedSpringJoint2D *self, godot_float rest_length);
GDEXTENSION_LITE_DECL godot_float godot_DampedSpringJoint2D_get_rest_length(const godot_DampedSpringJoint2D *self);
GDEXTENSION_LITE_DECL void godot_DampedSpringJoint2D_set_stiffness(godot_DampedSpringJoint2D *self, godot_float stiffness);
GDEXTENSION_LITE_DECL godot_float godot_DampedSpringJoint2D_get_stiffness(const godot_DampedSpringJoint2D *self);
GDEXTENSION_LITE_DECL void godot_DampedSpringJoint2D_set_damping(godot_DampedSpringJoint2D *self, godot_float damping);
GDEXTENSION_LITE_DECL godot_float godot_DampedSpringJoint2D_get_damping(const godot_DampedSpringJoint2D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_DAMPED_SPRING_JOINT2D_H__
