// This file was automatically generated
// Do not modify this file
#include "animation_root_node.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AnimationRootNode *godot_new_AnimationRootNode() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AnimationRootNode);
}


#ifdef __cplusplus
}
#endif
