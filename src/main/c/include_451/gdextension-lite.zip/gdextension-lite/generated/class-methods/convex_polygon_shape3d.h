// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONVEX_POLYGON_SHAPE3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONVEX_POLYGON_SHAPE3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_ConvexPolygonShape3D *godot_new_ConvexPolygonShape3D();

// Methods
GDEXTENSION_LITE_DECL void godot_ConvexPolygonShape3D_set_points(godot_ConvexPolygonShape3D *self, const godot_PackedVector3Array *points);
GDEXTENSION_LITE_DECL godot_PackedVector3Array godot_ConvexPolygonShape3D_get_points(const godot_ConvexPolygonShape3D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONVEX_POLYGON_SHAPE3D_H__
