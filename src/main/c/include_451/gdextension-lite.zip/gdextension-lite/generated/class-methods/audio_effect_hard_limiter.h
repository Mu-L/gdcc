// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_HARD_LIMITER_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_HARD_LIMITER_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AudioEffectHardLimiter *godot_new_AudioEffectHardLimiter();

// Methods
GDEXTENSION_LITE_DECL void godot_AudioEffectHardLimiter_set_ceiling_db(godot_AudioEffectHardLimiter *self, godot_float ceiling);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectHardLimiter_get_ceiling_db(const godot_AudioEffectHardLimiter *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectHardLimiter_set_pre_gain_db(godot_AudioEffectHardLimiter *self, godot_float p_pre_gain);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectHardLimiter_get_pre_gain_db(const godot_AudioEffectHardLimiter *self);
GDEXTENSION_LITE_DECL void godot_AudioEffectHardLimiter_set_release(godot_AudioEffectHardLimiter *self, godot_float p_release);
GDEXTENSION_LITE_DECL godot_float godot_AudioEffectHardLimiter_get_release(const godot_AudioEffectHardLimiter *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_AUDIO_EFFECT_HARD_LIMITER_H__
