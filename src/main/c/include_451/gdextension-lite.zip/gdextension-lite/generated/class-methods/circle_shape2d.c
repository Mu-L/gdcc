// This file was automatically generated
// Do not modify this file
#include "circle_shape2d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CircleShape2D *godot_new_CircleShape2D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CircleShape2D);
}

// Methods
void godot_CircleShape2D_set_radius(godot_CircleShape2D *self, godot_float radius) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CircleShape2D, set_radius, 373806689, void, self, &radius)
}
godot_float godot_CircleShape2D_get_radius(const godot_CircleShape2D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CircleShape2D, get_radius, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
