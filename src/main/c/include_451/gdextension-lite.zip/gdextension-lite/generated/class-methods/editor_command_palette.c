// This file was automatically generated
// Do not modify this file
#include "editor_command_palette.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorCommandPalette *godot_new_EditorCommandPalette() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorCommandPalette);
}

// Methods
void godot_EditorCommandPalette_add_command(godot_EditorCommandPalette *self, const godot_String *command_name, const godot_String *key_name, const godot_Callable *binded_callable, const godot_String *shortcut_text) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorCommandPalette, add_command, 864043298, void, self, command_name, key_name, binded_callable, shortcut_text)
}
void godot_EditorCommandPalette_remove_command(godot_EditorCommandPalette *self, const godot_String *key_name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorCommandPalette, remove_command, 83702148, void, self, key_name)
}


#ifdef __cplusplus
}
#endif
