// This file was automatically generated
// Do not modify this file
#include "editor_resource_tooltip_plugin.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorResourceTooltipPlugin *godot_new_EditorResourceTooltipPlugin() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorResourceTooltipPlugin);
}

// Methods
godot_bool godot_EditorResourceTooltipPlugin__handles(const godot_EditorResourceTooltipPlugin *self, const godot_String *type) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorResourceTooltipPlugin, _handles, 3927539163, godot_bool, self, type)
}
godot_Control * godot_EditorResourceTooltipPlugin__make_tooltip_for_path(const godot_EditorResourceTooltipPlugin *self, const godot_String *path, const godot_Dictionary *metadata, const godot_Control *base) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorResourceTooltipPlugin, _make_tooltip_for_path, 4100114520, godot_Control *, self, path, metadata, base)
}
void godot_EditorResourceTooltipPlugin_request_thumbnail(const godot_EditorResourceTooltipPlugin *self, const godot_String *path, const godot_TextureRect *control) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(EditorResourceTooltipPlugin, request_thumbnail, 3245519720, void, self, path, control)
}


#ifdef __cplusplus
}
#endif
