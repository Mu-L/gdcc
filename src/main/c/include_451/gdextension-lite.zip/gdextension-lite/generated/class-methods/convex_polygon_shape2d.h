// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONVEX_POLYGON_SHAPE2D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONVEX_POLYGON_SHAPE2D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_ConvexPolygonShape2D *godot_new_ConvexPolygonShape2D();

// Methods
GDEXTENSION_LITE_DECL void godot_ConvexPolygonShape2D_set_point_cloud(godot_ConvexPolygonShape2D *self, const godot_PackedVector2Array *point_cloud);
GDEXTENSION_LITE_DECL void godot_ConvexPolygonShape2D_set_points(godot_ConvexPolygonShape2D *self, const godot_PackedVector2Array *points);
GDEXTENSION_LITE_DECL godot_PackedVector2Array godot_ConvexPolygonShape2D_get_points(const godot_ConvexPolygonShape2D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CONVEX_POLYGON_SHAPE2D_H__
