// This file was automatically generated
// Do not modify this file
#include "config_file.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_ConfigFile *godot_new_ConfigFile() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(ConfigFile);
}

// Methods
void godot_ConfigFile_set_value(godot_ConfigFile *self, const godot_String *section, const godot_String *key, const godot_Variant *value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ConfigFile, set_value, 2504492430, void, self, section, key, value)
}
godot_Variant godot_ConfigFile_get_value(const godot_ConfigFile *self, const godot_String *section, const godot_String *key, const godot_Variant *default_value) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConfigFile, get_value, 89809366, godot_Variant, self, section, key, default_value)
}
godot_bool godot_ConfigFile_has_section(const godot_ConfigFile *self, const godot_String *section) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConfigFile, has_section, 3927539163, godot_bool, self, section)
}
godot_bool godot_ConfigFile_has_section_key(const godot_ConfigFile *self, const godot_String *section, const godot_String *key) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConfigFile, has_section_key, 820780508, godot_bool, self, section, key)
}
godot_PackedStringArray godot_ConfigFile_get_sections(const godot_ConfigFile *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConfigFile, get_sections, 1139954409, godot_PackedStringArray, self)
}
godot_PackedStringArray godot_ConfigFile_get_section_keys(const godot_ConfigFile *self, const godot_String *section) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConfigFile, get_section_keys, 4291131558, godot_PackedStringArray, self, section)
}
void godot_ConfigFile_erase_section(godot_ConfigFile *self, const godot_String *section) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ConfigFile, erase_section, 83702148, void, self, section)
}
void godot_ConfigFile_erase_section_key(godot_ConfigFile *self, const godot_String *section, const godot_String *key) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ConfigFile, erase_section_key, 3186203200, void, self, section, key)
}
godot_Error godot_ConfigFile_load(godot_ConfigFile *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConfigFile, load, 166001499, godot_Error, self, path)
}
godot_Error godot_ConfigFile_parse(godot_ConfigFile *self, const godot_String *data) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConfigFile, parse, 166001499, godot_Error, self, data)
}
godot_Error godot_ConfigFile_save(godot_ConfigFile *self, const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConfigFile, save, 166001499, godot_Error, self, path)
}
godot_String godot_ConfigFile_encode_to_text(const godot_ConfigFile *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConfigFile, encode_to_text, 201670096, godot_String, self)
}
godot_Error godot_ConfigFile_load_encrypted(godot_ConfigFile *self, const godot_String *path, const godot_PackedByteArray *key) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConfigFile, load_encrypted, 887037711, godot_Error, self, path, key)
}
godot_Error godot_ConfigFile_load_encrypted_pass(godot_ConfigFile *self, const godot_String *path, const godot_String *password) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConfigFile, load_encrypted_pass, 852856452, godot_Error, self, path, password)
}
godot_Error godot_ConfigFile_save_encrypted(godot_ConfigFile *self, const godot_String *path, const godot_PackedByteArray *key) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConfigFile, save_encrypted, 887037711, godot_Error, self, path, key)
}
godot_Error godot_ConfigFile_save_encrypted_pass(godot_ConfigFile *self, const godot_String *path, const godot_String *password) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(ConfigFile, save_encrypted_pass, 852856452, godot_Error, self, path, password)
}
void godot_ConfigFile_clear(godot_ConfigFile *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(ConfigFile, clear, 3218959716, void, self)
}


#ifdef __cplusplus
}
#endif
