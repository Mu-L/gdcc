// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAMERA2D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAMERA2D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_Camera2D *godot_new_Camera2D();

// Methods
GDEXTENSION_LITE_DECL void godot_Camera2D_set_offset(godot_Camera2D *self, const godot_Vector2 *offset);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Camera2D_get_offset(const godot_Camera2D *self);
GDEXTENSION_LITE_DECL void godot_Camera2D_set_anchor_mode(godot_Camera2D *self, godot_Camera2D_AnchorMode anchor_mode);
GDEXTENSION_LITE_DECL godot_Camera2D_AnchorMode godot_Camera2D_get_anchor_mode(const godot_Camera2D *self);
GDEXTENSION_LITE_DECL void godot_Camera2D_set_ignore_rotation(godot_Camera2D *self, godot_bool ignore);
GDEXTENSION_LITE_DECL godot_bool godot_Camera2D_is_ignoring_rotation(const godot_Camera2D *self);
GDEXTENSION_LITE_DECL void godot_Camera2D_set_process_callback(godot_Camera2D *self, godot_Camera2D_Camera2DProcessCallback mode);
GDEXTENSION_LITE_DECL godot_Camera2D_Camera2DProcessCallback godot_Camera2D_get_process_callback(const godot_Camera2D *self);
GDEXTENSION_LITE_DECL void godot_Camera2D_set_enabled(godot_Camera2D *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_Camera2D_is_enabled(const godot_Camera2D *self);
GDEXTENSION_LITE_DECL void godot_Camera2D_make_current(godot_Camera2D *self);
GDEXTENSION_LITE_DECL godot_bool godot_Camera2D_is_current(const godot_Camera2D *self);
GDEXTENSION_LITE_DECL void godot_Camera2D_set_limit_enabled(godot_Camera2D *self, godot_bool limit_enabled);
GDEXTENSION_LITE_DECL godot_bool godot_Camera2D_is_limit_enabled(const godot_Camera2D *self);
GDEXTENSION_LITE_DECL void godot_Camera2D_set_limit(godot_Camera2D *self, godot_Side margin, godot_int limit);
GDEXTENSION_LITE_DECL godot_int godot_Camera2D_get_limit(const godot_Camera2D *self, godot_Side margin);
GDEXTENSION_LITE_DECL void godot_Camera2D_set_limit_smoothing_enabled(godot_Camera2D *self, godot_bool limit_smoothing_enabled);
GDEXTENSION_LITE_DECL godot_bool godot_Camera2D_is_limit_smoothing_enabled(const godot_Camera2D *self);
GDEXTENSION_LITE_DECL void godot_Camera2D_set_drag_vertical_enabled(godot_Camera2D *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_Camera2D_is_drag_vertical_enabled(const godot_Camera2D *self);
GDEXTENSION_LITE_DECL void godot_Camera2D_set_drag_horizontal_enabled(godot_Camera2D *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_Camera2D_is_drag_horizontal_enabled(const godot_Camera2D *self);
GDEXTENSION_LITE_DECL void godot_Camera2D_set_drag_vertical_offset(godot_Camera2D *self, godot_float offset);
GDEXTENSION_LITE_DECL godot_float godot_Camera2D_get_drag_vertical_offset(const godot_Camera2D *self);
GDEXTENSION_LITE_DECL void godot_Camera2D_set_drag_horizontal_offset(godot_Camera2D *self, godot_float offset);
GDEXTENSION_LITE_DECL godot_float godot_Camera2D_get_drag_horizontal_offset(const godot_Camera2D *self);
GDEXTENSION_LITE_DECL void godot_Camera2D_set_drag_margin(godot_Camera2D *self, godot_Side margin, godot_float drag_margin);
GDEXTENSION_LITE_DECL godot_float godot_Camera2D_get_drag_margin(const godot_Camera2D *self, godot_Side margin);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Camera2D_get_target_position(const godot_Camera2D *self);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Camera2D_get_screen_center_position(const godot_Camera2D *self);
GDEXTENSION_LITE_DECL godot_float godot_Camera2D_get_screen_rotation(const godot_Camera2D *self);
GDEXTENSION_LITE_DECL void godot_Camera2D_set_zoom(godot_Camera2D *self, const godot_Vector2 *zoom);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Camera2D_get_zoom(const godot_Camera2D *self);
GDEXTENSION_LITE_DECL void godot_Camera2D_set_custom_viewport(godot_Camera2D *self, const godot_Node *viewport);
GDEXTENSION_LITE_DECL godot_Node * godot_Camera2D_get_custom_viewport(const godot_Camera2D *self);
GDEXTENSION_LITE_DECL void godot_Camera2D_set_position_smoothing_speed(godot_Camera2D *self, godot_float position_smoothing_speed);
GDEXTENSION_LITE_DECL godot_float godot_Camera2D_get_position_smoothing_speed(const godot_Camera2D *self);
GDEXTENSION_LITE_DECL void godot_Camera2D_set_position_smoothing_enabled(godot_Camera2D *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_Camera2D_is_position_smoothing_enabled(const godot_Camera2D *self);
GDEXTENSION_LITE_DECL void godot_Camera2D_set_rotation_smoothing_enabled(godot_Camera2D *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_Camera2D_is_rotation_smoothing_enabled(const godot_Camera2D *self);
GDEXTENSION_LITE_DECL void godot_Camera2D_set_rotation_smoothing_speed(godot_Camera2D *self, godot_float speed);
GDEXTENSION_LITE_DECL godot_float godot_Camera2D_get_rotation_smoothing_speed(const godot_Camera2D *self);
GDEXTENSION_LITE_DECL void godot_Camera2D_force_update_scroll(godot_Camera2D *self);
GDEXTENSION_LITE_DECL void godot_Camera2D_reset_smoothing(godot_Camera2D *self);
GDEXTENSION_LITE_DECL void godot_Camera2D_align(godot_Camera2D *self);
GDEXTENSION_LITE_DECL void godot_Camera2D_set_screen_drawing_enabled(godot_Camera2D *self, godot_bool screen_drawing_enabled);
GDEXTENSION_LITE_DECL godot_bool godot_Camera2D_is_screen_drawing_enabled(const godot_Camera2D *self);
GDEXTENSION_LITE_DECL void godot_Camera2D_set_limit_drawing_enabled(godot_Camera2D *self, godot_bool limit_drawing_enabled);
GDEXTENSION_LITE_DECL godot_bool godot_Camera2D_is_limit_drawing_enabled(const godot_Camera2D *self);
GDEXTENSION_LITE_DECL void godot_Camera2D_set_margin_drawing_enabled(godot_Camera2D *self, godot_bool margin_drawing_enabled);
GDEXTENSION_LITE_DECL godot_bool godot_Camera2D_is_margin_drawing_enabled(const godot_Camera2D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAMERA2D_H__
