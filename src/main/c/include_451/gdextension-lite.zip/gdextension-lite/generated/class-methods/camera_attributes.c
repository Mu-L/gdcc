// This file was automatically generated
// Do not modify this file
#include "camera_attributes.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CameraAttributes *godot_new_CameraAttributes() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CameraAttributes);
}

// Methods
void godot_CameraAttributes_set_exposure_multiplier(godot_CameraAttributes *self, godot_float multiplier) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraAttributes, set_exposure_multiplier, 373806689, void, self, &multiplier)
}
godot_float godot_CameraAttributes_get_exposure_multiplier(const godot_CameraAttributes *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraAttributes, get_exposure_multiplier, 1740695150, godot_float, self)
}
void godot_CameraAttributes_set_exposure_sensitivity(godot_CameraAttributes *self, godot_float sensitivity) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraAttributes, set_exposure_sensitivity, 373806689, void, self, &sensitivity)
}
godot_float godot_CameraAttributes_get_exposure_sensitivity(const godot_CameraAttributes *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraAttributes, get_exposure_sensitivity, 1740695150, godot_float, self)
}
void godot_CameraAttributes_set_auto_exposure_enabled(godot_CameraAttributes *self, godot_bool enabled) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraAttributes, set_auto_exposure_enabled, 2586408642, void, self, &enabled)
}
godot_bool godot_CameraAttributes_is_auto_exposure_enabled(const godot_CameraAttributes *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraAttributes, is_auto_exposure_enabled, 36873697, godot_bool, self)
}
void godot_CameraAttributes_set_auto_exposure_speed(godot_CameraAttributes *self, godot_float exposure_speed) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraAttributes, set_auto_exposure_speed, 373806689, void, self, &exposure_speed)
}
godot_float godot_CameraAttributes_get_auto_exposure_speed(const godot_CameraAttributes *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraAttributes, get_auto_exposure_speed, 1740695150, godot_float, self)
}
void godot_CameraAttributes_set_auto_exposure_scale(godot_CameraAttributes *self, godot_float exposure_grey) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CameraAttributes, set_auto_exposure_scale, 373806689, void, self, &exposure_grey)
}
godot_float godot_CameraAttributes_get_auto_exposure_scale(const godot_CameraAttributes *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CameraAttributes, get_auto_exposure_scale, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
