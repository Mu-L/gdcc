// This file was automatically generated
// Do not modify this file
#include "collision_shape3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CollisionShape3D *godot_new_CollisionShape3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CollisionShape3D);
}

// Methods
void godot_CollisionShape3D_resource_changed(godot_CollisionShape3D *self, const godot_Resource *resource) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionShape3D, resource_changed, 968641751, void, self, resource)
}
void godot_CollisionShape3D_set_shape(godot_CollisionShape3D *self, const godot_Shape3D *shape) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionShape3D, set_shape, 1549710052, void, self, shape)
}
godot_Shape3D * godot_CollisionShape3D_get_shape(const godot_CollisionShape3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionShape3D, get_shape, 3214262478, godot_Shape3D *, self)
}
void godot_CollisionShape3D_set_disabled(godot_CollisionShape3D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionShape3D, set_disabled, 2586408642, void, self, &enable)
}
godot_bool godot_CollisionShape3D_is_disabled(const godot_CollisionShape3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionShape3D, is_disabled, 36873697, godot_bool, self)
}
void godot_CollisionShape3D_make_convex_from_siblings(godot_CollisionShape3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionShape3D, make_convex_from_siblings, 3218959716, void, self)
}
void godot_CollisionShape3D_set_debug_color(godot_CollisionShape3D *self, const godot_Color *color) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionShape3D, set_debug_color, 2920490490, void, self, color)
}
godot_Color godot_CollisionShape3D_get_debug_color(const godot_CollisionShape3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionShape3D, get_debug_color, 3444240500, godot_Color, self)
}
void godot_CollisionShape3D_set_enable_debug_fill(godot_CollisionShape3D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CollisionShape3D, set_enable_debug_fill, 2586408642, void, self, &enable)
}
godot_bool godot_CollisionShape3D_get_enable_debug_fill(const godot_CollisionShape3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CollisionShape3D, get_enable_debug_fill, 36873697, godot_bool, self)
}


#ifdef __cplusplus
}
#endif
