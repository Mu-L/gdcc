// This file was automatically generated
// Do not modify this file
#include "editor_scene_post_import.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_EditorScenePostImport *godot_new_EditorScenePostImport() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(EditorScenePostImport);
}

// Methods
godot_Object * godot_EditorScenePostImport__post_import(godot_EditorScenePostImport *self, const godot_Node *scene) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorScenePostImport, _post_import, 134930648, godot_Object *, self, scene)
}
godot_String godot_EditorScenePostImport_get_source_file(const godot_EditorScenePostImport *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(EditorScenePostImport, get_source_file, 201670096, godot_String, self)
}


#ifdef __cplusplus
}
#endif
