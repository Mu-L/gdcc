// This file was automatically generated
// Do not modify this file
#include "audio_stream_mp3.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_AudioStreamMP3 *godot_new_AudioStreamMP3() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(AudioStreamMP3);
}

// Methods
godot_AudioStreamMP3 * godot_AudioStreamMP3_load_from_buffer(const godot_PackedByteArray *stream_data) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamMP3, load_from_buffer, 1674970313, godot_AudioStreamMP3 *, NULL, stream_data)
}
godot_AudioStreamMP3 * godot_AudioStreamMP3_load_from_file(const godot_String *path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamMP3, load_from_file, 4238362998, godot_AudioStreamMP3 *, NULL, path)
}
void godot_AudioStreamMP3_set_data(godot_AudioStreamMP3 *self, const godot_PackedByteArray *data) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamMP3, set_data, 2971499966, void, self, data)
}
godot_PackedByteArray godot_AudioStreamMP3_get_data(const godot_AudioStreamMP3 *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamMP3, get_data, 2362200018, godot_PackedByteArray, self)
}
void godot_AudioStreamMP3_set_loop(godot_AudioStreamMP3 *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamMP3, set_loop, 2586408642, void, self, &enable)
}
godot_bool godot_AudioStreamMP3_has_loop(const godot_AudioStreamMP3 *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamMP3, has_loop, 36873697, godot_bool, self)
}
void godot_AudioStreamMP3_set_loop_offset(godot_AudioStreamMP3 *self, godot_float seconds) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamMP3, set_loop_offset, 373806689, void, self, &seconds)
}
godot_float godot_AudioStreamMP3_get_loop_offset(const godot_AudioStreamMP3 *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamMP3, get_loop_offset, 1740695150, godot_float, self)
}
void godot_AudioStreamMP3_set_bpm(godot_AudioStreamMP3 *self, godot_float bpm) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamMP3, set_bpm, 373806689, void, self, &bpm)
}
godot_float godot_AudioStreamMP3_get_bpm(const godot_AudioStreamMP3 *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamMP3, get_bpm, 1740695150, godot_float, self)
}
void godot_AudioStreamMP3_set_beat_count(godot_AudioStreamMP3 *self, godot_int count) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamMP3, set_beat_count, 1286410249, void, self, &count)
}
godot_int godot_AudioStreamMP3_get_beat_count(const godot_AudioStreamMP3 *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamMP3, get_beat_count, 3905245786, godot_int, self)
}
void godot_AudioStreamMP3_set_bar_beats(godot_AudioStreamMP3 *self, godot_int count) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(AudioStreamMP3, set_bar_beats, 1286410249, void, self, &count)
}
godot_int godot_AudioStreamMP3_get_bar_beats(const godot_AudioStreamMP3 *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(AudioStreamMP3, get_bar_beats, 3905245786, godot_int, self)
}


#ifdef __cplusplus
}
#endif
