// This file was automatically generated
// Do not modify this file
#include "area3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_Area3D *godot_new_Area3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(Area3D);
}

// Methods
void godot_Area3D_set_gravity_space_override_mode(godot_Area3D *self, godot_Area3D_SpaceOverride space_override_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Area3D, set_gravity_space_override_mode, 2311433571, void, self, &space_override_mode)
}
godot_Area3D_SpaceOverride godot_Area3D_get_gravity_space_override_mode(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, get_gravity_space_override_mode, 958191869, godot_Area3D_SpaceOverride, self)
}
void godot_Area3D_set_gravity_is_point(godot_Area3D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Area3D, set_gravity_is_point, 2586408642, void, self, &enable)
}
godot_bool godot_Area3D_is_gravity_a_point(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, is_gravity_a_point, 36873697, godot_bool, self)
}
void godot_Area3D_set_gravity_point_unit_distance(godot_Area3D *self, godot_float distance_scale) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Area3D, set_gravity_point_unit_distance, 373806689, void, self, &distance_scale)
}
godot_float godot_Area3D_get_gravity_point_unit_distance(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, get_gravity_point_unit_distance, 1740695150, godot_float, self)
}
void godot_Area3D_set_gravity_point_center(godot_Area3D *self, const godot_Vector3 *center) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Area3D, set_gravity_point_center, 3460891852, void, self, center)
}
godot_Vector3 godot_Area3D_get_gravity_point_center(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, get_gravity_point_center, 3360562783, godot_Vector3, self)
}
void godot_Area3D_set_gravity_direction(godot_Area3D *self, const godot_Vector3 *direction) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Area3D, set_gravity_direction, 3460891852, void, self, direction)
}
godot_Vector3 godot_Area3D_get_gravity_direction(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, get_gravity_direction, 3360562783, godot_Vector3, self)
}
void godot_Area3D_set_gravity(godot_Area3D *self, godot_float gravity) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Area3D, set_gravity, 373806689, void, self, &gravity)
}
godot_float godot_Area3D_get_gravity(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, get_gravity, 1740695150, godot_float, self)
}
void godot_Area3D_set_linear_damp_space_override_mode(godot_Area3D *self, godot_Area3D_SpaceOverride space_override_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Area3D, set_linear_damp_space_override_mode, 2311433571, void, self, &space_override_mode)
}
godot_Area3D_SpaceOverride godot_Area3D_get_linear_damp_space_override_mode(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, get_linear_damp_space_override_mode, 958191869, godot_Area3D_SpaceOverride, self)
}
void godot_Area3D_set_angular_damp_space_override_mode(godot_Area3D *self, godot_Area3D_SpaceOverride space_override_mode) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Area3D, set_angular_damp_space_override_mode, 2311433571, void, self, &space_override_mode)
}
godot_Area3D_SpaceOverride godot_Area3D_get_angular_damp_space_override_mode(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, get_angular_damp_space_override_mode, 958191869, godot_Area3D_SpaceOverride, self)
}
void godot_Area3D_set_angular_damp(godot_Area3D *self, godot_float angular_damp) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Area3D, set_angular_damp, 373806689, void, self, &angular_damp)
}
godot_float godot_Area3D_get_angular_damp(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, get_angular_damp, 1740695150, godot_float, self)
}
void godot_Area3D_set_linear_damp(godot_Area3D *self, godot_float linear_damp) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Area3D, set_linear_damp, 373806689, void, self, &linear_damp)
}
godot_float godot_Area3D_get_linear_damp(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, get_linear_damp, 1740695150, godot_float, self)
}
void godot_Area3D_set_priority(godot_Area3D *self, godot_int priority) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Area3D, set_priority, 1286410249, void, self, &priority)
}
godot_int godot_Area3D_get_priority(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, get_priority, 3905245786, godot_int, self)
}
void godot_Area3D_set_wind_force_magnitude(godot_Area3D *self, godot_float wind_force_magnitude) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Area3D, set_wind_force_magnitude, 373806689, void, self, &wind_force_magnitude)
}
godot_float godot_Area3D_get_wind_force_magnitude(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, get_wind_force_magnitude, 1740695150, godot_float, self)
}
void godot_Area3D_set_wind_attenuation_factor(godot_Area3D *self, godot_float wind_attenuation_factor) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Area3D, set_wind_attenuation_factor, 373806689, void, self, &wind_attenuation_factor)
}
godot_float godot_Area3D_get_wind_attenuation_factor(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, get_wind_attenuation_factor, 1740695150, godot_float, self)
}
void godot_Area3D_set_wind_source_path(godot_Area3D *self, const godot_NodePath *wind_source_path) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Area3D, set_wind_source_path, 1348162250, void, self, wind_source_path)
}
godot_NodePath godot_Area3D_get_wind_source_path(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, get_wind_source_path, 4075236667, godot_NodePath, self)
}
void godot_Area3D_set_monitorable(godot_Area3D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Area3D, set_monitorable, 2586408642, void, self, &enable)
}
godot_bool godot_Area3D_is_monitorable(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, is_monitorable, 36873697, godot_bool, self)
}
void godot_Area3D_set_monitoring(godot_Area3D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Area3D, set_monitoring, 2586408642, void, self, &enable)
}
godot_bool godot_Area3D_is_monitoring(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, is_monitoring, 36873697, godot_bool, self)
}
godot_TypedArray(godot_Node3D) godot_Area3D_get_overlapping_bodies(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, get_overlapping_bodies, 3995934104, godot_TypedArray(godot_Node3D), self)
}
godot_TypedArray(godot_Area3D) godot_Area3D_get_overlapping_areas(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, get_overlapping_areas, 3995934104, godot_TypedArray(godot_Area3D), self)
}
godot_bool godot_Area3D_has_overlapping_bodies(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, has_overlapping_bodies, 36873697, godot_bool, self)
}
godot_bool godot_Area3D_has_overlapping_areas(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, has_overlapping_areas, 36873697, godot_bool, self)
}
godot_bool godot_Area3D_overlaps_body(const godot_Area3D *self, const godot_Node *body) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, overlaps_body, 3093956946, godot_bool, self, body)
}
godot_bool godot_Area3D_overlaps_area(const godot_Area3D *self, const godot_Node *area) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, overlaps_area, 3093956946, godot_bool, self, area)
}
void godot_Area3D_set_audio_bus_override(godot_Area3D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Area3D, set_audio_bus_override, 2586408642, void, self, &enable)
}
godot_bool godot_Area3D_is_overriding_audio_bus(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, is_overriding_audio_bus, 36873697, godot_bool, self)
}
void godot_Area3D_set_audio_bus_name(godot_Area3D *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Area3D, set_audio_bus_name, 3304788590, void, self, name)
}
godot_StringName godot_Area3D_get_audio_bus_name(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, get_audio_bus_name, 2002593661, godot_StringName, self)
}
void godot_Area3D_set_use_reverb_bus(godot_Area3D *self, godot_bool enable) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Area3D, set_use_reverb_bus, 2586408642, void, self, &enable)
}
godot_bool godot_Area3D_is_using_reverb_bus(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, is_using_reverb_bus, 36873697, godot_bool, self)
}
void godot_Area3D_set_reverb_bus_name(godot_Area3D *self, const godot_StringName *name) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Area3D, set_reverb_bus_name, 3304788590, void, self, name)
}
godot_StringName godot_Area3D_get_reverb_bus_name(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, get_reverb_bus_name, 2002593661, godot_StringName, self)
}
void godot_Area3D_set_reverb_amount(godot_Area3D *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Area3D, set_reverb_amount, 373806689, void, self, &amount)
}
godot_float godot_Area3D_get_reverb_amount(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, get_reverb_amount, 1740695150, godot_float, self)
}
void godot_Area3D_set_reverb_uniformity(godot_Area3D *self, godot_float amount) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Area3D, set_reverb_uniformity, 373806689, void, self, &amount)
}
godot_float godot_Area3D_get_reverb_uniformity(const godot_Area3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Area3D, get_reverb_uniformity, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
