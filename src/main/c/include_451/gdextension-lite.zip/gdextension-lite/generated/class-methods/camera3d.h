// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAMERA3D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAMERA3D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_Camera3D *godot_new_Camera3D();

// Methods
GDEXTENSION_LITE_DECL godot_Vector3 godot_Camera3D_project_ray_normal(const godot_Camera3D *self, const godot_Vector2 *screen_point);
GDEXTENSION_LITE_DECL godot_Vector3 godot_Camera3D_project_local_ray_normal(const godot_Camera3D *self, const godot_Vector2 *screen_point);
GDEXTENSION_LITE_DECL godot_Vector3 godot_Camera3D_project_ray_origin(const godot_Camera3D *self, const godot_Vector2 *screen_point);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Camera3D_unproject_position(const godot_Camera3D *self, const godot_Vector3 *world_point);
GDEXTENSION_LITE_DECL godot_bool godot_Camera3D_is_position_behind(const godot_Camera3D *self, const godot_Vector3 *world_point);
GDEXTENSION_LITE_DECL godot_Vector3 godot_Camera3D_project_position(const godot_Camera3D *self, const godot_Vector2 *screen_point, godot_float z_depth);
GDEXTENSION_LITE_DECL void godot_Camera3D_set_perspective(godot_Camera3D *self, godot_float fov, godot_float z_near, godot_float z_far);
GDEXTENSION_LITE_DECL void godot_Camera3D_set_orthogonal(godot_Camera3D *self, godot_float size, godot_float z_near, godot_float z_far);
GDEXTENSION_LITE_DECL void godot_Camera3D_set_frustum(godot_Camera3D *self, godot_float size, const godot_Vector2 *offset, godot_float z_near, godot_float z_far);
GDEXTENSION_LITE_DECL void godot_Camera3D_make_current(godot_Camera3D *self);
GDEXTENSION_LITE_DECL void godot_Camera3D_clear_current(godot_Camera3D *self, godot_bool enable_next);
GDEXTENSION_LITE_DECL void godot_Camera3D_set_current(godot_Camera3D *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_Camera3D_is_current(const godot_Camera3D *self);
GDEXTENSION_LITE_DECL godot_Transform3D godot_Camera3D_get_camera_transform(const godot_Camera3D *self);
GDEXTENSION_LITE_DECL godot_Projection godot_Camera3D_get_camera_projection(const godot_Camera3D *self);
GDEXTENSION_LITE_DECL godot_float godot_Camera3D_get_fov(const godot_Camera3D *self);
GDEXTENSION_LITE_DECL godot_Vector2 godot_Camera3D_get_frustum_offset(const godot_Camera3D *self);
GDEXTENSION_LITE_DECL godot_float godot_Camera3D_get_size(const godot_Camera3D *self);
GDEXTENSION_LITE_DECL godot_float godot_Camera3D_get_far(const godot_Camera3D *self);
GDEXTENSION_LITE_DECL godot_float godot_Camera3D_get_near(const godot_Camera3D *self);
GDEXTENSION_LITE_DECL void godot_Camera3D_set_fov(godot_Camera3D *self, godot_float fov);
GDEXTENSION_LITE_DECL void godot_Camera3D_set_frustum_offset(godot_Camera3D *self, const godot_Vector2 *offset);
GDEXTENSION_LITE_DECL void godot_Camera3D_set_size(godot_Camera3D *self, godot_float size);
GDEXTENSION_LITE_DECL void godot_Camera3D_set_far(godot_Camera3D *self, godot_float far);
GDEXTENSION_LITE_DECL void godot_Camera3D_set_near(godot_Camera3D *self, godot_float near);
GDEXTENSION_LITE_DECL godot_Camera3D_ProjectionType godot_Camera3D_get_projection(const godot_Camera3D *self);
GDEXTENSION_LITE_DECL void godot_Camera3D_set_projection(godot_Camera3D *self, godot_Camera3D_ProjectionType mode);
GDEXTENSION_LITE_DECL void godot_Camera3D_set_h_offset(godot_Camera3D *self, godot_float offset);
GDEXTENSION_LITE_DECL godot_float godot_Camera3D_get_h_offset(const godot_Camera3D *self);
GDEXTENSION_LITE_DECL void godot_Camera3D_set_v_offset(godot_Camera3D *self, godot_float offset);
GDEXTENSION_LITE_DECL godot_float godot_Camera3D_get_v_offset(const godot_Camera3D *self);
GDEXTENSION_LITE_DECL void godot_Camera3D_set_cull_mask(godot_Camera3D *self, godot_int mask);
GDEXTENSION_LITE_DECL godot_int godot_Camera3D_get_cull_mask(const godot_Camera3D *self);
GDEXTENSION_LITE_DECL void godot_Camera3D_set_environment(godot_Camera3D *self, const godot_Environment *env);
GDEXTENSION_LITE_DECL godot_Environment * godot_Camera3D_get_environment(const godot_Camera3D *self);
GDEXTENSION_LITE_DECL void godot_Camera3D_set_attributes(godot_Camera3D *self, const godot_CameraAttributes *env);
GDEXTENSION_LITE_DECL godot_CameraAttributes * godot_Camera3D_get_attributes(const godot_Camera3D *self);
GDEXTENSION_LITE_DECL void godot_Camera3D_set_compositor(godot_Camera3D *self, const godot_Compositor *compositor);
GDEXTENSION_LITE_DECL godot_Compositor * godot_Camera3D_get_compositor(const godot_Camera3D *self);
GDEXTENSION_LITE_DECL void godot_Camera3D_set_keep_aspect_mode(godot_Camera3D *self, godot_Camera3D_KeepAspect mode);
GDEXTENSION_LITE_DECL godot_Camera3D_KeepAspect godot_Camera3D_get_keep_aspect_mode(const godot_Camera3D *self);
GDEXTENSION_LITE_DECL void godot_Camera3D_set_doppler_tracking(godot_Camera3D *self, godot_Camera3D_DopplerTracking mode);
GDEXTENSION_LITE_DECL godot_Camera3D_DopplerTracking godot_Camera3D_get_doppler_tracking(const godot_Camera3D *self);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_Plane) godot_Camera3D_get_frustum(const godot_Camera3D *self);
GDEXTENSION_LITE_DECL godot_bool godot_Camera3D_is_position_in_frustum(const godot_Camera3D *self, const godot_Vector3 *world_point);
GDEXTENSION_LITE_DECL godot_RID godot_Camera3D_get_camera_rid(const godot_Camera3D *self);
GDEXTENSION_LITE_DECL godot_RID godot_Camera3D_get_pyramid_shape_rid(godot_Camera3D *self);
GDEXTENSION_LITE_DECL void godot_Camera3D_set_cull_mask_value(godot_Camera3D *self, godot_int layer_number, godot_bool value);
GDEXTENSION_LITE_DECL godot_bool godot_Camera3D_get_cull_mask_value(const godot_Camera3D *self, godot_int layer_number);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_CAMERA3D_H__
