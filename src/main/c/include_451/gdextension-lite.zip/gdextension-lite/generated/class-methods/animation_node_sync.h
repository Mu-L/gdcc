// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_SYNC_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_SYNC_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_AnimationNodeSync *godot_new_AnimationNodeSync();

// Methods
GDEXTENSION_LITE_DECL void godot_AnimationNodeSync_set_use_sync(godot_AnimationNodeSync *self, godot_bool enable);
GDEXTENSION_LITE_DECL godot_bool godot_AnimationNodeSync_is_using_sync(const godot_AnimationNodeSync *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_ANIMATION_NODE_SYNC_H__
