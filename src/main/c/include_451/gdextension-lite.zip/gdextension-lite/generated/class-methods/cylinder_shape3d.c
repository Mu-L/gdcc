// This file was automatically generated
// Do not modify this file
#include "cylinder_shape3d.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_CylinderShape3D *godot_new_CylinderShape3D() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(CylinderShape3D);
}

// Methods
void godot_CylinderShape3D_set_radius(godot_CylinderShape3D *self, godot_float radius) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CylinderShape3D, set_radius, 373806689, void, self, &radius)
}
godot_float godot_CylinderShape3D_get_radius(const godot_CylinderShape3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CylinderShape3D, get_radius, 1740695150, godot_float, self)
}
void godot_CylinderShape3D_set_height(godot_CylinderShape3D *self, godot_float height) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(CylinderShape3D, set_height, 373806689, void, self, &height)
}
godot_float godot_CylinderShape3D_get_height(const godot_CylinderShape3D *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(CylinderShape3D, get_height, 1740695150, godot_float, self)
}


#ifdef __cplusplus
}
#endif
