// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLLISION_SHAPE2D_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLLISION_SHAPE2D_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_CollisionShape2D *godot_new_CollisionShape2D();

// Methods
GDEXTENSION_LITE_DECL void godot_CollisionShape2D_set_shape(godot_CollisionShape2D *self, const godot_Shape2D *shape);
GDEXTENSION_LITE_DECL godot_Shape2D * godot_CollisionShape2D_get_shape(const godot_CollisionShape2D *self);
GDEXTENSION_LITE_DECL void godot_CollisionShape2D_set_disabled(godot_CollisionShape2D *self, godot_bool disabled);
GDEXTENSION_LITE_DECL godot_bool godot_CollisionShape2D_is_disabled(const godot_CollisionShape2D *self);
GDEXTENSION_LITE_DECL void godot_CollisionShape2D_set_one_way_collision(godot_CollisionShape2D *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_CollisionShape2D_is_one_way_collision_enabled(const godot_CollisionShape2D *self);
GDEXTENSION_LITE_DECL void godot_CollisionShape2D_set_one_way_collision_margin(godot_CollisionShape2D *self, godot_float margin);
GDEXTENSION_LITE_DECL godot_float godot_CollisionShape2D_get_one_way_collision_margin(const godot_CollisionShape2D *self);
GDEXTENSION_LITE_DECL void godot_CollisionShape2D_set_debug_color(godot_CollisionShape2D *self, const godot_Color *color);
GDEXTENSION_LITE_DECL godot_Color godot_CollisionShape2D_get_debug_color(const godot_CollisionShape2D *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_COLLISION_SHAPE2D_H__
