// This file was automatically generated
// Do not modify this file
#include "compositor.h"

#include "../../implementation-macros.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
godot_Compositor *godot_new_Compositor() {
	GDEXTENSION_LITE_CLASS_CONSTRUCTOR_IMPL(Compositor);
}

// Methods
void godot_Compositor_set_compositor_effects(godot_Compositor *self, const godot_TypedArray(godot_CompositorEffect) *compositor_effects) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL_VOID(Compositor, set_compositor_effects, 381264803, void, self, compositor_effects)
}
godot_TypedArray(godot_CompositorEffect) godot_Compositor_get_compositor_effects(const godot_Compositor *self) {
	GDEXTENSION_LITE_CLASS_METHOD_IMPL(Compositor, get_compositor_effects, 3995934104, godot_TypedArray(godot_CompositorEffect), self)
}


#ifdef __cplusplus
}
#endif
