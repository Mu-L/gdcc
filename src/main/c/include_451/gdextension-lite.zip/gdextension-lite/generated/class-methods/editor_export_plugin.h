// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_EXPORT_PLUGIN_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_EXPORT_PLUGIN_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Constructor
GDEXTENSION_LITE_DECL godot_EditorExportPlugin *godot_new_EditorExportPlugin();

// Methods
GDEXTENSION_LITE_DECL void godot_EditorExportPlugin__export_file(godot_EditorExportPlugin *self, const godot_String *path, const godot_String *type, const godot_PackedStringArray *features);
GDEXTENSION_LITE_DECL void godot_EditorExportPlugin__export_begin(godot_EditorExportPlugin *self, const godot_PackedStringArray *features, godot_bool is_debug, const godot_String *path, godot_int flags);
GDEXTENSION_LITE_DECL void godot_EditorExportPlugin__export_end(godot_EditorExportPlugin *self);
GDEXTENSION_LITE_DECL godot_bool godot_EditorExportPlugin__begin_customize_resources(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform, const godot_PackedStringArray *features);
GDEXTENSION_LITE_DECL godot_Resource * godot_EditorExportPlugin__customize_resource(godot_EditorExportPlugin *self, const godot_Resource *resource, const godot_String *path);
GDEXTENSION_LITE_DECL godot_bool godot_EditorExportPlugin__begin_customize_scenes(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform, const godot_PackedStringArray *features);
GDEXTENSION_LITE_DECL godot_Node * godot_EditorExportPlugin__customize_scene(godot_EditorExportPlugin *self, const godot_Node *scene, const godot_String *path);
GDEXTENSION_LITE_DECL godot_int godot_EditorExportPlugin__get_customization_configuration_hash(const godot_EditorExportPlugin *self);
GDEXTENSION_LITE_DECL void godot_EditorExportPlugin__end_customize_scenes(godot_EditorExportPlugin *self);
GDEXTENSION_LITE_DECL void godot_EditorExportPlugin__end_customize_resources(godot_EditorExportPlugin *self);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_Dictionary) godot_EditorExportPlugin__get_export_options(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform);
GDEXTENSION_LITE_DECL godot_Dictionary godot_EditorExportPlugin__get_export_options_overrides(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform);
GDEXTENSION_LITE_DECL godot_bool godot_EditorExportPlugin__should_update_export_options(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform);
GDEXTENSION_LITE_DECL godot_bool godot_EditorExportPlugin__get_export_option_visibility(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform, const godot_String *option);
GDEXTENSION_LITE_DECL godot_String godot_EditorExportPlugin__get_export_option_warning(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform, const godot_String *option);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_EditorExportPlugin__get_export_features(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform, godot_bool debug);
GDEXTENSION_LITE_DECL godot_String godot_EditorExportPlugin__get_name(const godot_EditorExportPlugin *self);
GDEXTENSION_LITE_DECL godot_bool godot_EditorExportPlugin__supports_platform(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_EditorExportPlugin__get_android_dependencies(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform, godot_bool debug);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_EditorExportPlugin__get_android_dependencies_maven_repos(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform, godot_bool debug);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_EditorExportPlugin__get_android_libraries(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform, godot_bool debug);
GDEXTENSION_LITE_DECL godot_String godot_EditorExportPlugin__get_android_manifest_activity_element_contents(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform, godot_bool debug);
GDEXTENSION_LITE_DECL godot_String godot_EditorExportPlugin__get_android_manifest_application_element_contents(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform, godot_bool debug);
GDEXTENSION_LITE_DECL godot_String godot_EditorExportPlugin__get_android_manifest_element_contents(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform, godot_bool debug);
GDEXTENSION_LITE_DECL godot_PackedByteArray godot_EditorExportPlugin__update_android_prebuilt_manifest(const godot_EditorExportPlugin *self, const godot_EditorExportPlatform *platform, const godot_PackedByteArray *manifest_data);
GDEXTENSION_LITE_DECL void godot_EditorExportPlugin_add_shared_object(godot_EditorExportPlugin *self, const godot_String *path, const godot_PackedStringArray *tags, const godot_String *target);
GDEXTENSION_LITE_DECL void godot_EditorExportPlugin_add_file(godot_EditorExportPlugin *self, const godot_String *path, const godot_PackedByteArray *file, godot_bool remap);
GDEXTENSION_LITE_DECL void godot_EditorExportPlugin_add_apple_embedded_platform_project_static_lib(godot_EditorExportPlugin *self, const godot_String *path);
GDEXTENSION_LITE_DECL void godot_EditorExportPlugin_add_apple_embedded_platform_framework(godot_EditorExportPlugin *self, const godot_String *path);
GDEXTENSION_LITE_DECL void godot_EditorExportPlugin_add_apple_embedded_platform_embedded_framework(godot_EditorExportPlugin *self, const godot_String *path);
GDEXTENSION_LITE_DECL void godot_EditorExportPlugin_add_apple_embedded_platform_plist_content(godot_EditorExportPlugin *self, const godot_String *plist_content);
GDEXTENSION_LITE_DECL void godot_EditorExportPlugin_add_apple_embedded_platform_linker_flags(godot_EditorExportPlugin *self, const godot_String *flags);
GDEXTENSION_LITE_DECL void godot_EditorExportPlugin_add_apple_embedded_platform_bundle_file(godot_EditorExportPlugin *self, const godot_String *path);
GDEXTENSION_LITE_DECL void godot_EditorExportPlugin_add_apple_embedded_platform_cpp_code(godot_EditorExportPlugin *self, const godot_String *code);
GDEXTENSION_LITE_DECL void godot_EditorExportPlugin_add_ios_project_static_lib(godot_EditorExportPlugin *self, const godot_String *path);
GDEXTENSION_LITE_DECL void godot_EditorExportPlugin_add_ios_framework(godot_EditorExportPlugin *self, const godot_String *path);
GDEXTENSION_LITE_DECL void godot_EditorExportPlugin_add_ios_embedded_framework(godot_EditorExportPlugin *self, const godot_String *path);
GDEXTENSION_LITE_DECL void godot_EditorExportPlugin_add_ios_plist_content(godot_EditorExportPlugin *self, const godot_String *plist_content);
GDEXTENSION_LITE_DECL void godot_EditorExportPlugin_add_ios_linker_flags(godot_EditorExportPlugin *self, const godot_String *flags);
GDEXTENSION_LITE_DECL void godot_EditorExportPlugin_add_ios_bundle_file(godot_EditorExportPlugin *self, const godot_String *path);
GDEXTENSION_LITE_DECL void godot_EditorExportPlugin_add_ios_cpp_code(godot_EditorExportPlugin *self, const godot_String *code);
GDEXTENSION_LITE_DECL void godot_EditorExportPlugin_add_macos_plugin_file(godot_EditorExportPlugin *self, const godot_String *path);
GDEXTENSION_LITE_DECL void godot_EditorExportPlugin_skip(godot_EditorExportPlugin *self);
GDEXTENSION_LITE_DECL godot_Variant godot_EditorExportPlugin_get_option(const godot_EditorExportPlugin *self, const godot_StringName *name);
GDEXTENSION_LITE_DECL godot_EditorExportPreset * godot_EditorExportPlugin_get_export_preset(const godot_EditorExportPlugin *self);
GDEXTENSION_LITE_DECL godot_EditorExportPlatform * godot_EditorExportPlugin_get_export_platform(const godot_EditorExportPlugin *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_EXPORT_PLUGIN_H__
