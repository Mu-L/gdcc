// This file was automatically generated
// Do not modify this file
#ifndef __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_INTERFACE_H__
#define __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_INTERFACE_H__

#include "../class-stubs/all.h"
#include "../global_enums.h"
#include "../native_structures.h"
#include "../variant/all.h"
#include "../../gdextension/gdextension_interface.h"
#include "../../variant/all.h"

#ifdef __cplusplus
extern "C" {
#endif

// Singleton
GDEXTENSION_LITE_DECL godot_EditorInterface *godot_EditorInterface_singleton();

// Methods
GDEXTENSION_LITE_DECL void godot_EditorInterface_restart_editor(godot_EditorInterface *self, godot_bool save);
GDEXTENSION_LITE_DECL godot_EditorCommandPalette * godot_EditorInterface_get_command_palette(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL godot_EditorFileSystem * godot_EditorInterface_get_resource_filesystem(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL godot_EditorPaths * godot_EditorInterface_get_editor_paths(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL godot_EditorResourcePreview * godot_EditorInterface_get_resource_previewer(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL godot_EditorSelection * godot_EditorInterface_get_selection(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL godot_EditorSettings * godot_EditorInterface_get_editor_settings(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL godot_EditorToaster * godot_EditorInterface_get_editor_toaster(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL godot_EditorUndoRedoManager * godot_EditorInterface_get_editor_undo_redo(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_Texture2D) godot_EditorInterface_make_mesh_previews(godot_EditorInterface *self, const godot_TypedArray(godot_Mesh) *meshes, godot_int preview_size);
GDEXTENSION_LITE_DECL void godot_EditorInterface_set_plugin_enabled(godot_EditorInterface *self, const godot_String *plugin, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_EditorInterface_is_plugin_enabled(const godot_EditorInterface *self, const godot_String *plugin);
GDEXTENSION_LITE_DECL godot_Theme * godot_EditorInterface_get_editor_theme(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL godot_Control * godot_EditorInterface_get_base_control(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL godot_VBoxContainer * godot_EditorInterface_get_editor_main_screen(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL godot_ScriptEditor * godot_EditorInterface_get_script_editor(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL godot_SubViewport * godot_EditorInterface_get_editor_viewport_2d(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL godot_SubViewport * godot_EditorInterface_get_editor_viewport_3d(const godot_EditorInterface *self, godot_int idx);
GDEXTENSION_LITE_DECL void godot_EditorInterface_set_main_screen_editor(godot_EditorInterface *self, const godot_String *name);
GDEXTENSION_LITE_DECL void godot_EditorInterface_set_distraction_free_mode(godot_EditorInterface *self, godot_bool enter);
GDEXTENSION_LITE_DECL godot_bool godot_EditorInterface_is_distraction_free_mode_enabled(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL godot_bool godot_EditorInterface_is_multi_window_enabled(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL godot_float godot_EditorInterface_get_editor_scale(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL void godot_EditorInterface_popup_dialog(godot_EditorInterface *self, const godot_Window *dialog, const godot_Rect2i *rect);
GDEXTENSION_LITE_DECL void godot_EditorInterface_popup_dialog_centered(godot_EditorInterface *self, const godot_Window *dialog, const godot_Vector2i *minsize);
GDEXTENSION_LITE_DECL void godot_EditorInterface_popup_dialog_centered_ratio(godot_EditorInterface *self, const godot_Window *dialog, godot_float ratio);
GDEXTENSION_LITE_DECL void godot_EditorInterface_popup_dialog_centered_clamped(godot_EditorInterface *self, const godot_Window *dialog, const godot_Vector2i *minsize, godot_float fallback_ratio);
GDEXTENSION_LITE_DECL godot_String godot_EditorInterface_get_current_feature_profile(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL void godot_EditorInterface_set_current_feature_profile(godot_EditorInterface *self, const godot_String *profile_name);
GDEXTENSION_LITE_DECL void godot_EditorInterface_popup_node_selector(godot_EditorInterface *self, const godot_Callable *callback, const godot_TypedArray(godot_StringName) *valid_types, const godot_Node *current_value);
GDEXTENSION_LITE_DECL void godot_EditorInterface_popup_property_selector(godot_EditorInterface *self, const godot_Object *object, const godot_Callable *callback, const godot_PackedInt32Array *type_filter, const godot_String *current_value);
GDEXTENSION_LITE_DECL void godot_EditorInterface_popup_method_selector(godot_EditorInterface *self, const godot_Object *object, const godot_Callable *callback, const godot_String *current_value);
GDEXTENSION_LITE_DECL void godot_EditorInterface_popup_quick_open(godot_EditorInterface *self, const godot_Callable *callback, const godot_TypedArray(godot_StringName) *base_types);
GDEXTENSION_LITE_DECL void godot_EditorInterface_popup_create_dialog(godot_EditorInterface *self, const godot_Callable *callback, const godot_StringName *base_type, const godot_String *current_type, const godot_String *dialog_title, const godot_TypedArray(godot_StringName) *type_blocklist);
GDEXTENSION_LITE_DECL godot_FileSystemDock * godot_EditorInterface_get_file_system_dock(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL void godot_EditorInterface_select_file(godot_EditorInterface *self, const godot_String *file);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_EditorInterface_get_selected_paths(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL godot_String godot_EditorInterface_get_current_path(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL godot_String godot_EditorInterface_get_current_directory(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL godot_EditorInspector * godot_EditorInterface_get_inspector(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL void godot_EditorInterface_inspect_object(godot_EditorInterface *self, const godot_Object *object, const godot_String *for_property, godot_bool inspector_only);
GDEXTENSION_LITE_DECL void godot_EditorInterface_edit_resource(godot_EditorInterface *self, const godot_Resource *resource);
GDEXTENSION_LITE_DECL void godot_EditorInterface_edit_node(godot_EditorInterface *self, const godot_Node *node);
GDEXTENSION_LITE_DECL void godot_EditorInterface_edit_script(godot_EditorInterface *self, const godot_Script *script, godot_int line, godot_int column, godot_bool grab_focus);
GDEXTENSION_LITE_DECL void godot_EditorInterface_open_scene_from_path(godot_EditorInterface *self, const godot_String *scene_filepath, godot_bool set_inherited);
GDEXTENSION_LITE_DECL void godot_EditorInterface_reload_scene_from_path(godot_EditorInterface *self, const godot_String *scene_filepath);
GDEXTENSION_LITE_DECL godot_PackedStringArray godot_EditorInterface_get_open_scenes(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL godot_TypedArray(godot_Node) godot_EditorInterface_get_open_scene_roots(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL godot_Node * godot_EditorInterface_get_edited_scene_root(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL godot_Error godot_EditorInterface_save_scene(godot_EditorInterface *self);
GDEXTENSION_LITE_DECL void godot_EditorInterface_save_scene_as(godot_EditorInterface *self, const godot_String *path, godot_bool with_preview);
GDEXTENSION_LITE_DECL void godot_EditorInterface_save_all_scenes(godot_EditorInterface *self);
GDEXTENSION_LITE_DECL godot_Error godot_EditorInterface_close_scene(godot_EditorInterface *self);
GDEXTENSION_LITE_DECL void godot_EditorInterface_mark_scene_as_unsaved(godot_EditorInterface *self);
GDEXTENSION_LITE_DECL void godot_EditorInterface_play_main_scene(godot_EditorInterface *self);
GDEXTENSION_LITE_DECL void godot_EditorInterface_play_current_scene(godot_EditorInterface *self);
GDEXTENSION_LITE_DECL void godot_EditorInterface_play_custom_scene(godot_EditorInterface *self, const godot_String *scene_filepath);
GDEXTENSION_LITE_DECL void godot_EditorInterface_stop_playing_scene(godot_EditorInterface *self);
GDEXTENSION_LITE_DECL godot_bool godot_EditorInterface_is_playing_scene(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL godot_String godot_EditorInterface_get_playing_scene(const godot_EditorInterface *self);
GDEXTENSION_LITE_DECL void godot_EditorInterface_set_movie_maker_enabled(godot_EditorInterface *self, godot_bool enabled);
GDEXTENSION_LITE_DECL godot_bool godot_EditorInterface_is_movie_maker_enabled(const godot_EditorInterface *self);


#ifdef __cplusplus
}
#endif

#endif  // __GDEXTENSION_LITE_GENERATED_CLASS_METHODS_EDITOR_INTERFACE_H__
